﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Automation;
using WinX.Core;

namespace WinX.Windows
{
    [DisplayName("Control Path Match Rule")]
    [TypeConverter(typeof(OptionsConverter))]
    [Serializable()]
    public partial class ControlPathMatchRule : MatchRule
    {
        public ControlPathMatchRule()
        {
            MatchRules = new ObservableCollection<MatchRule>();
        }

        public ControlPathMatchRule(ObservableCollection<MatchRule> rules)
        {
            this.MatchRules = rules;
        }


        [DisplayName("Match Rules")]
        public ObservableCollection<MatchRule> MatchRules
        {
            get; set;
        }

        [DisplayName("Child Element")]
        public ControlPathMatchRule Child
        {
            get; set;
        }

        protected override bool MatchEle(object ele)
        {
            return false;
        }

        public override void WriteDescription(TextWriter writer)
        {
            writer.Write("ControlPath Match Rule");
        }
    }
}
