﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Automation;
using WinX.Core;

namespace WinX.Windows
{
    [DisplayName("Parent Window Title Match Rule")]
    [TypeConverter(typeof(OptionsConverter))]
    [Serializable()]

    public partial class ParentWindowTitleMatchRule : MatchRule
    {
        [DisplayName("Comparer")]
        public WinX.Core.Comparer<string> Comparer
        {
            get; set;
        }

        public ParentWindowTitleMatchRule()
        {
            Comparer = new WinX.Core.StringComparer("", WinX.Core.StringComparer.StringCompareType.Equals);
        }

        public ParentWindowTitleMatchRule(WinX.Core.Comparer<string> comparer)
        {
            if(comparer == null)
            {
                throw new ArgumentException("comparer");
            }

            this.Comparer = comparer;
        }

        public ParentWindowTitleMatchRule(string title) : this(new WinX.Core.StringComparer(title))
        {

        }

        public ParentWindowTitleMatchRule(System.Text.RegularExpressions.Regex rex) : this(new RegexComparer(rex))
        {

        }

        protected override bool MatchEle(object ele)
        {
            var hWnd = (IntPtr)ele;

            if(hWnd != IntPtr.Zero)
            {
                var pHwnd = WindowsHelper.GetParentSafe(hWnd);
                if(pHwnd != IntPtr.Zero)
                {
                    return this.Comparer.Compare(WindowsHelper.GetWindowText(pHwnd));
                }
            }

            return false;
        }

        public override void WriteDescription(TextWriter writer)
        {
            writer.Write("Parent Window Title '{0}'", Comparer.ToString());
        }
    }
}
