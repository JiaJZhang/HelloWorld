﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Automation;
using WinX.Core;

namespace WinX.Windows
{
    [DisplayName("AutomationId Match Rule")]
    [TypeConverter(typeof(OptionsConverter))]
    [Serializable()]
    public partial class ControlIdMatchRule : MatchRule
    {
        public ControlIdMatchRule()
        {

        }

        public ControlIdMatchRule(string automationId)
        {
            this.AutomationId = automationId;
        }

        [DisplayName("AutomationId")]
        public string AutomationId
        {
            get; set;
        }



        public override void WriteDescription(TextWriter writer)
        {
            writer.Write("ID = '{0}'", this.AutomationId);
        }

        protected override bool MatchEle(object ele)
        {
            if (ele == null)
                return false;
            var autEle = ele as AutomationElement;
            return this.AutomationId.Equals(autEle.Current.AutomationId);
        }
    }
}
