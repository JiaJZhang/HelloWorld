﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Automation;
using WinX.Core;


namespace WinX.Windows
{
    [DisplayName("Process Name Rule")]
    [TypeConverter(typeof(OptionsConverter))]
    [Serializable()]
    public partial class ProcessNameMatchRule : MatchRule
    {
        [DisplayName("Comparer")]
        public WinX.Core.Comparer<string> Comparer
        {
            get; set;
        }


        public ProcessNameMatchRule()
        {
            Comparer = new WinX.Core.StringComparer("", WinX.Core.StringComparer.StringCompareType.Equals);
        }

        public ProcessNameMatchRule(WinX.Core.Comparer<string> comparer)
        {
            if (comparer == null)
            {
                throw new ArgumentException("comparer");
            }

            this.Comparer = comparer;
        }

        public ProcessNameMatchRule(string processName) : this(new WinX.Core.StringComparer(processName))
        {

        }

        public ProcessNameMatchRule(System.Text.RegularExpressions.Regex rex) : this(new RegexComparer(rex))
        {

        }

        protected override bool MatchEle(object ele)
        {
            if ((IntPtr)ele == IntPtr.Zero)
                return false;
            return this.Comparer.Compare(WindowsHelper.GetProcessName((IntPtr)ele));
        }

        public override void WriteDescription(TextWriter writer)
        {
            writer.Write("Process Name = '{0}'", this.Comparer.ToString());
        }
    }
}
