﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Automation;
using WinX.Core;

namespace WinX.Windows
{
    [DisplayName("Index Match Rule")]
    [TypeConverter(typeof(OptionsConverter))]
    [Serializable()]
    public partial class ControlIndexMatchRule : MatchRule
    {
        public ControlIndexMatchRule()
        {

        }

        public ControlIndexMatchRule(int index)
        {
            this.Index = index;
        }

        [DisplayName("Index")]
        public int Index
        {
            get; set;
        }
        
        public override void WriteDescription(TextWriter writer)
        {
            writer.Write("Index = '{0}'", this.Index);
        }

        protected override bool MatchEle(object ele)
        {
            if (ele == null)
                return false;
            var autEle = ele as AutomationElement;
            return this.Index == autEle.GetIndex();
        }
    }
}
