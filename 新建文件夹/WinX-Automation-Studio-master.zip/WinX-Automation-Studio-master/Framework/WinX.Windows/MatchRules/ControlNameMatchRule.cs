﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Automation;
using WinX.Core;

namespace WinX.Windows
{
    [DisplayName("Name Match Rule")]
    [TypeConverter(typeof(OptionsConverter))]
    [Serializable()]
    public partial class ControlNameMatchRule : MatchRule
    {
        public ControlNameMatchRule()
        {

        }

        public ControlNameMatchRule(string elementName)
        {
            this.ElementName = elementName;
        }


        [DisplayName("ElementName")]
        public string ElementName
        {
            get; set;
        }

        public override void WriteDescription(TextWriter writer)
        {
            writer.Write("Name = '{0}'", this.ElementName);
        }

        protected override bool MatchEle(object ele)
        {
            if (ele == null)
                return false;
            var autEle = ele as AutomationElement;
            return this.ElementName.Equals(autEle.Current.Name);
        }
    }
}
