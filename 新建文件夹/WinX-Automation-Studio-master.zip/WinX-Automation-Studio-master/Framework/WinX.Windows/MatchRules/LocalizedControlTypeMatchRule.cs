﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Automation;
using WinX.Core;

namespace WinX.Windows
{
    [DisplayName("Localized Control Type Match Rule")]
    [TypeConverter(typeof(OptionsConverter))]
    [Serializable()]
    public partial class LocalizedControlTypeMatchRule : MatchRule
    {
        public LocalizedControlTypeMatchRule()
        {

        }


        public LocalizedControlTypeMatchRule(string localizedControlType)
        {
            this.LocalizedControlType = localizedControlType;
        }

        [DisplayName("LocalizedControlType")]
        public string LocalizedControlType
        {
            get; set;
        }

        public override void WriteDescription(TextWriter writer)
        {
            writer.Write("LocalizedControlType = '{0}'", this.LocalizedControlType);
        }

        protected override bool MatchEle(object ele)
        {
            if (ele == null)
                return false;
            var autEle = ele as AutomationElement;
            return this.LocalizedControlType.Equals(autEle.Current.LocalizedControlType);
        }
    }
}
