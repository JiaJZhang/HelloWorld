﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using WinX.Core;

namespace WinX.Windows
{
    [DisplayName("Window Title Match Rule")]
    [TypeConverter(typeof(OptionsConverter))]
    [Serializable()]
    public partial class WindowTitleMatchRule : MatchRule
    {
        [DisplayName("Comparer")]
        public WinX.Core.Comparer<string> Comparer
        {
            get; set;
        }
        
        public WindowTitleMatchRule()
        {
            Comparer = new WinX.Core.StringComparer("", WinX.Core.StringComparer.StringCompareType.Equals);
        }

        public WindowTitleMatchRule(WinX.Core.Comparer<string> comparer)
        {
            if (comparer == null)
            {
                throw new ArgumentException("comparer");
            }

            this.Comparer = comparer;
        }

        public WindowTitleMatchRule(string title) : this(new WinX.Core.StringComparer(title))
        {

        }

        public WindowTitleMatchRule(System.Text.RegularExpressions.Regex rex) : this(new RegexComparer(rex))
        {

        }
        
        public override void WriteDescription(TextWriter writer)
        {
            writer.Write("Title Name = '{0}'", this.Comparer.ToString());
        }

        protected override bool MatchEle(object ele)
        {
            if ((IntPtr)ele == IntPtr.Zero)
                return false;
            return this.Comparer.Compare(WindowsHelper.GetWindowText((IntPtr)ele));
        }
    }
}
