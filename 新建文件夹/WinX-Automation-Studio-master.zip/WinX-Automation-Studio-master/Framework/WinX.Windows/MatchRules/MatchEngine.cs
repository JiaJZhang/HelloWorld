﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Automation;
using WinX.Core;
using WinX.Windows.Controls;

namespace WinX.Windows
{
    public static partial class MatchEngine
    {
        public static void PeformWindowMatch(this GenericWindow window,RawWindow sourceWindow,bool MatchAllRules = false)
        {
            if (window == null)
                return;

            if(sourceWindow != null)
            {
                var objWindow = GetWindowByRule(window, sourceWindow, MatchAllRules);
                if(objWindow != null)
                {
                    MatchAllFields(objWindow, window.Fields);
                }
            }
        }

        public static Window GetWindowByRule(this GenericWindow window, RawWindow sourceWindow = null, bool MatchAllRules = false)
        {
            if (window == null)
            {
                return null;
            }

            ResetScreenStatus(window);

            window.Status = false;
            Window objWindow = null;

            if(sourceWindow == null)
            {
                var winElements = WindowsHelper.GetWindowHandles();
                if(winElements != null)
                {
                    Logger.Write("Method[GetWindowByRule] : Found " + winElements.Count + " windows.");
                    if(winElements.Count > 0)
                    {
                        foreach(var winPtr in winElements)
                        {
                            if(MatchElementRules(winPtr,window.MatchRules.ToList(),MatchAllRules))
                            {
                                Logger.Write("Found a match with handle ->['" + winPtr.ToString() + "'], returning window object.");
                                objWindow = new Window(AutomationElement.FromHandle(winPtr));
                                break;
                            }
                        }
                    }
                }
            }
            else if(MatchElementRules(sourceWindow.Handler,window.MatchRules.ToList(),MatchAllRules))
            {
                objWindow = new Window(AutomationElement.FromHandle(sourceWindow.Handler));
            }
            window.Status = false;
            if (objWindow != null)
                window.Status = true;
            return objWindow;
        }

        public static bool MatchElementRules(object autoEle,List<MatchRule> rules, bool MatchAllRules = false)
        {
            if(rules != null && rules.Count > 0)
            {
                foreach(var rule in rules)
                {
                    rule.Status = false;
                }

                var doneEvent = new ManualResetEvent(false);
                int taskCount = 0;
                for(int i =0;i < rules.Count ;i++)
                {
                    var index = i;
                    Interlocked.Increment(ref taskCount);

                    ThreadPool.QueueUserWorkItem((Object evt) =>
                    {
                        try
                        {
                            rules[index].Status = rules[index].Match(autoEle);
                            Logger.Write("Match Rule -> '" + rules[index].ID + "',[" + rules[index].ToString() + "], MatchAll = " + MatchAllRules + ",Match Status : " + rules[index].Status);
                            if (!MatchAllRules && !rules[index].Status)
                            {
                                doneEvent.Set();
                            }
                        }
                        catch (Exception ex)
                        {
                            Logger.Write(ex, "There was an error while trying to match rule '" + rules[index].ToString() + "'.");
                        }
                        finally
                        {
                            if(Interlocked.Decrement(ref taskCount) == 0)
                            {
                                doneEvent.Set();
                            }
                        }
                    },null);
                }

                doneEvent.WaitOne();

                return rules.Where(r => r.Status == false).Count() == 0;
            }
            return false;
        }

        public static bool MatchAllFields(this Window ObjWindow, ObservableCollection<Field> fields,int timeOutInSec = 30)
        {
            if(ObjWindow == null)
            {
                return false;
            }
            else if(fields != null && fields.Count > 0)
            {
                var doneEvent = new ManualResetEvent(false);
                int taskCount = 0;

                for (int i = 0; i < fields.Count; i++)
                {
                    int index = i;
                    Interlocked.Increment(ref taskCount);

                    ThreadPool.QueueUserWorkItem((object evt) =>
                    {
                        try
                        {
                            var field = fields[index] as WinX.Windows.GenericElement;
                            var objElement = GetElementByID(ObjWindow, field, timeOutInSec);
                            if (objElement != null)
                            {
                                field.Status = true;
                                field.TargetsCount = 1;
                                field.Targets = new List<object>();
                                field.Targets.Add(objElement);
                            }
                            else
                            {
                                field.Status = false;
                                field.TargetsCount = 0;
                            }
                        }
                        catch (Exception ex)
                        {
                            Logger.Write(ex, "There was an error while trying to match field '" + fields[index].Name + "'.");
                        }
                        finally
                        {
                            if (Interlocked.Decrement(ref taskCount) == 0)
                            {
                                doneEvent.Set();
                            }
                        }
                    }, null);

                }
                doneEvent.WaitOne(timeOutInSec * 1000);

                return fields.Where(r => r.Status == false).Count() == 0;
            }
            return false;
        }

        public static object GetElementByID(Window objWindow, Field fld, int timeoutInSec = 30)
        {
            try
            {
                var pathRule = fld.MatchRules.Where(m => m.GetType().Name.Equals(typeof(ControlPathMatchRule).Name)).FirstOrDefault() as ControlPathMatchRule;
                if (pathRule != null)
                {
                    return GetElementByPath(objWindow, pathRule, timeoutInSec);
                }
                return GetElementByPath(objWindow, new ControlPathMatchRule() { MatchRules = fld.MatchRules });

            }
            catch (Exception ex)
            {
                Logger.Write(ex, "[Field Name -> " + fld.Name + "]");
            }
            return null;
        }

        public static object GetElementByPath(Window objWindow, ControlPathMatchRule rule, int timeoutInSec = 30)
        {
            try
            {
                var rootEle = objWindow.AutomationElement;

                while (rule != null)
                {
                    rule.Status = false;
                    AutomationElement tmpEle = null;

                    var IndexRule = rule.MatchRules.Where(r => r.GetType().Name.Equals(typeof(ControlIndexMatchRule).Name)).FirstOrDefault() as ControlIndexMatchRule;
                    var lstRules = rule.MatchRules.Where(r => !r.GetType().Name.Equals(typeof(ControlIndexMatchRule).Name));

                    if (IndexRule != null)
                    {
                        tmpEle = WinX.Windows.AutomationExtns.FindChildAt(rootEle, IndexRule.Index);
                        if (tmpEle != null)
                        {
                            IndexRule.Status = true;

                            if (lstRules.Count() > 0 && !MatchElementRules(tmpEle, lstRules.ToList()))
                            {
                                tmpEle = null;
                            }
                        }
                    }


                    if (tmpEle == null && lstRules.Count() > 0)
                    {
                        var condition = SearchCondition.fromMatchRules(lstRules.ToList());
                        tmpEle = WinX.Windows.AutomationExtns.FindFirst(rootEle, TreeScope.Descendants, condition.CreateCondition(), timeoutInSec);

                        if (tmpEle != null)
                        {
                            foreach (var cRule in lstRules)
                            {
                                cRule.Status = true;
                            }
                        }
                    }

                    if (tmpEle != null)
                    {
                        rule.Status = true;
                        rootEle = tmpEle;
                    }
                    else
                    {
                        if (rule.MatchRules.Count != 0)
                        {
                            rootEle = null;
                            break;
                        }
                        else
                        {
                            rule.Status = true;
                        }
                    }

                    rule = rule.Child;
                }

                if (rootEle != null)
                {
                    return WinX.Windows.AutomationExtns.GetWinXGenericControl(rootEle);
                }
            }
            catch (Exception ex)
            {
                Logger.Write(ex, rule.ToString());
            }

            return null;
        }

        public static void ResetScreenStatus(GenericWindow window)
        {
            if (window != null)
            {
                window.Status = false;

                foreach (var rule in window.MatchRules)
                {
                    rule.Status = false;
                }

                foreach (var field in window.Fields)
                {
                    field.Status = false;
                    field.TargetsCount = 0;

                    foreach (var rule in field.MatchRules)
                    {
                        rule.Status = false;

                        if (rule.GetType().Name.Equals(typeof(ControlPathMatchRule).Name))
                        {
                            var pathRule = rule as ControlPathMatchRule;

                            while (pathRule != null)
                            {
                                pathRule.Status = false;
                                foreach (var cRule in pathRule.MatchRules)
                                {
                                    cRule.Status = false;
                                }
                                pathRule = pathRule.Child;
                            }
                        }
                    }
                }
            }
        }

        [MTAThread]
        public static bool WaitForAll(Window window, int timeOutInSec, params BaseElement[] fields)
        {
            if (window == null || window.AutomationElement == null)
            {
                return false;
            }

            if (fields == null && fields.Count() < 1)
            {
                return false;
            }

            var doneEvent = new ManualResetEvent(false);
            int taskCount = 0;

            for (int i = 0; i < fields.Length; i++)
            {
                int index = i;
                Interlocked.Increment(ref taskCount);
                ThreadPool.QueueUserWorkItem(state =>
                {
                    try
                    {
                        var field = fields[index] as GenericElement;

                        field.Status = false;
                        field.TargetsCount = 0;
                        field.Targets = null;

                        var objElement = GetElementByID(window, field, timeOutInSec);

                        while (objElement == null)
                        {
                            System.Threading.Thread.Sleep(250);
                            objElement = GetElementByID(window, field, timeOutInSec);
                        }

                        if (objElement != null)
                        {
                            field.Status = true;
                            field.TargetsCount = 1;
                            field.Targets = new List<object>();
                            field.Targets.Add(objElement);
                        }
                    }
                    catch (Exception ex)
                    {
                        Logger.Write(ex, "There was an error while trying to match field '" + fields[index].Name + "'.");
                    }
                    finally
                    {
                        if (Interlocked.Decrement(ref taskCount) == 0)
                        {
                            doneEvent.Set();
                        }
                    }
                }, null);
            }
            doneEvent.WaitOne(timeOutInSec * 1000);

            return fields.Where(f => f.Status == false).Count() == 0;
        }

        [MTAThread]
        public static bool WaitForAny(Window window, int timeOutInSec, params BaseElement[] fields)
        {
            if (window == null || window.AutomationElement == null)
            {
                return false;
            }

            if (fields == null && fields.Count() < 1)
            {
                return false;
            }

            var doneEvent = new ManualResetEvent(false);
            
            for (int i = 0; i < fields.Length; i++)
            {
                int index = i;

                ThreadPool.QueueUserWorkItem(state =>
                {
                    try
                    {
                        var field = fields[index] as GenericElement;

                        field.Status = false;
                        field.TargetsCount = 0;
                        field.Targets = null;

                        var objElement = GetElementByID(window, field, timeOutInSec);

                        while (objElement == null)
                        {
                            System.Threading.Thread.Sleep(250);
                            objElement = GetElementByID(window, field, timeOutInSec);
                        }

                        if (objElement != null)
                        {
                            field.Status = true;
                            field.TargetsCount = 1;
                            field.Targets = new List<object>();
                            field.Targets.Add(objElement);
                        }
                    }
                    catch (Exception ex)
                    {
                        Logger.Write(ex, "There was an error while trying to match field '" + fields[index].Name + "'.");
                    }
                    finally
                    {
                        doneEvent.Set();
                    }
                }, null);
            }
            doneEvent.WaitOne(timeOutInSec * 1000);

            return fields.Where(f => f.Status == false).Count() == 0;
        }
    }
}
