﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Automation;
using WinX.Core;

namespace WinX.Windows
{

    [DisplayName("Grand ParentWindowTitle Match Rule")]
    [TypeConverter(typeof(OptionsConverter))]
    [Serializable()]
    public partial class GrandParentWindowTitleMatchRule : MatchRule
    {
        [DisplayName("Comparer")]
        public WinX.Core.Comparer<string> Comparer
        {
            get; set;
        }

        public GrandParentWindowTitleMatchRule()
        {
            Comparer = new WinX.Core.StringComparer("", WinX.Core.StringComparer.StringCompareType.Equals);
        }

        public GrandParentWindowTitleMatchRule(WinX.Core.Comparer<string> comparer)
        {
            if (comparer == null)
            {
                throw new ArgumentException("comparer");
            }
            this.Comparer = comparer;
        }

        public GrandParentWindowTitleMatchRule(string title) : this(new WinX.Core.StringComparer(title))
        {

        }

        public GrandParentWindowTitleMatchRule(System.Text.RegularExpressions.Regex rex) : this(new RegexComparer(rex))
        {

        }

        protected override bool MatchEle(object ele)
        {
            var hWnd = (IntPtr)ele;
            var pHwnd = IntPtr.Zero;
            var gpHwnd = IntPtr.Zero;

            try
            {
                if (hWnd != IntPtr.Zero)
                {
                    pHwnd = WindowsHelper.GetParentSafe(hWnd);
                    if (pHwnd != IntPtr.Zero)
                    {
                        gpHwnd = WindowsHelper.GetParentSafe(pHwnd);
                        if (gpHwnd != IntPtr.Zero)
                        {
                            return this.Comparer.Compare(WindowsHelper.GetWindowText(gpHwnd));
                        }
                    }
                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                pHwnd = IntPtr.Zero;
                gpHwnd = IntPtr.Zero;


            }

            return false;
        }

        public override void WriteDescription(TextWriter writer)
        {
            writer.Write("Grand Parent Window Title '{0}'", Comparer.ToString());
        }
    }
}
