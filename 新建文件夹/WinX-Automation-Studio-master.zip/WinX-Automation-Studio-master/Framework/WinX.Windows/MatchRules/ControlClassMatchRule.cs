﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Automation;
using WinX.Core;

namespace WinX.Windows
{
    [DisplayName("ClassName Match Rule")]
    [TypeConverter(typeof(OptionsConverter))]
    [Serializable()]
    public partial class ControlClassMatchRule : MatchRule
    {
        [DisplayName("Comparer")]
        public WinX.Core.Comparer<string> Comparer
        {
            get; set;
        }

        public ControlClassMatchRule()
        {
            Comparer = new WinX.Core.StringComparer("", WinX.Core.StringComparer.StringCompareType.Equals);
        }

        public ControlClassMatchRule(WinX.Core.Comparer<string> comparer)
        {
            if (comparer == null)
            {
                throw new ArgumentException("comparer");
            }

            this.Comparer = comparer;
        }

        public ControlClassMatchRule(string className) : this(new WinX.Core.StringComparer(className))
        {

        }

        public ControlClassMatchRule(System.Text.RegularExpressions.Regex rex) : this(new RegexComparer(rex))
        {

        }

        protected override bool MatchEle(object ele)
        {
            if ((IntPtr)ele == IntPtr.Zero)
                return false;
            return this.Comparer.Compare(WindowsHelper.GetClassName((IntPtr)ele));
        }

        public override void WriteDescription(TextWriter writer)
        {
            writer.Write("Class Name = '{0}'", this.Comparer.ToString());
        }
    }
}
