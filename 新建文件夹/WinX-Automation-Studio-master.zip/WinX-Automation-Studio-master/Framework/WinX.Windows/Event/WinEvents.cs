﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using WinX.Core;

namespace WinX.Windows
{
    public partial class WinEvents
    {
        public delegate void MenuStartDelegate(IntPtr hWnd);
        public delegate void MenuEndDelegate(IntPtr hWnd);
        public delegate void WindowMinimizeStartDelegate(IntPtr hWnd);
        public delegate void WindowMinimizeEndtDelegate(IntPtr hWnd);
        public delegate void WindowForegroundChangedDelegate(IntPtr hWnd);
        public delegate void WindowDestroyDelegate(IntPtr hWnd);
        public delegate void WindowCreateDelegate(IntPtr hWnd);

        public sealed class WindowHook
        {
            private static User32.WinEventDelegate dEvent;
            private IntPtr pHook;

            public WindowHook(uint processID = 0)
            {
                dEvent = WinEventProc;
                pHook = User32.SetWinEventHook(User32.WinEvents.EVENT_SYSTEM_FOREGROUND, User32.WinEvents.EVENT_OBJECT_DESTROY, IntPtr.Zero, dEvent, processID, 0, 0x0000);
                if (IntPtr.Zero.Equals(pHook))
                {
                    throw new Win32Exception();
                }
                GC.KeepAlive(dEvent);
            }

            #region event handle

            public event MenuStartDelegate MenuStart;
            public event MenuEndDelegate MenuEnd;
            public event WindowMinimizeStartDelegate WindowMinimizeStart;
            public event WindowMinimizeEndtDelegate WindowMinimizeEnd;
            public event WindowForegroundChangedDelegate WindowForegroundChanged;
            public event WindowDestroyDelegate WindowDestroy;
            public event WindowCreateDelegate WindowCreate;


            public void OnMenuStart(IntPtr hWnd)
            {
                if (MenuStart != null)
                {
                    MenuStart(hWnd);
                }
            }

            public void OnMenuEnd(IntPtr hWnd)
            {
                if (MenuEnd != null)
                {
                    MenuEnd(hWnd);
                }
            }

            public void OnWindowMinimizeEnd(IntPtr hWnd)
            {
                if (WindowMinimizeEnd != null)
                {
                    WindowMinimizeEnd(hWnd);
                }
            }

            public void OnWindowMinimizeStart(IntPtr hWnd)
            {
                if (WindowMinimizeStart != null)
                {
                    WindowMinimizeStart(hWnd);
                }
            }

            public void OnWindowForegroundChanged(IntPtr hWnd)
            {
                if (WindowForegroundChanged != null)
                {
                    WindowForegroundChanged(hWnd);
                }
            }

            public void OnWindowDestroy(IntPtr hWnd)
            {
                if (WindowDestroy != null)
                {
                    WindowDestroy(hWnd);
                }
            }

            public void OnWindowCreate(IntPtr hWnd)
            {
                if (WindowCreate != null)
                {
                    WindowCreate(hWnd);
                }
            }

            #endregion

            private void WinEventProc(IntPtr hWinEventHook, User32.WinEvents eventType, IntPtr hwnd, int idObject, int idChild, uint dwEventThread, uint dwmsEventTime)
            {
                switch (eventType)
                {
                    case User32.WinEvents.EVENT_SYSTEM_FOREGROUND:
                        OnWindowForegroundChanged(hwnd);
                        break;
                    case User32.WinEvents.EVENT_SYSTEM_MENUEND:
                        OnMenuEnd(hwnd);
                        break;
                    case User32.WinEvents.EVENT_OBJECT_DESTROY:
                        OnWindowDestroy(hwnd);
                        break;
                    case User32.WinEvents.EVENT_SYSTEM_MINIMIZESTART:
                        OnWindowMinimizeStart(hwnd);
                        break;
                    case User32.WinEvents.EVENT_SYSTEM_MINIMIZEEND:
                        OnWindowMinimizeEnd(hwnd);
                        break;
                }
            }

            ~WindowHook()
            {
                if (!IntPtr.Zero.Equals(pHook))
                {
                    User32.UnhookWinEvent(pHook);
                }

                pHook = IntPtr.Zero;
                dEvent = null;

                WindowDestroy = null;
                WindowForegroundChanged = null;
                WindowMinimizeStart = null;
                WindowMinimizeEnd = null;
            }
        }
    }
}
