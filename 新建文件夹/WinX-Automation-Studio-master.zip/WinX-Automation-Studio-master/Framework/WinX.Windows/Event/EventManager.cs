﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;

namespace WinX.Windows
{
    public partial class EventManager
    {
        public delegate void WindowCreatedDelegate(GenericWindow source, Controls.Window target);
        public static event WindowCreatedDelegate WindowCreated;

        public static void OnWindowCreated(GenericWindow source, Controls.Window target)
        {
            if(WindowCreated != null)
            {
                WindowCreated(source, target);
            }
        }

        public delegate void WindowDestroyedDelegate(GenericWindow source, Controls.Window target);
        public static event WindowDestroyedDelegate WindowDestroyed;

        public static void OnWindowDestroyed(GenericWindow source, Controls.Window target)
        {
            if (WindowDestroyed != null)
            {
                WindowDestroyed(source, target);
            }
        }

        private static List<IntPtr> lstHandles = new List<IntPtr>();
        private static WinEvents.WindowHook winHook = new WinEvents.WindowHook();
        
        private static List<GenericWindow> windows = new List<GenericWindow>();
        public static List<GenericWindow> Windows
        {
            get
            {
                return windows;
            }
            set
            {
                windows = value;
            }
        }

        private static int timeOutInSec = 60;
        public static int TimeOutInSec
        {
            get
            {
                return timeOutInSec;
            }
            set
            {
                timeOutInSec = value;
            }
        }

        static EventManager()
        {
            winHook.WindowForegroundChanged += WinHook_WindowForegroundChanged;
            winHook.WindowDestroy += WinHook_WindowDestroy;
        }

        private static void WinHook_WindowDestroy(IntPtr hWnd)
        {
            try
            {
                if(lstHandles.Contains(hWnd))
                {
                    lstHandles.Remove(hWnd);
                    System.Threading.ThreadPool.QueueUserWorkItem(handle =>
                    {
                        DestroyedEvent(hWnd);
                    });
                }
            }
            catch(Exception ex)
            {
                WinX.Core.Logger.Write(ex, "There was an error while trying to identify the window form 'evt_OnWindowDestroy'.");
            }
        }

        private static void WinHook_WindowForegroundChanged(IntPtr hWnd)
        {
            try
            {
                if (lstHandles.Contains(hWnd))
                {
                    lstHandles.Add(hWnd);
                    System.Threading.ThreadPool.QueueUserWorkItem(handle =>
                    {
                        CreatedEvent(hWnd);
                    });
                }
            }
            catch (Exception ex)
            {
                WinX.Core.Logger.Write(ex, "There was an error while trying to identify the window form 'evt_OnWindowForegroundChanged'.");
            }
        }

        private static void CreatedEvent(IntPtr hwd)
        {
            for(int i =0;i < windows.Count ;i++)
            {
                int index = i;

                try
                {
                    if (MatchEngine.GetWindowByRule(windows[i], hwd.GetRawWindowFromHandle(), false) != null)
                    {
                        if (WindowCreated != null)
                        {
                            var windowCreated = new EventManager.WindowCreatedDelegate((GenericWindow source, Controls.Window target) =>
                            {
                                WindowCreated(source, target);
                            });

                            windowCreated.Invoke(windows[i], new Controls.Window(AutomationElement.FromHandle(hwd)));
                        }
                    }
                }
                catch(Exception ex)
                {
                    WinX.Core.Logger.Write(ex, "There was an error while trying to match generic window '" + windows[i].Name + "'.");
                }
            }
        }

        private static void DestroyedEvent(IntPtr hwd)
        {

        }
    }
}
