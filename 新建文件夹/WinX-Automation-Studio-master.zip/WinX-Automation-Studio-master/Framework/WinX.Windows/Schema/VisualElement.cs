﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;
using System.Xml.Serialization;
using WinX.Core;
using WinX.Imaging;

namespace WinX.Windows
{
    [Serializable]
    public partial class VisualElement : Field
    {
        [NonSerialized]
        [XmlIgnore()]
        public AutomationElement AutomationElement;

        [NonSerialized]
        [XmlIgnore()]
        WinX.Core.WindowsInput.InputSimulator inputSimulator = new WinX.Core.WindowsInput.InputSimulator();

        public VisualElement() : base()
        {

        }

        public VisualElement(AutomationElement automationElement) : base()
        {
            this.AutomationElement = automationElement;
        }

        //[XmlIgnore()]
        //public WinX.Windows.GenericWindow Parent
        //{
        //    get;
        //    set;
        //}

        public string Anchor
        {
            get; set;
        }

        public double Left
        {
            get; set;
        }

        public double Top
        {
            get; set;
        }

        public double Height
        {
            get; set;
        }

        public double Width
        {
            get; set;
        }

        public int WindowWidht
        {
            get; set;
        }

        public int WindowHeight
        {
            get; set;
        }

        public double srcZoom
        {
            get;
            set;
        }

        public double AdjustX
        {
            get; set;
        }

        public double AdjustY
        {
            get; set;
        }

        public string ImageBase64
        {
            get; set;
        }


        //public string ImageSrcBase64
        //{
        //    get; set;
        //}

        public double vWindowScrollPosition
        {
            get;
            set;
        }

        public double hWindowScrollPosition
        {
            get;
            set;
        }

        public void CaptureDetials(IntPtr hwnd)
        {
            var windowPos = hwnd.GetWindowLocation();
            this.WindowHeight = windowPos.Height;
            this.WindowWidht = windowPos.Width;
            this.GetWindowScrollPositions(hwnd);
        }

        //public void Click()
        //{
        //    MouseHelper.DoMouseRightClick(0, 0);
        //}

        private double threashold = 0.8f;

        public void Click()
        {
            var matchPoint = GetRealRectangle();
            if (matchPoint.X > 0)
            {
                MouseHelper.DoMosuseLeftClick(matchPoint.X, matchPoint.Y);
            }
        }

        public void DBClick()
        {
            var matchPoint = GetRealRectangle();
            if (matchPoint.X > 0)
            {
                MouseHelper.DoMosuseLeftClick(matchPoint.X, matchPoint.Y);

                System.Threading.Thread.Sleep(10);

                MouseHelper.DoMosuseLeftClick(matchPoint.X, matchPoint.Y);

            }
        }

        public void RightClick()
        {
            var matchPoint = GetRealRectangle();
            if (matchPoint.X > 0)
            {
                MouseHelper.DoMouseRightClick(matchPoint.X, matchPoint.Y);
            }
        }

        public System.Drawing.Point GetRealRectangle()
        {
            var result = new System.Drawing.Point();
            var matchRect = MatchFoundRect();
            if (matchRect.Height > 0)
            {
                var zoomSize = matchRect.Height / matchRect.Height;

                this.AutomationElement.Current.NativeWindowHandle.BringWindowFront();

                var adjustX = Convert.ToInt32(this.AutomationElement.Current.BoundingRectangle.X + matchRect.X  + 5 + (this.AdjustX * this.srcZoom * zoomSize));
                var adjustY = Convert.ToInt32(this.AutomationElement.Current.BoundingRectangle.Y + matchRect.Y  - 5 + (this.AdjustY * this.srcZoom * zoomSize));

                result = new System.Drawing.Point(adjustX, adjustY);
            }
            return result;
        }

        public System.Drawing.Rectangle MatchFoundRect()
        {
            var result = new System.Drawing.Rectangle();
            if (this.AutomationElement != null)
            {
                this.AutomationElement.Current.NativeWindowHandle.BringWindowFront();

                using (var imgSourceBitmap = this.AutomationElement.TakeScreenshotBitMap())
                {
                    using (var imgTagetBitmap = ImageHelper.BitmapImageToBitmap(WinX.Windows.ImageHelper.Base64ToImage(this.ImageBase64)))
                    {
                        result = ImageSearch.Search(imgSourceBitmap, imgTagetBitmap, false, threashold);
                    }
                }
            }
            return result;
        }

        public void TypeText(string Text)
        {
            this.Click();

            inputSimulator.Keyboard.TextEntry(Text);
        }


        public void SendKeys(System.Windows.Forms.Keys keys)
        {
        }

        public string OcrText()
        {
            return string.Empty;
        }

        public void GetWindowScrollPositions(IntPtr hwnd)
        {
            this.vWindowScrollPosition = this.GetVScrollPosition(hwnd);
            this.hWindowScrollPosition = this.GetHScrollPosition(hwnd);
        }

        public void SetWindowScrollPositions(IntPtr hwnd, int hScrollPos, int vScrollPos)
        {
            this.SetHScrollPosition(hwnd, hScrollPos);
            this.SetVScrollPosition(hwnd, vScrollPos);

        }

        private int GetVScrollPosition(IntPtr Hwnd)
        {
            return Core.User32.GetScrollPos(Hwnd, System.Windows.Forms.Orientation.Vertical);
        }

        private int GetHScrollPosition(IntPtr Hwnd)
        {
            return Core.User32.GetScrollPos(Hwnd, System.Windows.Forms.Orientation.Horizontal);
        }

        private void SetHScrollPosition(IntPtr Hwnd, int Position)
        {
            Core.User32.SetScrollPos(Hwnd, System.Windows.Forms.Orientation.Horizontal, Position, true);
        }

        private void SetVScrollPosition(IntPtr Hwnd, int Position)
        {
            Core.User32.SetScrollPos(Hwnd, System.Windows.Forms.Orientation.Vertical, Position, true);
        }

    }
}
