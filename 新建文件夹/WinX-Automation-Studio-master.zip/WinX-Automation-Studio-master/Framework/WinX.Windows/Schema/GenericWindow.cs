﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Xml.Serialization;
using WinX.Core;

namespace WinX.Windows
{
    public partial class GenericWindow : WinX.Core.Screen
    {
        private WinX.Windows.Controls.Window window = null;


        [XmlIgnore()]
        public WinX.Windows.Controls.Window Window
        {
            get
            {
                return this.window;
            }
            set
            {
                this.window = value;
                if (window != null)
                {
                    this.Status = true;
                }
            }
        }

        public override bool Refresh(bool MatchAllChildern = false)
        {
            return this.IsCreated(MatchAllChildern);
        }

        public bool IsCreated(bool MatchAllChildern = false)
        {
            this.Status = false;
            this.window = null;

            WinX.Core.Logger.Write("Attempting to locate window for the screen '" + this.Name + "'.");

            if (this.MatchRules != null && this.MatchRules.Count > 0)
            {
                this.window = MatchEngine.GetWindowByRule(this);
                this.Status = this.window != null;

                if (this.Status)
                {
                    WinX.Core.Logger.Write("Window found for the screen '" + this.Name + "'.");

                    if (MatchAllChildern && this.Status)
                    {
                        return MatchAllElements();
                    }
                    else
                    {
                        return this.Status;
                    }
                }
                else
                {
                    WinX.Core.Logger.Write("No window found for the screen '" + this.Name + "'.");
                }
            }

            return false;
        }

        public bool MatchAllElements(int timeOutInSec = 30)
        {
            return MatchEngine.MatchAllFields(this.window, this.Fields, timeOutInSec);
        }

        public override bool WaitForCreate(int timeoutInSeconds = 30, bool MatchAllChildern = false)
        {
            return WhenReady(() => this.window != null, timeoutInSeconds, MatchAllChildern);
        }

        public bool WhenReady(DoFunc<bool> func, int timeOutInSec = 30, bool MatchAllChildern = false)
        {
            WinX.Core.Logger.Write("Waiting for the screen '" + this.Name + "'.");

            if (func == null)
            {
                throw new ArgumentNullException("func");
            }

            var mEvent = new AutoResetEvent(false);

            try
            {
                var startTime = DateTime.Now;
                int timeLeft = (int)(timeOutInSec - (DateTime.Now.Subtract(startTime).TotalSeconds));

                ThreadPool.QueueUserWorkItem(obj =>
                {
                    AutoResetEvent evt = obj as AutoResetEvent;

                    try
                    {
                        while (!IsCreated(MatchAllChildern) && timeLeft > 0)
                        {
                            WinX.Core.VisualLog.RaiseOnWaitEvent(this, timeLeft, evt);
                            Logger.Write("Retrying for the screen '" + this.Name + "' to load complete| [Time left : " + timeLeft + " ].");
                            System.Threading.Thread.Sleep(600);
                            timeLeft = TimeoutInSec - Convert.ToInt32(DateTime.Now.Subtract(startTime).TotalSeconds);
                        }
                    }
                    catch (Exception ex)
                    {
                        Logger.Write(ex, "There was an error while trying to wait for a window object [" + window.Name + "].");
                    }
                    finally
                    {
                        ((AutoResetEvent)evt).Set();
                    }
                }, mEvent);

                VisualLog.RaiseOnWaitEvent(this, timeLeft, mEvent);

                if (mEvent.WaitOne(timeOutInSec * 1000))
                {
                    Logger.Write("WaitForCreate event was success.");

                    if (this.window != null)
                    {
                        VisualLog.RaiseWaitCompleteEvent(this, mEvent);
                        return func.Invoke();
                    }
                }
                else
                {
                    Logger.Write("WaitForCreate failed for the screen '" + this.Name + "'", Logger.MsgType.Error);
                }
            }
            catch (Exception ex)
            {
                Logger.Write(ex, "Error while trying to locate a window object for generic window [" + window.Name + "].");
            }

            VisualLog.RaiseWaitCompleteEvent(this, mEvent);
            return false;
        }

        public void SendKeys(string keys)
        {
            if (this.window != null)
            {
                try
                {
                    var windHandler = new IntPtr(this.Window.AutomationElement.Current.NativeWindowHandle);
                    windHandler.SendKeys(keys);
                }
                catch (Exception ex)
                {
                    Logger.Write("There was an error while trying to send keys to the window '" + this.Name + "'.");
                }
            }
        }

        public void SendKeyWait(string keys)
        {
            if (this.window != null)
            {
                try
                {

                    var windHandler = new IntPtr(this.Window.AutomationElement.Current.NativeWindowHandle);
                    windHandler.SendKeysWait(keys);
                }
                catch (Exception ex)
                {
                    Logger.Write("There was an error while trying to send keys to the window '" + this.Name + "'.");
                }
            }
        }

        public override object GetField(Guid fieldId)
        {
            if (window != null)
            {
                var fld = this.Fields.Where(m => m.ID == fieldId).FirstOrDefault();

                if (fld is VisualElement)
                {
                    var vld = (VisualElement)fld;

                    if (this.window != null)
                    {
                        vld.AutomationElement = this.window.AutomationElement;
                    }

                    return vld;
                }
                else if (fld != null)
                {
                    return MatchEngine.GetElementByID(this.Window, fld);
                }
                else
                {
                    Logger.Write("No field found with the proided ID '" + fieldId.ToString() + "'.", Logger.MsgType.Error);
                }
            }

            Logger.Write("Parent window is null or not an object.", Logger.MsgType.Error);
            return null;
        }


        private object getFields(Guid fieldId)
        {
            if (window != null)
            {
                var fld = this.Fields.Where(m => m.ID == fieldId).FirstOrDefault();

                if (fld != null)
                {
                    var typeArgument = Type.GetType(fld.ElementType);

                    if (typeArgument != null)
                    {
                        var getMethod = typeof(WinX.Windows.Controls.Window).GetMethods().Where(m => m.Name.Equals("GetAll") && m.ToString().Equals("T[] GetAll[T] WinX.Windows.Core.SearchCondition)")).FirstOrDefault();
                        if (getMethod != null)
                        {
                            return getMethod.MakeGenericMethod(typeArgument).Invoke(this.window, new object[] { new SearchCondition(fld.MatchRules.ToList()) });
                        }
                        else
                        {
                            throw new Exception("Cound not found method 'T[] GetAll[T] WinX.Windows.Core.SearchCondition)' -> [" + ID.ToString() + "].");
                        }
                    }
                    else
                    {
                        throw new Exception("Cound not found element type '" + fld.ElementType + "'. -> [" + fieldId.ToString() + "].");
                    }
                }
                else
                {
                    throw new Exception("Cound not identify any property with the ID -> [" + fieldId.ToString() + "].");
                }
            }
            throw new Exception("Parent window is null or not an object.");
        }


        public T GetField<T>(Guid id) where T : class
        {
            return GetField(id) as T;
        }

        public delegate void WindowEvent(GenericWindow sourceWindow);
        private EventManager.WindowCreatedDelegate _createdEvent;

        public event WindowEvent OnCreated
        {
            add
            {
                var window = EventManager.Windows.Where(w => w.ID == this.ID).FirstOrDefault();

                if (this.window != null)
                {
                    EventManager.Windows.Add(this);
                }

                _createdEvent = (source, target) =>
                {
                    if (this.ID.Equals(source.ID))
                    {
                        this.window = target;
                        value.Invoke(source);
                    }
                };

                EventManager.WindowCreated += _createdEvent;
            }
            remove
            {
                if (_createdEvent != null)
                {
                    EventManager.WindowCreated -= _createdEvent;
                    var window = EventManager.Windows.Where(m => m.ID == this.ID).FirstOrDefault();
                    if (window != null)
                    {
                        EventManager.Windows.Remove(window);
                    }
                }
            }
        }
    }
}
