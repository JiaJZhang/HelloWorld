﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Automation;

namespace WinX.Windows
{
    public partial class GenericApplication : WinX.Core.Application, IRunnableEntity
    {
        private Process process;

        public GenericApplication Start(string path,int TimeOutInSec = 30)
        {
            try
            {
                var startTime = DateTime.Now;
                WinX.Core.VisualLog.RaiseOnWaitEvent(this , (TimeOutInSec - DateTime.Now.Subtract(startTime).Seconds),null);
                var application = new GenericApplication();

                string[] subStr = path.Split(new char[] { ' ' }, 2);
                var arguments = string.Empty;
                if(subStr.Length > 1)
                {
                    path = subStr[0];
                    arguments = subStr[1];
                }

                if(File.Exists(path))
                {
                    throw new ArgumentException("path doesn't exist: " + path);
                }

                application.process = new Process { StartInfo = { FileName = @path, Arguments = arguments } };
                application.process.Start();
                application.process.WaitForInputIdle();

                WinX.Core.VisualLog.RaiseWaitCompleteEvent(this, null);
                return application;
            }
            catch(Exception ex)
            {
                WinX.Core.Logger.Write(ex, "There was exception while trying to start application '" + this.Name + "'.");
            }

            WinX.Core.VisualLog.RaiseWaitCompleteEvent(this, null);
            return null;
        }

        public Controls.Window GetWindowByName(string name)
        {
            var searchCondition = SearchCondition.ByName(name).And(SearchCondition.ByControlType(ControlType.Window));
            return this.GetWindowBySearchCondtion(searchCondition);
        }


        public Controls.Window GetWindowById(string automationId)
        {
            var searchCondition = SearchCondition.ByAutomationId(automationId).And(SearchCondition.ByControlType(ControlType.Window));
            return this.GetWindowBySearchCondtion(searchCondition);
        }

        public void Stop()
        {
            if(this.process != null)
            {
                try
                {
                    if(this.process.HasExited)
                    {
                        this.process.Kill();
                    }
                }
                finally
                {
                    this.process.Dispose();
                    this.process = null;
                }
            }
        }

        private Controls.Window GetWindowBySearchCondtion(SearchCondition searchCondition)
        {
            return searchCondition.GetWindowBySearchCondition();
        }

    }
}
