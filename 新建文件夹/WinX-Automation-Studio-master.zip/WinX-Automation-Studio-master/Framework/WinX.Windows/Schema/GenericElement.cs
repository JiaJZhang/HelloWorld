﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace WinX.Windows
{
    [Serializable()]
    public partial class GenericElement : WinX.Core.Field
    {
        [XmlIgnore()]
        public List<object> Targets { get; set; }

        public GenericElement():base()
        {

        }
    }
}
