﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;

namespace WinX.Windows.Controls
{
    public partial class ListBoxItem : ComboBoxItem, ISelectionItemMulti
    {
        public ListBoxItem(AutomationElement element) : base(element)
        {
        }

        public static SearchCondition ControlTypeCondition
        {
            get
            {
                return SearchCondition.ByControlType(ControlType.ListItem);
            }
        }

        public void AddToSelection()
        {
            this.SelectionItemServant.AddToSelection();
        }
    }
}
