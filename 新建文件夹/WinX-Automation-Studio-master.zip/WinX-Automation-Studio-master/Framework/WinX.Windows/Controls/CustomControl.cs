﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;
using System.Windows.Controls;

namespace WinX.Windows.Controls
{
    public partial class CustomControl : RunnableBaseElement
    {
        public CustomControl(AutomationElement element) : base(element)
        {
           

        }

        public static CustomControl Start<T>(params object[] constructorParameters) where T : UserControl
        {
            var controlType = typeof(T);
            var constructorInfo = GetConstructorInfo(controlType, constructorParameters);
            return Start(() => (UserControl)constructorInfo.Invoke(constructorParameters));
        }


        public static CustomControl Start<T>(Action<T> initalizeAction,params object[] constructorParameters) where T : UserControl
        {
            var controlType = typeof(T);
            var constructorInfo = GetConstructorInfo(controlType, constructorParameters);
            return Start(() => {

                var userControl = (T)constructorInfo.Invoke(constructorParameters);
                initalizeAction.Invoke(userControl);
                return userControl;
            });
        }


        protected override void CloseOpenElements()
        {
            var windows = this.GetParentElement().GetAll<Window>();
            do
            {
                foreach (var w in windows)
                {
                    try
                    {
                        w.Close();
                    }
                    catch (OperationNotSupportedException ex)
                    {

                    }
                }
            } while ((windows = this.GetParentWindow().GetAll<Window>()).Length > 0);
        }

        private static CustomControl Start(Func<UserControl> function)
        {
            var uerControlName = string.Empty;
            var customControl = RunnableBaseElement.Start<CustomControl>(() => 
            {
                var hostGrid = new Grid();
                var userControl = function.Invoke();
                uerControlName = userControl.Name;
                hostGrid.Children.Add(userControl);
                var hostWindow = new System.Windows.Window();
                hostWindow.Title = "UserControlWindow";
                hostWindow.Name = "UserControlWindow";
                hostWindow.SizeToContent = System.Windows.SizeToContent.WidthAndHeight;
                
                return hostWindow;
            });
            var baseElement = customControl.Get(uerControlName);
            customControl.automationElement = baseElement.AutomationElement;
            return customControl;
        }

    }
}
