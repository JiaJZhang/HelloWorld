﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;

namespace WinX.Windows.Controls
{
    public partial class StatusBar : BaseElement
    {
        public StatusBar(AutomationElement element) : base(element)
        {

        }

        public static SearchCondition ControlTypeCondition
        {
            get
            {
                return SearchCondition.ByControlType(ControlType.StatusBar);
            }
        }

        public Lable this[int index]
        {
            get
            {
                return this.GetStatusBarItems()[index];
            }
        }

        public Lable[] GetStatusBarItems()
        {
            return this.GetAll<Lable>();
        }
    }
}
