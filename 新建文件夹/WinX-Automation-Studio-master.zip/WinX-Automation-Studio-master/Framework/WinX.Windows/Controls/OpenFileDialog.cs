﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;

namespace WinX.Windows.Controls
{
    public partial class OpenFileDialog : BaseElement
    {

        public OpenFileDialog(AutomationElement element) : base(element)
        {
           
        }

        public static SearchCondition ControlTypeCondition
        {
            get
            {
                return SearchCondition.ByControlType(ControlType.Window).And(SearchCondition.ByClassName("#32770"));
            }
        }

        private string FilePath
        {
            set
            {
                var comboBox = this.Get<ComboBox>("1148");
                var textBox = comboBox.Get<TextBox>("1148");
                textBox.Value = value;
            }
        }

        public void Open(string filePath)
        {
            this.Open(new string[] { filePath });
        }

        public void Open(string[] filePath)
        {
            var wholeFilepath = string.Empty;
            foreach (var s in filePath)
            {
                wholeFilepath += "\"" + s + "\" ";
            }
            wholeFilepath = wholeFilepath.Trim();
            this.FilePath = wholeFilepath;
            this.Open();
        }

        public void Cancel()
        {
            this.Get<Button>("2").Click();
        }

        public void Open()
        {
            this.Get<Button>("1").Click();
        }
    }
}
