﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;

namespace WinX.Windows.Controls
{
    public partial class Calendar : BaseElement
    {
        public Calendar(AutomationElement element): base(element)
        {

        }

        public enum ECalendarView
        {
            MONTH = 0,
            Year = 1,
            DECADE = 2,
        }

        public static SearchCondition ControlTypeCondition
        {
            get
            {
                return SearchCondition.ByControlType(ControlType.Calendar);
            }
        }
        
        public ECalendarView View
        {
            get
            {
                var viewId = this.MultipleViewPattern.Current.CurrentView;
                ECalendarView currentView;
                switch (viewId)
                {
                    case 0:
                        currentView = ECalendarView.MONTH;
                        break;
                    case 1:
                        currentView = ECalendarView.Year;
                        break;
                    case 2:
                        currentView = ECalendarView.DECADE;
                        break;
                    default:
                        throw new UIException("Invalid View");
                }
                return currentView;
            }
            set
            {
                if(value != this.View)
                {
                    int viewId = 0;

                    switch (value)
                    {
                        case ECalendarView.MONTH:
                            viewId = 0;
                            break;
                        case ECalendarView.Year:
                            viewId = 1;
                            break;
                        case ECalendarView.DECADE:
                            viewId = 2;
                            break;
                    }
                    this.MultipleViewPattern.SetCurrentView(viewId);
                }
            }
        }

        public string HeaderValue
        {
            get
            {
                return this.Get<Button>("PARt_HeaderButton").Name;
            }
        }

        public DateTime[] SelectedDates
        {
            get
            {
                var selectedDates = new List<DateTime>();
                var selection = this.SelectionPattern.Current.GetSelection();
                foreach(var element in selection)
                {
                    var baseElement = new BaseElement(element);
                    selectedDates.Add(DateTime.Parse(baseElement.Name));
                }

                return selectedDates.ToArray();
            }
        }
        
        private MultipleViewPattern MultipleViewPattern
        {
            get
            {
                return this.GetPattern<MultipleViewPattern>();
            }
        }

        private SelectionPattern SelectionPattern
        {
            get
            {
                return this.GetPattern<SelectionPattern>();
            }
        }

        public void Next()
        {
            var nextButton = this.Get<Button>("PART_NextButton");
            nextButton.Click();
        }

        public void Previous()
        {
            var previousButton = this.Get<Button>("PART_PreviousButton");
            previousButton.Click();
        }

        public void SetSelectedDate(DateTime date)
        {
            try
            {
                var dayButton = this.GetCalendarDayButton(date);
                dayButton.Select();
            }
            catch(Exception ex)
            {
                throw new OperationNotSupportedException(ex.Message);
            }
        }

        public void AddDateToSelection(DateTime date)
        {
            try
            {
                var dayButton = this.GetCalendarDayButton(date);
                dayButton.AddToSelection();
            }
            catch (Exception ex)
            {
                throw new OperationNotSupportedException(ex.Message);
            }
        }

        public void UnselectDate(DateTime date)
        {
            try
            {
                var dayButton = this.GetCalendarDayButton(date);
                dayButton.Unselect();
            }
            catch (Exception ex)
            {
                throw new OperationNotSupportedException(ex.Message);
            }
        }

        public bool IsDateSelected(DateTime date)
        {
            try
            {
                var dayButton = this.GetCalendarDayButton(date);
                return dayButton.IsSelected;
            }
            catch (Exception ex)
            {
                throw new OperationNotSupportedException(ex.Message);
            }
        }


        public void SelectRange(DateTime startDate,DateTime endDate)
        {
            var dateRange = new List<DateTime>();
            for(var currentDate = startDate; currentDate <= endDate;currentDate = currentDate.AddDays(1))
            {
                dateRange.Add(currentDate);
            }
            this.SelectRange(dateRange);
        }


        public void SelectRange(IEnumerable<DateTime> dateRange)
        {
            try
            {
                bool firstSelected = false;
                foreach(var date in dateRange)
                {
                    if(!firstSelected)
                    {
                        var dayButton = this.GetCalendarDayButton(date);
                        dayButton.Select();
                        firstSelected = true;
                    }
                    else
                    {
                        var dayButton = this.GetCalendarDayButton(date);
                        dayButton.AddToSelection();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new OperationNotSupportedException(ex.Message);
            }
        }

        public void AddRangeToSelection(DateTime startDate, DateTime endDate)
        {
            var dateRange = new List<DateTime>();
            for (var currentDate = startDate; currentDate <= endDate; currentDate = currentDate.AddDays(1))
            {
                dateRange.Add(currentDate);
            }
            this.AddRangeToSelection(dateRange);
        }


        public void AddRangeToSelection(IEnumerable<DateTime> dateRange)
        {
            try
            {
                foreach (var date in dateRange)
                {
                    var dayButton = this.GetCalendarDayButton(date);
                    dayButton.AddToSelection();
                }
            }
            catch (Exception ex)
            {
                throw new OperationNotSupportedException(ex.Message);
            }
        }

        public void NavigateToMonth(int month,int year)
        {
            var navMonth = new DateTime(year, month, 1);
            this.NavigateToMonth(navMonth);
        }


        public void NavigateToMonth(DateTime date)
        {
            try
            {
                this.View = ECalendarView.MONTH;
                DateTime currentVisDate;
                do
                {
                    currentVisDate = DateTime.Parse(this.HeaderValue);
                    while (currentVisDate.Year < date.Year)
                    {
                        this.Next();
                        currentVisDate = DateTime.Parse(this.HeaderValue);
                    }

                    while (currentVisDate.Year > date.Year)
                    {
                        this.Previous();
                        currentVisDate = DateTime.Parse(this.HeaderValue);
                    }

                    if (currentVisDate.Month < date.Month)
                    {
                        this.Next();
                    }
                    else if (currentVisDate.Month > date.Month)
                    {
                        this.Previous();
                    }
                } while (currentVisDate.Month != date.Month || currentVisDate.Year != date.Year);

            }
            catch (Exception ex)
            {
                throw new OperationNotSupportedException(ex.Message);
            }
        }

        private CalendarDayButton GetCalendarDayButton(DateTime date)
        {
            var buttonName = date.ToLongDateString();
            this.NavigateToMonth(date);
            var dayButton = this.GetByName<CalendarDayButton>(buttonName);
            return dayButton;
        }
    }
}
