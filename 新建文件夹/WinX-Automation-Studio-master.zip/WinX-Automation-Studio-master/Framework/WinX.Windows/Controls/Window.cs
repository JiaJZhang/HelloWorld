﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Automation;
using WinX.Core;

namespace WinX.Windows.Controls
{
    [TypeConverter(typeof(OptionsConverter))]
    public partial class Window:BaseElement,IWindow
    {
        public Window(AutomationElement automationElement) :base(automationElement)
        {

        }

        public Bitmap TakeScreenshotBitMap()
        {
            return this.AutomationElement.TakeScreenshotBitMap();
        }

        public string TakeScreenshotBase64()
        {
            return this.AutomationElement.TakeScreenshotBase64();
        }


        public System.Windows.Rect GetRect()
        {
            return this.automationElement.Current.BoundingRectangle;
        }

        public void MinimizedWindow()
        {
            if (this.AutomationElement != null)
            {
                var hwnd = new IntPtr(AutomationElement.Current.NativeWindowHandle);
                var winP = new Core.WINDOWPLACEMENT();
                if (Core.User32.GetWindowPlacement(hwnd, out winP))
                {
                    Core.User32.ShowWindow(hwnd, 2);
                }
            }
        }

        public void BringWindowFront()
        {
            //if (this.AutomationElement != null)
            //{
            //    var hwnd = new IntPtr(AutomationElement.Current.NativeWindowHandle);
            //    var winP = new Core.WINDOWPLACEMENT();
            //    if (Core.User32.GetWindowPlacement(hwnd, out winP))
            //    {
            //        if (winP.showCmd == 2)// if Minimized
            //        {
            //            Core.User32.ShowWindow(hwnd, 1);
            //        }
            //    }

            //    User32.SetActiveWindow(hwnd);
            //    User32.SetForegroundWindow(hwnd);
            //    User32.SetForegroundWindow(hwnd);
            //    User32.SetFocus(hwnd);

            //    System.Threading.Thread.Sleep(300);
            //}
            this.AutomationElement.Current.NativeWindowHandle.BringWindowFront();

        }

        public static SearchCondition ControlTypeCondition
        {
            get
            {
                return SearchCondition.ByControlType(ControlType.Window);
            }
        }

        public MessageBox GetMessageBox(string name)
        {
            return this.Get<MessageBox>(SearchCondition.ByName(name));
        }

        public SaveFileDialog GetSaveFileDialog(string name)
        {
            return this.Get<SaveFileDialog>(SearchCondition.ByName(name));
        }

        public SaveFileDialog GetSaveFileDialog()
        {
            return this.GetSaveFileDialog(AppConfigImpl.Instance.GetLocalizedName(ElementIdentifier.SAVE_FILE_DEFAULT_TITLE));
        }
        
        public OpenFileDialog GetOpenFileDialog()
        {
            return this.GetOpenFileDialog(AppConfigImpl.Instance.GetLocalizedName(ElementIdentifier.SAVE_FILE_DEFAULT_TITLE));
        }

        public OpenFileDialog GetOpenFileDialog(string name)
        {
            return this.Get<OpenFileDialog>(SearchCondition.ByName(name));
        }

        public void Maximize()
        {
            var windowPattern = GetPattern<WindowPattern>();
            if(windowPattern.Current.CanMaximize)
            {
                windowPattern.SetWindowVisualState(WindowVisualState.Maximized);
            }
            else
            {
                throw new OperationNotSupportedException("Maximizing is not allowed for the window with the automation-id " + this.GetAutomationId());
            }
        }

        public void Minimize()
        {
            var windowPattern = GetPattern<WindowPattern>();
            if (windowPattern.Current.CanMinimize)
            {
                windowPattern.SetWindowVisualState(WindowVisualState.Minimized);
            }
            else
            {
                throw new OperationNotSupportedException("Minimizing is not allowed for the window with the automation-id " + this.GetAutomationId());
            }
        }

        public void Close()
        {
            var windowPattern = GetPattern<WindowPattern>();
            windowPattern.Close();
        }

        public Menu GetMenu(string automationId)
        {
            return Get<Menu>(automationId);
        }
        
        public WindowVisualState GetVisualState()
        {
            var windowPattern = GetPattern<WindowPattern>();
            return windowPattern.Current.WindowVisualState;
        }

        public void RecoverNormal()
        {
            var windowpattern = GetPattern<WindowPattern>();
            windowpattern.SetWindowVisualState(WindowVisualState.Normal);
        }
    }
}
