﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;

namespace WinX.Windows.Controls
{
    public partial class Hyperlink : BaseElement, IInvoke
    {
        private readonly IInvoke invokeServant;

        public Hyperlink(AutomationElement element) : base(element)
        {
            invokeServant = new InvokeImpl(this);
        }

        public static SearchCondition ControlTypeCondition
        {
            get
            {
                return SearchCondition.ByControlType(ControlType.Hyperlink);
            }
        }

        public string TextValue
        {
            get
            {
                return Name;
            }
        }


        public void Click()
        {
            this.invokeServant.Click();
        }
    }

}