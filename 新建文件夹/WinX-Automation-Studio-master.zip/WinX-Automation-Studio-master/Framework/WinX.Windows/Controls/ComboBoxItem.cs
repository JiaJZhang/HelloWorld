﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;

namespace WinX.Windows.Controls
{
    public partial class ComboBoxItem : BaseElement , ISelectionIetmSingle
    {
        protected readonly ISelectionItemMulti SelectionItemServant;

        public ComboBoxItem(AutomationElement element) : base(element)
        {
            SelectionItemServant = new SelectionItemImpl(this);
        }
        
        public static SearchCondition ControlTypeCondition
        {
            get
            {
                return SearchCondition.ByControlType(ControlType.ListItem);
            }
        }

        public bool IsSelected
        {
            get
            {
                return this.SelectionItemServant.IsSelected;
            }
            set
            {
                this.SelectionItemServant.IsSelected = value;
            }
        }

        public string TextValue
        {
            get
            {
                return this.Name;
            }
        }

        public void Select()
        {
            this.SelectionItemServant.Select();
        }

        public void Unselect()
        {
            this.SelectionItemServant.Unselect();
        }
    }
}
