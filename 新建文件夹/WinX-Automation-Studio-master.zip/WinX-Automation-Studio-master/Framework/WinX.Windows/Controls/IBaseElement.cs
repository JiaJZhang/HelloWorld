﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;

namespace WinX.Windows.Controls
{
    public interface IBaseElement
    {
        AutomationElement AutomationElement
        {
            get;
        }

        string GetToolTip();

        BaseElement GetParentElement();

        string GetElementName();

        string GetAutomationId();

        bool IsEnabled();

        bool IsOffscreen();

        IWindow GetParentWindow();

        T[] GetAll<T>() where T: BaseElement;

        T Get<T>(string automationId) where T : BaseElement;

        T GetByName<T>(string name) where T : BaseElement;

        T Get<T>(SearchCondition condition) where T : BaseElement;

        T[] GetAll<T>(SearchCondition condition) where T : BaseElement;

        BaseElement Get(SearchCondition condition);

        BaseElement Get(string automationId);

        BaseElement GetByName(string name);

        BaseElement[] GetAll(SearchCondition condition);

        T GetPattern<T>() where T : BasePattern;

        void ClickRight();

        void ClickLeft();

        void DoubleClick();

        void SetFocus();
    }
}
