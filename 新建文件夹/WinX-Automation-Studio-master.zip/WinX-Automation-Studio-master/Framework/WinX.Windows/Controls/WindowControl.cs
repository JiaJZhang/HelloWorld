﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;

namespace WinX.Windows.Controls
{
    public partial class WindowControl : RunnableBaseElement, IWindow
    {
        private readonly Window dummyWindow;

        public WindowControl(AutomationElement element) : base(element)
        {
            this.dummyWindow = new Window(element);
        }

        public static WindowControl Start<T>(params object[] constructorParameters) where T : System.Windows.Window
        {
            var windowType = typeof(T);
            var constructorInfo = GetConstructorInfo(windowType, constructorParameters);
            return Start<WindowControl>(() => (System.Windows.Window)constructorInfo.Invoke(constructorParameters));
        }

        public void Close()
        {
            this.dummyWindow.Close();
        }

        public Menu GetMenu(string automationId)
        {
            return this.dummyWindow.GetMenu(automationId);
        }

        public MessageBox GetMessageBox(string name)
        {
            return this.dummyWindow.GetMessageBox(name);
        }

        public OpenFileDialog GetOpenFileDialog()
        {
            return this.dummyWindow.GetOpenFileDialog();
        }

        public OpenFileDialog GetOpenFileDialog(string name)
        {
           return this.dummyWindow.GetOpenFileDialog(name);
        }

        public SaveFileDialog GetSaveFileDialog()
        {
            return this.dummyWindow.GetSaveFileDialog();
        }

        public SaveFileDialog GetSaveFileDialog(string name)
        {
           return this.dummyWindow.GetSaveFileDialog(name);
        }

        public WindowVisualState GetVisualState()
        {
            return this.dummyWindow.GetVisualState();
        }

        public void Maximize()
        {
            this.dummyWindow.Maximize();
        }

        public void Minimize()
        {
            this.dummyWindow.Minimize();
        }

        public void RecoverNormal()
        {
            this.dummyWindow.RecoverNormal();
        }

        protected override void CloseOpenElements()
        {
            var windows = this.GetAll<Window>();
            do
            {
                foreach (var w in windows)
                {
                    try
                    {
                        w.Close();
                    }
                    catch (OperationNotSupportedException ex)
                    {

                    }
                }
            }
            while ((windows = this.GetAll<Window>()).Length > 0);
        }
    }
}
