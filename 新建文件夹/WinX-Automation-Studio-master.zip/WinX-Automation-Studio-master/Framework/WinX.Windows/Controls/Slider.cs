﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;

namespace WinX.Windows.Controls
{
    public partial class Slider : BaseElement
    {
        public Slider(AutomationElement element) : base(element)
        {

        }

        public static SearchCondition ControlTypeCondition
        {
            get
            {
                return SearchCondition.ByControlType(ControlType.Slider);
            }
        }

        public double Value
        {
            get
            {
                return this.GetRangeValuePattern().Current.Value;
            }
            set
            {
                try
                {
                    this.GetRangeValuePattern().SetValue(value);
                }
                catch(ElementNotFoundException ex)
                {
                    throw new OperationNotSupportedException("Element is not enabled");
                }
                catch (ArgumentOutOfRangeException ex)
                {
                    throw new OperationNotSupportedException("Value was out of range");
                }
            }
        }

        public double Maximum
        {
            get
            {
                return this.GetRangeValuePattern().Current.Maximum;
            }
        }

        public double Minimum
        {
            get
            {
                return this.GetRangeValuePattern().Current.Minimum;
            }
        }

        public double SmallChange
        {
            get
            {
                return this.GetRangeValuePattern().Current.SmallChange;
            }
        }

        public double LargeChange
        {
            get
            {
                return this.GetRangeValuePattern().Current.LargeChange;
            }
        }

        public void SmallIncrease()
        {
            var newValue = this.GetRangeValuePattern().Current.Value + this.SmallChange;
            this.Value = newValue;
        }

        public void SmallDecrease()
        {
            var newValue = this.GetRangeValuePattern().Current.Value - this.SmallChange;
            this.Value = newValue;
        }

        public void LargeIncrease()
        {
            var newValue = this.GetRangeValuePattern().Current.Value + this.LargeChange;
            this.Value = newValue;
        }

        public void LargeDecrease()
        {
            var newValue = this.GetRangeValuePattern().Current.Value - this.LargeChange;
            this.Value = newValue;
        }

        public RangeValuePattern GetRangeValuePattern()
        {
            return this.GetPattern<RangeValuePattern>();
        }
    }
}
