﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;

namespace WinX.Windows.Controls
{
    public partial class ToggleImpl : AbstractPatternServant, IToggle
    {
        public ToggleImpl(BaseElement element) : base(element)
        {

        }

        private TogglePattern GetTogglePattern()
        {
            return this.BaseElement.GetPattern<TogglePattern>();
        }

        public bool IsOff
        {
            get
            {
                return this.GetTogglePattern().Current.ToggleState == ToggleState.Off;
            }
        }

        public bool IsOn
        {
            get
            {
                return this.GetTogglePattern().Current.ToggleState == ToggleState.On;
            }
        }


        public bool IsIndeterminate
        {
            get
            {
                return this.GetTogglePattern().Current.ToggleState == ToggleState.Indeterminate;
            }
        }


        public void Toggle()
        {
            try
            {
                this.GetTogglePattern().Toggle();
            }
            catch(Exception ex)
            {
                throw new OperationNotSupportedException("The control is not enabled");
            }
        }
    }
}
