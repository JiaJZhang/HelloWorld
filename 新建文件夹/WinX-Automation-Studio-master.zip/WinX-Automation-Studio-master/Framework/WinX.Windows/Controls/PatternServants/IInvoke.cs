﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WinX.Windows.Controls
{
    /// <summary>
    /// Represents the interface for the invoke-pattern.
    /// </summary>
    public interface IInvoke
    {
        /// <summary>
        /// Invoke the Base Element.
        /// </summary>
        void Click();
    }
}
