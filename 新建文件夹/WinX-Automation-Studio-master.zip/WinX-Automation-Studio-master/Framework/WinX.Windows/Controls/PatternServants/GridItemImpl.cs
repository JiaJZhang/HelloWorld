﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;

namespace WinX.Windows.Controls
{
    public partial class GridItemImpl : AbstractPatternServant, IGridItem
    {
        public GridItemImpl(BaseElement element): base(element)
        {

        }

        public int Column
        {
            get
            {
                return this.BaseElement.GetPattern<GridItemPattern>().Current.Column;
            }
        }

        public int ColumnSpan
        {
            get
            {
                return this.BaseElement.GetPattern<GridItemPattern>().Current.ColumnSpan;
            }
        }

        public int Row
        {
            get
            {
                return this.BaseElement.GetPattern<GridItemPattern>().Current.Row;
            }
        }

        public int RowSpan
        {
            get
            {
                return this.BaseElement.GetPattern<GridItemPattern>().Current.RowSpan;
            }
        }
    }
}
