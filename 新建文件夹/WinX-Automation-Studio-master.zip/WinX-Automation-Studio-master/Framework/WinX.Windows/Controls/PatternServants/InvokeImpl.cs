﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;

namespace WinX.Windows.Controls
{
    public class InvokeImpl : AbstractPatternServant, IInvoke
    {
        public InvokeImpl(BaseElement BaseElement) : base(BaseElement) { }

        public void Click()
        {
            this.BaseElement.GetPattern<InvokePattern>().Invoke();
        }
    }
}
