﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WinX.Windows.Controls
{
    public class AbstractPatternServant
    {
        private readonly BaseElement baseElement;

        protected AbstractPatternServant(BaseElement clientElement)
        {
            this.baseElement = clientElement;
        }

        protected BaseElement BaseElement
        {
            get { return this.baseElement; }
        }
    }
}
