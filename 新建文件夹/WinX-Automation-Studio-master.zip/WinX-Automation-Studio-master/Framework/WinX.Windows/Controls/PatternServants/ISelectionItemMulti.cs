﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WinX.Windows.Controls
{
    public interface ISelectionItemMulti : ISelectionIetmSingle
    {
        void AddToSelection();
    }
}
