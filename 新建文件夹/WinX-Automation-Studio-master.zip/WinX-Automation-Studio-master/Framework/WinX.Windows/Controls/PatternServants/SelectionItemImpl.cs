﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WinX.Windows.Controls
{
    public partial class SelectionItemImpl : AbstractPatternServant, ISelectionItemMulti
    {
        public SelectionItemImpl(BaseElement element) : base(element)
        {

        }

        public bool IsSelected
        {
            get
            {
                throw new NotImplementedException();
            }

            set
            {
                throw new NotImplementedException();
            }
        }

        bool ISelectionItemSimple.IsSelected
        {
            get
            {
                throw new NotImplementedException();
            }
        }

        public void AddToSelection()
        {
            throw new NotImplementedException();
        }

        public void Select()
        {
            throw new NotImplementedException();
        }

        public void Unselect()
        {
            throw new NotImplementedException();
        }
    }
}
