﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WinX.Windows.Controls
{
    public interface ISelectionIetmSingle : ISelectionItemSimple
    {
        new bool IsSelected { get; set; }

        void Unselect();
    }
}
