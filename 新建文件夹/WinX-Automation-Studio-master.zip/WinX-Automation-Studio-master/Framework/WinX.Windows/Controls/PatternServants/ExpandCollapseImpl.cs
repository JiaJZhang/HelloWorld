﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WinX.Windows.Controls
{
    public partial class ExpandCollapseImpl : AbstractPatternServant, IExpandCollapse
    {
        public ExpandCollapseImpl(BaseElement element): base(element)
        {

        }

        public bool IsExpanded
        {
            get
            {
                var expandCollapsestate = this.BaseElement.GetPattern<System.Windows.Automation.ExpandCollapsePattern>().Current.ExpandCollapseState;

                return expandCollapsestate == System.Windows.Automation.ExpandCollapseState.Expanded;
            }
            set
            {
                if(this.IsExpanded && !value)
                {
                    this.Collapse();
                }
                else if(!this.IsExpanded && value)
                {
                    this.Expand();
                }
            }
        }

        public void Expand()
        {
            if(!this.BaseElement.IsEnabled())
            {
                throw new OperationNotSupportedException("Can not expand item , because it's not enabled");
            }

            this.BaseElement.GetPattern<System.Windows.Automation.ExpandCollapsePattern>().Expand();
        }

        public void Collapse()
        {

            if (!this.BaseElement.IsEnabled())
            {
                throw new OperationNotSupportedException("Can not expand item , because it's not Collapse");
            }

            this.BaseElement.GetPattern<System.Windows.Automation.ExpandCollapsePattern>().Collapse();
        }

    }
}
