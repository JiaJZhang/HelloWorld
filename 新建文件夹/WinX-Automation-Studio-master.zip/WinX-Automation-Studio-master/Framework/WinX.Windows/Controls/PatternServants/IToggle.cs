﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WinX.Windows.Controls
{
    public interface IToggle
    {
        bool IsOff { get; }

        bool IsOn { get; }

        bool IsIndeterminate { get; }

        void Toggle();
    }
}
