﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;

namespace WinX.Windows.Controls
{
    public abstract class AbstractDataGrid : BaseElement
    {
        protected AbstractDataGrid(AutomationElement automationElement) : base(automationElement)
        {
        }

        public DataGridHeader Header
        {
            get
            {
                return this.Get<DataGridHeader>(SearchCondition.FromAutomationCondition(Condition.TrueCondition));
            }
        }

        public int ColumnCount
        {
            get
            {
                return this.GetPattern<GridPattern>().Current.ColumnCount;
            }
        }


        public int RowCount
        {
            get
            {
                return this.GetPattern<GridPattern>().Current.RowCount;
            }
        }

        protected T[] GetRows<T>() where T : AbstractDataGridRow
        {
            return this.GetAll<T>();
        }

        public T GetCell<T>(int row, int column) where T : AbstractDataGridCell
        {
            var cellElement = this.GetPattern<GridPattern>().GetItem(row, column);

            if (cellElement == null)
            {
                throw new ArgumentOutOfRangeException("No such cell in datagrid : colun " + column + ", row " + row);
            }

            var element = (T)typeof(T).GetConstructor(new Type[] { typeof(AutomationElement) }).Invoke(new object[] { cellElement });

            return element;
        }
    }
}
