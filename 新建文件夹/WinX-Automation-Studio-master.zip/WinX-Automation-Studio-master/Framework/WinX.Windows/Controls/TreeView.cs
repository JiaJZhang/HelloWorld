﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;

namespace WinX.Windows.Controls
{
    public partial class TreeView : BaseElement
    {
        public TreeView(AutomationElement element) : base(element)
        {

        }

        public static SearchCondition ControlTypeCondition
        {
            get
            {
                return SearchCondition.ByControlType(ControlType.Tree);
            }
        }

        public TreeViewItem SelectedItem
        {
            get
            {
                var selectedElements = SelectionPattern.Current.GetSelection();
                if(selectedElements.Length == 1)
                {
                    return new TreeViewItem(selectedElements[0]);
                }
                return null;
            }
        }

        private SelectionPattern SelectionPattern
        {
            get
            {
                return this.GetPattern<SelectionPattern>();
            }
        }

    }
}
