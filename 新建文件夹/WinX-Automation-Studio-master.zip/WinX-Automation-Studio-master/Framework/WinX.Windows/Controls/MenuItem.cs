﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;

namespace WinX.Windows.Controls
{
    public partial class MenuItem : AbstractMenuItem , IInvoke , IExpandCollapse
    {
        protected readonly IInvoke invokeServant;
        protected readonly IExpandCollapse expandCollapseServant;
        protected readonly IToggle toggleServant;

        public MenuItem(AutomationElement element) : base(element)
        {
            invokeServant = new InvokeImpl(this);
            expandCollapseServant = new ExpandCollapseImpl(this);
            toggleServant = new ToggleImpl(this);
        }

        public static SearchCondition ControlTypeCondition
        {
            get
            {
                return SearchCondition.ByControlType(ControlType.MenuItem);
            }
        }

        public bool IsExpanded
        {
            get
            {
                return expandCollapseServant.IsExpanded;
            }

            set
            {
                expandCollapseServant.IsExpanded = value;
            }
        }

        public bool IsChecked
        {
            get
            {
                return this.toggleServant.IsOn;
            }
        }


        public void Click()
        {
            this.invokeServant.Click();
        }

        public void Toggle()
        {
            this.toggleServant.Toggle();
        }

        public void Check()
        {
            if(!this.toggleServant.IsOn)
            {
                this.toggleServant.Toggle();
            }
        }

        public void UnCheck()
        {
            if (!this.toggleServant.IsOff)
            {
                this.toggleServant.Toggle();
            }
        }

        public void Expand()
        {
            this.expandCollapseServant.Expand();
        }

        public override MenuItem[] GetAllMenuItems()
        {
            try
            {
                this.Expand();
            }
            catch(OperationNotSupportedException ex)
            {

            }

            return base.GetAllMenuItems();
        }

        public void Collapse()
        {
            this.expandCollapseServant.Collapse();
        }

        public override MenuItem GetMenuItem(string automationId)
        {
            try
            {
                this.Expand();
            }
            catch (OperationNotSupportedException ex)
            {

            }

            return base.GetMenuItem(automationId);
        }
    }
}
