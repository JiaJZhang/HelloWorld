﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;

namespace WinX.Windows.Controls
{
    public partial class DataGrid_WpfToolKit : AbstractDataGrid
    {
        public DataGrid_WpfToolKit(AutomationElement element) : base(element)
        {

        }


        public static SearchCondition ControlTypeCondition
        {
            get
            {
                return SearchCondition.ByControlType(ControlType.DataGrid).And(SearchCondition.ByClassName("DataGrid"));
            }
        }

        public DataGridRow_WpfToolkit[] Rows
        {
            get
            {
                return this.GetRows<DataGridRow_WpfToolkit>();
            }
        }

        public DataGridCell_WpfToolkit this[int row, int column]
        {
            get
            {
                return this.GetCell<DataGridCell_WpfToolkit>(row, column);
            }
        }
    }
}
