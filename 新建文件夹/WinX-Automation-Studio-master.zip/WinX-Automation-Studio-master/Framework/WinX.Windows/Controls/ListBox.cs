﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;

namespace WinX.Windows.Controls
{
    public partial class ListBox : BaseElement
    {
        public ListBox(AutomationElement element) : base(element)
        {
        }

        public static SearchCondition ControlTypeCondition
        {
            get
            {
                return SearchCondition.ByControlType(ControlType.List);
            }
        }

        public ListBoxItem[] SelectedItems
        {
            get
            {
                var selectedItems = new List<ListBoxItem>();
                var items = this.Items;
                foreach (var item in items)
                {
                    if (item.IsSelected)
                    {
                        selectedItems.Add(item);
                    }
                }
                return selectedItems.ToArray();
            }
        }

        public ListBoxItem[] Items
        {
            get
            {
                return this.GetAll<ListBoxItem>();
            }
        }

        public ListBoxItem this[string value]
        {
            get
            {
                return this.GetItem(value);
            }
        }

        public ListBoxItem this[int index]
        {
            get
            {
                return GetItem(index);
            }
        }

        public ListBoxItem GetItem(string value)
        {
            var item = this.Get<ListBoxItem>(SearchCondition.ByName(value));
            return item;
        }

        public bool Contains(string value)
        {
            var contains = false;
            try
            {
                var item = this.Get<ListBoxItem>(SearchCondition.ByName(value));
                if (item != null)
                {
                    contains = true;
                }
            }
            catch(Exception ex)
            {

            }
            return false;
        }

        public ListBoxItem GetItem(int index)
        {
            try
            {
                var items = this.Items;
                return items[index];
            }
            catch(IndexOutOfRangeException ex)
            {
                throw new ElementNotFoundException("No listbox - item found with the index " + index);
            }
        }
    }
}
