﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;

namespace WinX.Windows.Controls
{
    public partial class ToggleButton : BaseElement , IToggle
    {
        private readonly IToggle toggleServant;

        public ToggleButton(AutomationElement element) : base(element)
        {
            toggleServant = new ToggleImpl(this);
        }

        public static SearchCondition ControlTypeCondition
        {
            get
            {
                return SearchCondition.ByControlType(ControlType.Button);
            }
        }

        public bool IsOff
        {
            get
            {
                return this.toggleServant.IsOff;
            }
        }
        public bool IsOn
        {
            get
            {
                return this.toggleServant.IsOn;
            }
        }

        public bool IsIndeterminate
        {
            get
            {
                return this.toggleServant.IsIndeterminate;
            }
        }


        public void Toggle()
        {
            this.toggleServant.Toggle();
        }
    }
}
