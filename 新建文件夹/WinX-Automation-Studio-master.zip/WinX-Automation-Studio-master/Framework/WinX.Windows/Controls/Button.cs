﻿using System;
using System.Windows.Automation;


namespace WinX.Windows.Controls
{
    public class Button : BaseElement, IInvoke
    {
        private readonly IInvoke invokeServant;

        public Button(AutomationElement automationElement) : base(automationElement)
        {
            this.invokeServant = new InvokeImpl(this);
        }

        public static SearchCondition ControlTypeCondition
        {
            get
            {
                return SearchCondition.ByControlType(ControlType.Button);
            }
        }

        public string TextValue
        {
            get
            {
                return Name;
            }
        }
        
        public void Click()
        {
            this.invokeServant.Click();
        }
    }
}
