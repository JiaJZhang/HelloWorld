﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;

namespace WinX.Windows.Controls
{
    public class ComboBox : BaseElement , IExpandCollapse
    {
        private readonly IExpandCollapse expandCollapseServant;

        public ComboBox(AutomationElement automationElement) : base(automationElement)
        {
            this.expandCollapseServant = new ExpandCollapseImpl(this);
        }

        public static SearchCondition ControlTypeCondition
        {
            get
            {
                return SearchCondition.ByControlType(ControlType.ComboBox);
            }
        }

        public bool IsExpanded
        {
            get
            {
                return this.expandCollapseServant.IsExpanded;
            }
            set
            {
                this.expandCollapseServant.IsExpanded = value;
            }
        }

        public ComboBoxItem SelectedItem
        {
            get
            {
                var items = this.GetAll<ComboBoxItem>();
                ComboBoxItem selectedItem = null;
                foreach (var item in items)
                {
                    if (item.IsSelected)
                    {
                        selectedItem = item;
                        break;
                    }
                }
                return selectedItem;
            }
        }

        public ComboBoxItem[] Items
        {
            get
            {
                return this.GetAll<ComboBoxItem>();
            }
        }

        public ComboBoxItem this[string value]
        {
            get
            {
                return this.GetItem(value);
            }
        }

        public ComboBoxItem this[int index]
        {
            get
            {
                return this.GetItem(index);
            }
        }

        public ComboBoxItem GetItem(string value)
        {
            var item = this.Get<ComboBoxItem>(SearchCondition.ByName(value));
            if(!item.IsEnabled())
            {
                this.Expand();
            }
            return item;
        }

        public void Expand()
        {
            this.expandCollapseServant.Expand();
        }

        public void Collapse()
        {
            this.expandCollapseServant.Collapse();
        }

        public bool Contains(string value)
        {
            bool contains = false;
            try
            {
                var item = this.Get<ComboBoxItem>(SearchCondition.ByName(value));
                if(item != null)
                {
                    contains = true;
                }
            }
            catch(Exception ex)
            {

            }
            return contains;
        }


        public ComboBoxItem GetItem(int index)
        {
            try
            {
                var items = this.Items;
                var item = items[index];
                if (!item.IsEnabled())
                {
                    this.Expand();
                }
                return item;
            }
            catch(Exception ex)
            {
                throw new ElementNotFoundException("No commbobox - item found with the index " + index);
            }
        }

    }
}
