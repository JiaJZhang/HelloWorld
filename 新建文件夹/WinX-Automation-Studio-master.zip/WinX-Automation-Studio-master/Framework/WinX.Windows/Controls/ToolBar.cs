﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;

namespace WinX.Windows.Controls
{
    public partial class ToolBar : BaseElement
    {

        public ToolBar(AutomationElement element) : base(element)
        {

        }

        public static SearchCondition ControlTypeCondition
        {
            get
            {
                return SearchCondition.ByControlType(ControlType.ToolBar);
            }
        }

        public bool IsExpanded
        {
            get
            {
                return this.GetTogglePattern().Current.ToggleState == ToggleState.On;
            }
            set
            {
                if(value != this.IsExpanded)
                {
                    this.GetTogglePattern().Toggle();
                }
            }
        }

        public void Expand()
        {
            this.IsExpanded = true;
        }

        public void Collapse()
        {
            this.IsExpanded = false;
        }

        public T GetItem<T>(string automationId) where T : BaseElement
        {
            T item;
            try
            {
                item = this.Get<T>(automationId);
            }
            catch(ElementNotFoundException ex)
            {
                if(this.IsExpanded)
                {
                    throw;
                }

                var parentWindow = this.GetParentWindow();
                item = parentWindow.Get<T>(automationId);
            }

            if(item == null)
            {
                throw new ElementNotFoundException("Could not find any element with the AutomationId " + automationId);
            }
            return item;
        }

        private TogglePattern GetTogglePattern()
        {
            return this.Get<Button>("OverflowButton").GetPattern<TogglePattern>();
        }

    }
}
