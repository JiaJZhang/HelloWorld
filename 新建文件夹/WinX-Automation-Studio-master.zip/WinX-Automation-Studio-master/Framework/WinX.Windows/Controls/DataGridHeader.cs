﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;

namespace WinX.Windows.Controls
{
    public partial class DataGridHeader : BaseElement
    {
        public DataGridHeader(AutomationElement automationElement) : base(automationElement)
        {
        }

        public static SearchCondition ControlTypeCondition
        {
            get
            {
                return SearchCondition.ByControlType(ControlType.Header);
            }
        }

        public int ColumnCount
        {
            get
            {
                return this.GetAll<DataGridHeaderItem>().Length;
            }
        }

        public DataGridHeaderItem[] HeaderCoumns
        {
            get
            {
                return this.GetAll<DataGridHeaderItem>();
            }
        }

        public DataGridHeaderItem this[string columnName]
        {
            get
            {
                return this.Get<DataGridHeaderItem>(SearchCondition.ByName(columnName));
            }
        }

        public DataGridHeaderItem this[int columnIndex]
        {
            get
            {
                return this.GetAll<DataGridHeaderItem>()[columnIndex];
            }
        }
    }
}
