﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;

namespace WinX.Windows.Controls
{
    public partial class RadioButton : BaseElement , ISelectionItemSimple
    {
        private readonly ISelectionItemSimple selectionTiemServant;

        public RadioButton(AutomationElement element) : base(element)
        {
            selectionTiemServant = new SelectionItemImpl(this);
        }

        public static SearchCondition ControlTypeCondition
        {
            get
            {
                return SearchCondition.ByControlType(ControlType.RadioButton);
            }
        }

        public bool IsSelected
        {
            get
            {
                return this.selectionTiemServant.IsSelected;
            }
        }

        public void Select()
        {
            this.selectionTiemServant.Select();
        }
    }
}
