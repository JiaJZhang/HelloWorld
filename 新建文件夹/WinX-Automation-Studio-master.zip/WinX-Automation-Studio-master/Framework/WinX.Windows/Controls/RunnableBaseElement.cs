﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Windows.Automation;
using System.Windows.Media.Animation;
using System.Windows.Threading;

namespace WinX.Windows.Controls
{
    public abstract partial class RunnableBaseElement : BaseElement , IRunnableEntity
    {
        private static readonly int CloseModalWindowsTimeout = AppConfigImpl.Instance.CloseModalWindowsTimeout;
        private System.Threading.Thread thread;

        public RunnableBaseElement(AutomationElement automationElement) : base(automationElement)
        {
        }

        public void Stop()
        {
            this.Stop(false);
        }

        public void Stop(bool closeModalWindows)
        {
            if (closeModalWindows)
            {
                Action action = () => this.CloseOpenElements();
                Action timeoutAction = () => { throw new TimeoutException(); };
                action.Run(timeoutAction, CloseModalWindowsTimeout);
            }

            if(this.thread != null)
            {
                try
                {
                    var windowDispatcher = Dispatcher.FromThread(this.thread);
                    if(windowDispatcher != null)
                    {
                        windowDispatcher.InvokeShutdown();
                    }
                    else
                    {
                        this.thread.Abort();
                    }
                    this.thread.Join();
                }
                catch(Exception ex)
                {

                }
                finally
                {
                    this.thread = null;
                }
            }
        }

        protected static T Start<T>(Func<System.Windows.Window> function) where T : RunnableBaseElement
        {
            T runnableBaseElement = null;
            try
            {
                var windowNameSetEvent = new ManualResetEvent(false);
                var windowName = string.Empty;
                var localThread = new Thread(() =>
                {
                    var window = function.Invoke();
                    try
                    {
                        windowName = window.Title;
                        window.Close();
                        windowNameSetEvent.Set();
                        try
                        {
                            Dispatcher.Run();
                        }
                        catch (AnimationException)
                        {

                        }
                    }
                    catch (ThreadAbortException)
                    {
                        Dispatcher.CurrentDispatcher.InvokeShutdown();
                    }

                });

                localThread.SetApartmentState(ApartmentState.STA);
                localThread.Start();
                windowNameSetEvent.WaitOne();
                var automationWindow = GetWindowByName(windowName);
                automationWindow.SetFocus();
                var constrInfo = GetConstructorInfo(typeof(T), automationWindow.AutomationElement);
                runnableBaseElement = (T)constrInfo.Invoke(new object[] { automationWindow.AutomationElement });
                runnableBaseElement.thread = localThread;
            }
            catch(Exception ex)
            {

            }
            return runnableBaseElement;
        }

        protected static ConstructorInfo GetConstructorInfo(Type type,params object[] constructorParameters)
        {
            ConstructorInfo constructorInfo = null;
            if(constructorParameters.Length  > 0)
            {
                var paramTypes = new Type[constructorParameters.Length];
                for(int i = 0; i< constructorParameters.Length;i++)
                {
                    var paramType = constructorParameters[i].GetType();
                    paramTypes[i] = paramType;
                }
                constructorInfo = type.GetConstructor(paramTypes);
            }
            else
            {
                constructorInfo = type.GetConstructor(new Type[0]);
            }

            if(constructorInfo == null)
            {
                throw new NoConstructorFoundException("No constructor for the given parameter was found");
            }

            return constructorInfo;
        }


        protected abstract void CloseOpenElements();


        private static Window GetWindowByName(string name)
        {
            var searchCondition = SearchCondition.ByName(name).And(SearchCondition.ByControlType(ControlType.Window));
            return searchCondition.GetWindowBySearchCondition();
        }
    }
}
