﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;

namespace WinX.Windows.Controls
{
    public partial class DatePicker : BaseElement, IExpandCollapse
    {
        private readonly IExpandCollapse expandCollapseServant;
        private readonly TextBox valueTextBox;


        public DatePicker(AutomationElement element) : base(element)
        {
            expandCollapseServant = new ExpandCollapseImpl(this);
            valueTextBox = this.Get<TextBox>("Part_TextBox");
        }

        public static SearchCondition ControlTypeCondition
        {
            get
            {
                return SearchCondition.ByControlType(ControlType.Custom).And(SearchCondition.ByClassName("DatePicker"));
            }
        }

        public DateTime Date
        {
            get
            {
                try
                {
                    var tmpValue = this.ValuePattern.Current.Value;
                    var value = DateTime.Parse(tmpValue);
                    return value;
                }
                catch (FormatException ex)
                {
                    throw new OperationNotSupportedException("Could not get the date." + ex.Message);
                }
            }
            set
            {
                try
                {
                    this.ValuePattern.SetValue(value.ToLongDateString());
                }
                catch (ElementNotEnabledException ex)
                {
                    throw new OperationNotSupportedException(ex.Message);
                }
            }
        }

        public string TextValue
        {
            get
            {
                return this.valueTextBox.Value;
            }
        }


        public bool IsExpanded
        {
            get
            {
                return this.expandCollapseServant.IsExpanded;
            }

            set
            {
                this.expandCollapseServant.IsExpanded = value;
            }
        }

        private ValuePattern ValuePattern
        {
            get
            {
                return this.GetPattern<ValuePattern>();
            }
        }

        public bool TryGetDate(out DateTime dateTime)
        {
            bool result;
            try
            {
                var tmpValue = this.ValuePattern.Current.Value;
                dateTime = DateTime.Parse(tmpValue);
                result = true;
            }
            catch (Exception ex)
            {
                result = false;
                dateTime = new DateTime();
            }
            return result;
        }

        public void Collapse()
        {
            this.expandCollapseServant.Collapse();
        }

        public void Expand()
        {
            this.expandCollapseServant.Expand();
        }
    }
}
