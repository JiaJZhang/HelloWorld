﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;

namespace WinX.Windows.Controls
{
    public partial class SaveFileDialog : BaseElement
    {
        public SaveFileDialog(AutomationElement element) : base(element)
        {

        }

        public static SearchCondition ControlTypeCondition
        {
            get
            {
                return SearchCondition.ByControlType(ControlType.Window).And(SearchCondition.ByClassName("#32770"));
            }
        }

        private string FilePath
        {
            set
            {
                var comboBox = this.Get<ComboBox>("1148");
                var textBox = comboBox.Get<TextBox>("1148");
                textBox.Value = value;
            }
        }

        public void Save(string filePath)
        {
            this.FilePath = filePath;
            this.Save();
        }

        public void Cancel()
        {
            this.Get<Button>("2").Click();
        }

        public void Save()
        {
            this.Get<Button>("1").Click();
        }
    }
}
