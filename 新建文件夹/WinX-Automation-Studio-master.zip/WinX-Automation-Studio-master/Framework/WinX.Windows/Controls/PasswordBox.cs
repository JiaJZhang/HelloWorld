﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;

namespace WinX.Windows.Controls
{
    public partial class PasswordBox : TextBox
    {
        public PasswordBox(AutomationElement element) : base(element)
        {

        }

        public static SearchCondition ControlTypeCondition
        {
            get
            {
                return SearchCondition.ByControlType(ControlType.Edit).And(SearchCondition.ByClassName("PasswordBox"));
            }
        }

        public new string Value
        {
            set
            {
                base.Value = value;
            }
        }
    }
}
