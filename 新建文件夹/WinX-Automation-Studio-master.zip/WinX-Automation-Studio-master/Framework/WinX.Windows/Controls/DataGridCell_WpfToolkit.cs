﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;

namespace WinX.Windows.Controls
{
    public partial class DataGridCell_WpfToolkit : AbstractDataGridCell, IGridItem , ISelectionItemMulti
    {
        private readonly IGridItem gridItemServant;
        private readonly ISelectionItemMulti selectionItemServant;

        public DataGridCell_WpfToolkit(AutomationElement element) : base(element)
        {
            gridItemServant = new GridItemImpl(this);
            selectionItemServant = new SelectionItemImpl(this);
        }

        public static SearchCondition ControlTypeCondition
        {
            get
            {
                return SearchCondition.ByControlType(ControlType.Custom).And(SearchCondition.ByClassName("DataGridCell"));
            }
        }

        public int Column
        {
            get
            {
                return this.gridItemServant.Column;
            }
        }

        public int Row
        {
            get
            {
                return this.gridItemServant.Row;
            }
        }

        public int ColumnSpan
        {
            get
            {
                return this.gridItemServant.ColumnSpan;
            }
        }

        public int RowSpan
        {
            get
            {
                return this.gridItemServant.RowSpan;
            }
        }

        public bool IsSelected
        {
            get
            {
                return this.selectionItemServant.IsSelected;
            }
            set
            {
                this.selectionItemServant.IsSelected = value;
            }
        }

        protected new string TextValue
        {
            get
            {
                return base.TextValue;
            }
            set
            {
                try
                {
                    this.GetNestedElement<Lable>();
                    this.DoubleClick();
                    this.GetNestedElement<TextBox>().Value = value;
                }
                catch(ElementNotAvailableException ex)
                {
                    throw new ElementNotFoundException("Could not set a text for the cell, since no nested Label / TextBox is available in this DataGridCell.");
                }
                finally
                {
                    System.Windows.Forms.SendKeys.SendWait("\r");
                }
            }
        }


        protected override string GetTextValue()
        {
            try
            {
                return GetNestedElement<Lable>().TextValue;
            }
            catch(ElementNotAvailableException ex)
            {
                throw new OperationNotSupportedException("Could not get the textual value of this cell, since there exists no nested Label.");
            }
        }


        public void AddToSelection()
        {
            this.selectionItemServant.AddToSelection();
        }

        public void Unselect()
        {
            this.selectionItemServant.Unselect();
        }

        public void Select()
        {
            this.selectionItemServant.Select();
        }

        public T GetNestedElement<T>() where T: BaseElement
        {
            var nestedElements = this.GetAll<T>();
            if(nestedElements.Length == 0)
            {
                throw new ElementNotAvailableException("There is not nested element of tyle \"" + typeof(T) + "\" inside the DataGrid-cell.");
            }
            return nestedElements[0];
        }
    }
}
