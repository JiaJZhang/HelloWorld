﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;

namespace WinX.Windows.Controls
{
    public partial class AbstractTreeView : BaseElement
    {
        public AbstractTreeView(AutomationElement element) : base(element)
        {

        }


        public virtual TreeViewItem[] Items
        {
            get
            {
                var searchCondition = SearchCondition.FromAutomationCondition(Condition.TrueCondition);
                searchCondition.Scope = TreeScope.Children;
                return GetAll<TreeViewItem>(searchCondition);
            }
        }

        public virtual TreeViewItem GetItem(string itemName)
        {
            return this.GetByName<TreeViewItem>(itemName);
        }

        public TreeViewItem this[string name]
        {
            get
            {
                return this.GetItem(name);
            }
        }

        public TreeViewItem this[int index]
        {
            get
            {
                return this.GetItem(index);
            }
        }


        public virtual TreeViewItem GetItem(int index)
        {
            try
            {
                var items = this.Items;
                var item = items[index];
                return item;
            }
            catch(IndexOutOfRangeException)
            {
                throw new ElementNotFoundException("No TreeViewItem found with the index " + index);
            }

        }
    }
}
