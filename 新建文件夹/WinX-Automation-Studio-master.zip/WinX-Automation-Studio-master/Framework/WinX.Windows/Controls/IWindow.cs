﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;

namespace WinX.Windows.Controls
{
    public interface IWindow: IBaseElement
    {
        MessageBox GetMessageBox(string name);

        SaveFileDialog GetSaveFileDialog(string name);

        SaveFileDialog GetSaveFileDialog();

        OpenFileDialog GetOpenFileDialog(string name);

        OpenFileDialog GetOpenFileDialog();

        void Maximize();

        void Close();

        void Minimize();

        void RecoverNormal();

        WindowVisualState GetVisualState();

        Menu GetMenu(string automationId);
    }
}
