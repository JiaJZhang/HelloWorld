﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;

namespace WinX.Windows.Controls
{
    public abstract partial class AbstractDataGridCell : BaseElement
    {
        public AbstractDataGridCell(AutomationElement element) : base(element)
        {

        }

        public string TextValue
        {
            get
            {
                return this.GetTextValue();
            }
        }

        protected abstract string GetTextValue();
    }
}
