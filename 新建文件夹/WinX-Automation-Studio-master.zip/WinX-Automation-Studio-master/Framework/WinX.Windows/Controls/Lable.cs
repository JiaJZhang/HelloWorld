﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;

namespace WinX.Windows.Controls
{
    public partial class Lable : BaseElement
    {
        public Lable(AutomationElement element) : base(element)
        {
        }

        public static SearchCondition ControlTypeCondition
        {
            get
            {
                return SearchCondition.ByControlType(ControlType.Text);
            }
        }

        public string TextValue
        {
            get
            {
                return this.AutomationElement.Current.Name;
            }
        }
    }
}
