﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;

namespace WinX.Windows.Controls
{
    public class Menu : BaseElement
    {
        public Menu(AutomationElement automationElement) : base(automationElement)
        {
        }

        public static SearchCondition ControlTypeCondition
        {
            get
            {
                return SearchCondition.ByControlType(ControlType.Menu);
            }
        }
    }
}
