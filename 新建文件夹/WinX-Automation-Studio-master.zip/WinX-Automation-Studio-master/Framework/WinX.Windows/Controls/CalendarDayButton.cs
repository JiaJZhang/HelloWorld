﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;

namespace WinX.Windows.Controls
{
    public class CalendarDayButton : BaseElement, ISelectionItemMulti
    {
        private readonly ISelectionItemMulti selectionItemServant;

        public CalendarDayButton(AutomationElement element): base(element)
        {

        }
        
        public static SearchCondition ControlTypeCondition
        {
            get
            {
                return SearchCondition.ByControlType(ControlType.Button).And(SearchCondition.ByClassName("CalendarDayButton"));
            }
        }

        public bool IsSelected
        {
            get
            {
                return this.selectionItemServant.IsSelected;
            }
            set
            {
                this.selectionItemServant.IsSelected = value;
            }
        }


        public void AddToSelection()
        {
            this.selectionItemServant.AddToSelection();
        }

        public void Select()
        {
            this.selectionItemServant.Select();
        }

        public void Unselect()
        {
            this.selectionItemServant.Unselect();
        }
    }
}
