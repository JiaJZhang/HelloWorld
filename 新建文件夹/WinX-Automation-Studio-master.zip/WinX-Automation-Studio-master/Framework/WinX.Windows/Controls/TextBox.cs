﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;

namespace WinX.Windows.Controls
{
    public partial class TextBox : BaseElement
    {
        public TextBox(AutomationElement element) : base(element)
        {

        }

        public static SearchCondition ControlTypeCondition
        {
            get
            {
                return SearchCondition.ByControlType(ControlType.Edit);
            }
        }

        public string Value
        {
            get
            {
                try
                {
                    return GetPattern<ValuePattern>().Current.Value;
                }
                catch(InvalidOperationException)
                {

                }
                return string.Empty;
            }
            set
            {
                try
                {
                    GetPattern<ValuePattern>().SetValue(value);
                }
                catch(InvalidOperationException)
                {

                }
            }
        }

        public bool IsReadOnly
        {
            get
            {
                return GetPattern<ValuePattern>().Current.IsReadOnly;
            }
        }
    }
}