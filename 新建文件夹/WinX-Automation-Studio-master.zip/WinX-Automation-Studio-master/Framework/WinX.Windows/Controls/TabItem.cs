﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;

namespace WinX.Windows.Controls
{
    public partial class TabItem : BaseElement,ISelectionItemSimple
    {
        private readonly ISelectionItemSimple selectionItemServant;

        public TabItem(AutomationElement element) : base(element)
        {
            selectionItemServant = new SelectionItemImpl(this);
        }

        public static SearchCondition ControlTypeCondition
        {
            get
            {
                return SearchCondition.ByControlType(ControlType.TabItem);
            }
        }

        public string Header
        {
            get
            {
                return this.automationElement.Current.Name;
            }
        }

        public bool IsSelected
        {
            get
            {
                return this.selectionItemServant.IsSelected;
            }
        }
        
        public void Select()
        {
            this.selectionItemServant.Select();
        }
    }
}
