﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;

namespace WinX.Windows.Controls
{
    public abstract partial class AbstractDataGridRow : BaseElement , ISelectionIetmSingle
    {

        private readonly ISelectionItemMulti selectionItemServant;

        public AbstractDataGridRow(AutomationElement element) : base(element)
        {
            this.selectionItemServant = new SelectionItemImpl(this);
        }

        public bool IsSelected
        {
            get
            {
                return this.selectionItemServant.IsSelected;
            }
            set
            {
                this.selectionItemServant.IsSelected = value;
            }
        }
        
        public void Select()
        {
            this.selectionItemServant.Select();
        }

        public void Unselect()
        {
            this.selectionItemServant.Unselect();
        }

        protected T[] GetCells<T>() where T : AbstractDataGridCell
        {
            return this.GetAll<T>();
        }
    }
}
