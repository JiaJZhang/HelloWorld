﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;

namespace WinX.Windows.Controls
{
    public partial class DataGridRow_WpfToolkit : AbstractDataGridRow
    {
        public DataGridRow_WpfToolkit(AutomationElement element) : base(element)
        {

        }

        public static SearchCondition ControlTypeCondition
        {
            get
            {
                return SearchCondition.ByControlType(ControlType.DataItem);
            }
        }

        public DataGridCell_WpfToolkit[] Cells
        {
            get
            {
                return this.GetCells<DataGridCell_WpfToolkit>();
            }
        }
    }
}
