﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;

namespace WinX.Windows.Controls
{
    public partial class AbstractMenuItem : BaseElement
    {
        public AbstractMenuItem(AutomationElement element) : base(element)
        {

        }

        public MenuItem this[string automationId]
        {
            get
            {
                return this.GetMenuItem(automationId);
            }
        }

        public virtual MenuItem[] GetAllMenuItems()
        {
            var searchCondition = SearchCondition.FromAutomationCondition(Condition.TrueCondition);
            searchCondition.Scope = TreeScope.Children;
            return GetAll<MenuItem>(searchCondition);
        }

        public virtual MenuItem GetMenuItem(string automationId)
        {
            var searchCondition = SearchCondition.FromAutomationCondition(Condition.TrueCondition);
            searchCondition.Scope = TreeScope.Children;
            searchCondition.And(SearchCondition.ByAutomationId(automationId));
            return Get<MenuItem>(searchCondition);
        }

    }
}
