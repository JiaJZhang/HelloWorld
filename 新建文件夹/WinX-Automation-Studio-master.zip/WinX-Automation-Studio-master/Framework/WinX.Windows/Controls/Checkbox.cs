﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;

namespace WinX.Windows.Controls
{

    public class Checkbox : BaseElement
    {
        private readonly IToggle toggleServant;

        public Checkbox(AutomationElement automationElement) : base(automationElement)
        {
            this.toggleServant = new ToggleImpl(this);
        }

        public static SearchCondition ControlTypeCondition
        {
            get
            {
                return SearchCondition.ByControlType(ControlType.CheckBox);
            }
        }

        public bool isChecked
        {
            get
            {
                return this.toggleServant.IsOn;
            }
        }


        public void Check()
        {
            if(!this.toggleServant.IsOn)
            {
                this.toggleServant.Toggle();
            }
        }

        public void UnCheck()
        {
            if (!this.toggleServant.IsOff)
            {
                this.toggleServant.Toggle();
            }
        }

        public void Toggle()
        {
            this.toggleServant.Toggle();
        }

    }
}
