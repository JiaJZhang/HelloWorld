﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;

namespace WinX.Windows.Controls
{
    public partial class DataGridCell_ListView : AbstractDataGridCell, IGridItem
    {
        private readonly IGridItem gridItemServant;

        public DataGridCell_ListView(AutomationElement element) : base(element)
        {
            gridItemServant = new GridItemImpl(this);
        }

        public static SearchCondition ControlTypeCondition
        {
            get
            {
                return SearchCondition.ByControlType(ControlType.Text);
            }
        }


        public int Column
        {
            get
            {
                return this.gridItemServant.Column;
            }
        }

        public int Row
        {
            get
            {
                return this.gridItemServant.Row;
            }
        }

        public int ColumnSpan
        {
            get
            {
                return this.gridItemServant.ColumnSpan;
            }
        }
        
        public int RowSpan
        {
            get
            {
                return this.gridItemServant.RowSpan;
            }
        }

        protected override string GetTextValue()
        {
            return this.Name;
        }
    }
}
