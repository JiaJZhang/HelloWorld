﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;

namespace WinX.Windows.Controls
{
    public partial class Expander : BaseElement, IExpandCollapse
    {
        private readonly IExpandCollapse expandCollapseServant;

        public Expander(AutomationElement element) : base(element)
        {
            expandCollapseServant = new ExpandCollapseImpl(this);
        }

        public static SearchCondition ControlTypeCondition
        {
            get
            {
                return SearchCondition.ByControlType(ControlType.Custom).And(SearchCondition.ByClassName("Expander"));
            }
        }

        public bool IsExpanded
        {
            get
            {
                return this.expandCollapseServant.IsExpanded;
            }

            set
            {
                this.expandCollapseServant.IsExpanded = value;
            }
        }

        public void Collapse()
        {
            this.expandCollapseServant.Collapse();
        }

        public void Expand()
        {
            this.expandCollapseServant.Expand();
        }
    }
}
