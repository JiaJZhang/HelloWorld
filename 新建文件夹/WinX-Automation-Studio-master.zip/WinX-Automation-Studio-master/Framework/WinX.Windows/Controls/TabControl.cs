﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;

namespace WinX.Windows.Controls
{
    public partial class TabControl : BaseElement
    {
        public TabControl(AutomationElement element) : base(element)
        {

        }

        public static SearchCondition ControlTypeCondition
        {
            get
            {
                return SearchCondition.ByControlType(ControlType.Tab);
            }
        }

        public TabItem SelectedTab
        {
            get
            {
                var selectionpattern = GetSelectionPattern();
                var automationElements = selectionpattern.Current.GetSelection();
                if(automationElements.Length == 1)
                {
                    return new TabItem(automationElements[0]);
                }
                else
                {
                    return null;
                }
            }
        }

        public TabItem[] AllTabs
        {
            get
            {
                return this.GetAll<TabItem>();
            }
        }

        public TabItem this[int index]
        {
            get
            {
                return this.GetTab(index);
            }
        }

        public TabItem this[string tagName]
        {
            get
            {
                return this.GetTab(tagName);
            }
        }

        public TabItem GetTab(int index)
        {
            try
            {
                var items = this.AllTabs;
                var item = items[index];
                return item;
            }
            catch(IndexOutOfRangeException ex)
            {
                throw new ElementNotFoundException("No TabItem found with the index " + index);
            }
        }

        public TabItem GetTab(string tagName)
        {
            return this.GetByName<TabItem>(tagName);
        }

        private SelectionPattern GetSelectionPattern()
        {
            return this.GetPattern<SelectionPattern>();
        }
    }
}