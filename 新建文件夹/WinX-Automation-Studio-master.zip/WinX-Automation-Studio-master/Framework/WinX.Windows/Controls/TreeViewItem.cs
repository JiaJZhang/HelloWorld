﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;

namespace WinX.Windows.Controls
{
    public partial class TreeViewItem : AbstractTreeView,IExpandCollapse
    {
        private readonly IExpandCollapse expandCollapseServant;

        public TreeViewItem(AutomationElement element) : base(element)
        {
            expandCollapseServant = new ExpandCollapseImpl(this);
        }

        public static SearchCondition ControlTypeCondition
        {
            get
            {
                return SearchCondition.ByControlType(ControlType.TreeItem);
            }
        }

        public string Header
        {
            get
            {
                return this.automationElement.Current.Name;
            }
        }

        public bool IsSelected
        {
            get
            {
                return this.SelectionItemPattern.Current.IsSelected;
            }
            set
            {
                if(value != this.IsSelected)
                {
                    if(value)
                    {
                        this.Select();
                    }
                    else
                    {
                        this.UnSelect();
                    }
                }
            }
        }

        public void Select()
        {
            if (!this.IsEnabled())
            {
                throw new OperationNotSupportedException("The element is disabled");
            }
            this.SelectionItemPattern.Select();
        }

        public void UnSelect()
        {
            this.SelectionItemPattern.RemoveFromSelection();
        }

        private SelectionItemPattern SelectionItemPattern
        {
            get
            {
                return this.GetPattern<SelectionItemPattern>();
            }
        }



        public bool IsExpanded
        {
            get
            {
                return this.expandCollapseServant.IsExpanded;
            }

            set
            {
                this.expandCollapseServant.IsExpanded = value;
            }
        }

        public override TreeViewItem[] Items
        {
            get
            {
                if(!this.IsExpanded)
                {
                    this.Expand();
                }
                return base.Items;
            }
        }

        public override TreeViewItem GetItem(string itemName)
        {
            if(!this.IsExpanded)
            {
                this.Expand();
            }
            return base.GetItem(itemName);
        }


        public void Collapse()
        {
            this.expandCollapseServant.Collapse();
        }

        public void Expand()
        {
            this.expandCollapseServant.Expand();
        }
    }
}
