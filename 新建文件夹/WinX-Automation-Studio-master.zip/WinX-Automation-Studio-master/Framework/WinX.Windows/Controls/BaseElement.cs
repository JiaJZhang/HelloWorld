﻿using System;
using System.Reflection;
using System.Windows;
using System.ComponentModel;
using System.Windows.Automation;
using WinX.Core;

namespace WinX.Windows.Controls
{
    public partial class BaseElement : GenericElement, IBaseElement
    {
        [NonSerialized]
        protected AutomationElement automationElement;

        [NonSerialized]
        private readonly TreeWalker walker = TreeWalker.ControlViewWalker;

        [NonSerialized]
        private static readonly BaseElement rootElement = new BaseElement(AutomationElement.RootElement);

        public BaseElement() { }
        public BaseElement(AutomationElement automationElement)
        {
            this.automationElement = automationElement;
        }
        public static BaseElement RootElement
        {
            get { return rootElement; }
        }
        public AutomationElement AutomationElement
        {
            get
            {
                return this.automationElement;
            }
        }
        public string GetToolTip()
        {
            try
            {
                if (this.automationElement != null)
                    return this.automationElement.Current.HelpText;
                else
                    return null;
            }
            catch (Exception)
            {
                return null;
            }

        }
        public ControlType GetControlType()
        {
            try
            {
                if (this.automationElement != null)
                    return this.automationElement.Current.ControlType;
                else
                    return null;
            }
            catch (Exception)
            {
                return null;
            }

        }
        public String GetElementName()
        {
            try
            {
                if (this.automationElement != null)
                    return this.automationElement.Current.Name;
                else
                    return null;
            }
            catch (Exception)
            {
                return null;
            }

        }
        public String GetAutomationId()
        {
            try
            {
                if (this.automationElement != null)
                    return this.automationElement.Current.AutomationId;
                else
                    return null;
            }
            catch (Exception)
            {
                return null;
            }

        }
        public bool IsEnabled()
        {
            try
            {
                if (this.automationElement != null)
                    return this.automationElement.Current.IsEnabled;
                else
                    return false;
            }
            catch (Exception)
            {
                return false;
            }

        }
        public bool IsOffscreen()
        {
            try
            {
                if (this.automationElement != null)
                    return this.automationElement.Current.IsOffscreen;
                else
                    return false;
            }
            catch (Exception)
            {
                return false;
            }

        }
        public IWindow GetParentWindow()
        {
            BaseElement parentElement;
            do
            {
                parentElement = this.GetParentElement();
                if (parentElement.AutomationElement == RootElement.AutomationElement)
                {
                    throw new OperationNotSupportedException("There is no parent window");
                }
            } while (parentElement.GetControlType() != ControlType.Window);
            IWindow parentWindow = new Window(parentElement.automationElement);
            return parentWindow;
        }
        public BaseElement GetParentElement()
        {
            try
            {
                AutomationElement node = this.automationElement;
                if (node != null)
                {
                    node = this.walker.GetParent(node);
                    BaseElement parent = new BaseElement(node);
                    return parent;
                }
            }
            catch (Exception)
            {

            }
            return null;
        }

        public void ClickLeft()
        {
            try
            {
                this.SetFocus();
                var point = this.automationElement.GetClickablePoint();
                WinX.Core.MouseHelper.DoMosuseLeftClick((int)point.X, (int)point.Y);
            }
            catch (Exception ex)
            {

            }
        }

        public void ClickRight()
        {
            try
            {
                this.SetFocus();
                var point = this.automationElement.GetClickablePoint();
                WinX.Core.MouseHelper.DoMouseRightClick((int)point.X, (int)point.Y);
            }
            catch (Exception ex)
            {

            }
        }

        public void DoubleClick()
        {
            try
            {
                this.SetFocus();
                var point = this.automationElement.GetClickablePoint();
                WinX.Core.MouseHelper.DoMosuseLeftClick((int)point.X, (int)point.Y);
                WinX.Windows.Delay.ForMilliseconds(10);
                WinX.Core.MouseHelper.DoMosuseLeftClick((int)point.X, (int)point.Y);
            }
            catch (Exception ex)
            {

            }
        }

        public void ClickSecureButton()
        {
            var hWnd = new IntPtr(this.automationElement.Current.NativeWindowHandle);
            User32.SetActiveWindow(hWnd);
            User32.SetFocus(hWnd);

            try
            {
                var rect = this.automationElement.Current.BoundingRectangle;
                if (rect != null)
                {
                    User32.SetCursorPos((int)rect.X + 5, (int)rect.Y + 5);
                    WinX.Core.MouseHelper.DoMosuseLeftClick((int)rect.X, (int)rect.Y);
                }
            }
            catch (Exception ex)
            {

            }
        }

        public void SetFocus()
        {
            try
            {
                this.automationElement.SetFocus();
            }
            catch (Exception)
            {
            }
            IntPtr hwnd = (IntPtr)this.automationElement.Current.NativeWindowHandle;
            User32.SetForegroundWindow(hwnd);
            User32.SetFocus(hwnd);
        }
        public BaseElement Get(string automationId)
        {
            return BaseElementFactory.GetBaseElement(this, SearchCondition.ByAutomationId(automationId));
        }

        public BaseElement Get(SearchCondition condition)
        {
            return BaseElementFactory.GetBaseElement(this, condition);
        }
        public BaseElement GetByName(string name)
        {
            return BaseElementFactory.GetBaseElement(this, SearchCondition.ByName(name));
        }
        public BaseElement[] GetAll(SearchCondition condition)
        {
            return BaseElementFactory.GetAllBaseElements(this, condition);
        }

        public T Get<T>(SearchCondition condition) where T : BaseElement
        {
            return BaseElementFactory.GetBaseElement<T>(this, condition);
        }

        public T[] GetAll<T>() where T : BaseElement
        {
            return BaseElementFactory.GetAllBaseElements<T>(this);
        }

        public T Get<T>(string automationId) where T : BaseElement
        {
            return BaseElementFactory.GetBaseElement<T>(this, SearchCondition.ByAutomationId(automationId));
        }
        public T GetByName<T>(string name) where T : BaseElement
        {
            return BaseElementFactory.GetBaseElement<T>(this, SearchCondition.ByName(name));
        }

        public T[] GetAll<T>(SearchCondition condition) where T : BaseElement
        {
            return BaseElementFactory.GetAllBaseElements<T>(this, condition);
        }

        public T GetPattern<T>() where T : BasePattern
        {
            try
            {
                FieldInfo fieldInfo = typeof(T).GetField("Pattern");
                AutomationPattern value = (AutomationPattern)fieldInfo.GetValue(null);
                T pattern = (T)this.automationElement.GetCurrentPattern(value);
                return pattern;
            }
            catch (Exception ex)
            {
                throw new OperationNotSupportedException(ex.Message);
            }
        }
    }
}