﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;

namespace WinX.Windows.Controls
{
    public partial class DataGridRow_ListView : AbstractDataGridRow
    {
        public DataGridRow_ListView(AutomationElement element) : base(element)
        {

        }

        public static SearchCondition ControlTypeCondition
        {
            get
            {
                return SearchCondition.ByControlType(ControlType.DataItem);
            }
        }

        public DataGridCell_ListView[] Cells
        {
            get
            {
                return this.GetCells<DataGridCell_ListView>();
            }
        }
    }
}
