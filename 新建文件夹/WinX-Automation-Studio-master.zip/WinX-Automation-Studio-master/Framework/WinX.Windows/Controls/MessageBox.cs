﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;

namespace WinX.Windows.Controls
{
    public partial class MessageBox : BaseElement
    {

        public MessageBox(AutomationElement element) : base(element)
        {
        }

        public static SearchCondition ControlTypeCondition
        {
            get
            {
                return SearchCondition.ByControlType(ControlType.Window);
            }
        }

        public enum EMessageBoxType
        {
            OK,
            OK_CANCEL,
            YES_NO,
            YES_NO_CANCEL,
            UNKNOWN
        }

        public string Text
        {
            get
            {
                var allLabels = BaseElementFactory.GetAllBaseElements<Lable>(this);
                return allLabels[0].TextValue;
            }
        }

        public Button[] Buttons
        {
            get
            {
                return BaseElementFactory.GetAllBaseElements<Button>(this);
            }
        }

        public EMessageBoxType MessageBoxType
        {
            get
            {
                var result = EMessageBoxType.UNKNOWN;
                var buttons = new List<Button>(this.Buttons);

                switch (buttons.Count - 1)
                {
                    case 1:
                        result = EMessageBoxType.OK;
                        break;
                    case 2:
                        bool existsOk = buttons.Exists(b => b.GetAutomationId() == "1");
                        bool existsCancel = buttons.Exists(b => b.GetAutomationId() == "2");

                        if(existsOk && existsCancel )
                        {
                            result = EMessageBoxType.OK_CANCEL;
                        }
                        else
                        {
                            result = EMessageBoxType.YES_NO;
                        }
                        break;
                    case 3:
                        result = EMessageBoxType.YES_NO_CANCEL;
                        break;
                }

                return result;
            }
        }

        public void OK()
        {
            if(this.MessageBoxType == EMessageBoxType.OK)
            {
                this.Get<Button>(SearchCondition.ByAutomationId("2")).Click();
            }
            else if (this.MessageBoxType == EMessageBoxType.OK_CANCEL)
            {
                this.Get<Button>(SearchCondition.ByAutomationId("1")).Click();
            }
            else
            {
                throw new OperationNotSupportedException("Invalid MessageBoxType " + this.MessageBoxType);
            }
        }

        public void Cancel()
        {
            if (this.MessageBoxType == EMessageBoxType.OK_CANCEL || this.MessageBoxType == EMessageBoxType.YES_NO_CANCEL)
            {
                this.Get<Button>(SearchCondition.ByAutomationId("2")).Click();
            }
            else
            {
                throw new OperationNotSupportedException("Invalid MessageBoxType " + this.MessageBoxType);
            }
        }

        public void Yes()
        {
            if (this.MessageBoxType == EMessageBoxType.YES_NO || this.MessageBoxType == EMessageBoxType.YES_NO_CANCEL)
            {
                this.Get<Button>(SearchCondition.ByAutomationId("6")).Click();
            }
            else
            {
                throw new OperationNotSupportedException("Invalid MessageBoxType " + this.MessageBoxType);
            }
        }

        public void No()
        {
            if (this.MessageBoxType == EMessageBoxType.YES_NO || this.MessageBoxType == EMessageBoxType.YES_NO_CANCEL)
            {
                this.Get<Button>(SearchCondition.ByAutomationId("7")).Click();
            }
            else
            {
                throw new OperationNotSupportedException("Invalid MessageBoxType " + this.MessageBoxType);
            }
        }
    }
}
