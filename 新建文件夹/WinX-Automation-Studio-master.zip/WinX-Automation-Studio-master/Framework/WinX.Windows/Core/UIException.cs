﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WinX.Windows
{
    public partial class UIException : Exception
    {
        public UIException(string message):base(message)
        {

        }

    }
}
