﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Automation;
using System.Windows.Forms;
using WinX.Core;

namespace WinX.Windows
{
    public static partial class PatternExtensions
    {
        public static AutomationElement FindChildAt(this AutomationElement parent, int index)
        {
            if (index < 0)
            {
                throw new ArgumentOutOfRangeException();
            }

            var walker = TreeWalker.RawViewWalker;
            var child = walker.GetFirstChild(parent);
            for (int i = 0; i < index; i++)
            {
                child = walker.GetNextSibling(child);
                if (child == null)
                {
                    throw new ArgumentOutOfRangeException();
                }
            }
            return child;
        }


        public static AutomationElement FindChildAtB(this AutomationElement parent, int index)
        {
            var findCondition = new PropertyCondition(AutomationElement.IsControlElementProperty, true);
            var found = parent.FindAll(TreeScope.Children, findCondition);
            if (index < 0 || index >= found.Count)
            {
                throw new ArgumentOutOfRangeException();
            }
            return found[index];
        }

        public static void WalkEnabledElements(this AutomationElement rootElement, TreeNode treeNode)
        {
            var condition1 = new PropertyCondition(AutomationElement.IsContentElementProperty, true);
            var condition2 = new PropertyCondition(AutomationElement.IsEnabledProperty, true);
            var walker = new TreeWalker(new AndCondition(condition1, condition2));
            var elementNode = walker.GetFirstChild(rootElement);
            while(elementNode != null)
            {
                var childTreeNode = treeNode.Nodes.Add(elementNode.Current.ControlType.LocalizedControlType);
                WalkEnabledElements(elementNode, childTreeNode);
                elementNode = walker.GetNextSibling(elementNode);
            }
        }

        public static AutomationElement GetTopLevelWindow(AutomationElement element)
        {
            var walker = TreeWalker.ControlViewWalker;
            AutomationElement elementParent;
            var node = element;
            if(node == AutomationElement.RootElement)
            {
                return node;
            }
            do
            {
                elementParent = walker.GetParent(node);
                if (elementParent == AutomationElement.RootElement)
                {
                    break;
                }
                node = elementParent;
            } while (true);

            return node;
        }
        

        public static Bitmap GetBitmap(this AutomationElement ae)
        {
            var bitmap = new DisplayItem(new IntPtr(ae.Current.NativeWindowHandle));
            return bitmap.GetVisibleImage();
        }

        public static string GetValue(this AutomationElement element)
        {
            var pattern = element.GetPattern<ValuePattern>(ValuePattern.Pattern);
            return pattern.Current.Value;
        }

        public static void SetValue(this AutomationElement element,string value)
        {
            var pattern = element.GetPattern<ValuePattern>(ValuePattern.Pattern);
            pattern.SetValue(value);
        }

        public static InvokePattern GetInvokePattern(this AutomationElement element)
        {
            return element.GetPattern<InvokePattern>(InvokePattern.Pattern);
        }


        public static T GetPattern<T>(this AutomationElement element, AutomationPattern pattern) where T : class
        {
            var patternObject = element.GetCurrentPattern(pattern);
            return patternObject as T;
        }
    }
}
