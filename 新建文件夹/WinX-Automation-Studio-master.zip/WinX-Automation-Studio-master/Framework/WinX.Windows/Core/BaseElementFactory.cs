﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;
using WinX.Windows.Controls;

namespace WinX.Windows
{
    public static class BaseElementFactory
    {

        public static BaseElement GetBaseElement(BaseElement parent, SearchCondition condition)
        {
            var automationElement = AutomationElementFinder.FindFirst(parent, condition);
            var BaseElement = new BaseElement(automationElement);
            return BaseElement;
        }

        public static BaseElement[] GetAllBaseElements(BaseElement parent, SearchCondition condition)
        {
            var BaseElements = new List<BaseElement>();
            try
            {
                var automationElementCollection = AutomationElementFinder.FindAll(parent, condition);
                foreach (AutomationElement automationElement in automationElementCollection)
                {
                    BaseElements.Add(new BaseElement(automationElement));
                }
            }
            catch (ElementNotFoundException)
            {

            }
            return BaseElements.ToArray();
        }

        public static BaseElement[] GetAllBaseElements(BaseElement parent)
        {
            var BaseElements = new List<BaseElement>();
            try
            {
                var automationElementCollection = AutomationElementFinder.FindAll(parent);
                foreach (AutomationElement automationElement in automationElementCollection)
                {
                    BaseElements.Add(new BaseElement(automationElement));
                }

            }
            catch (ElementNotFoundException)
            {

            }
            return BaseElements.ToArray();
        }

        public static T GetBaseElement<T>(BaseElement parent, SearchCondition condition) where T : BaseElement
        {
            var controlTypeCondition = ControlTypeDirectory.GetConditionForType<T>();
            var searchCondition = condition.And(controlTypeCondition);
            var automationElement = AutomationElementFinder.FindFirst(parent, condition);
            if (automationElement != null)
            {
                T element = (T)typeof(T).GetConstructor(new Type[] { typeof(AutomationElement)})
                    .Invoke(new object[] { automationElement });
                return element;
            }
            return null;
        }

        public static T[] GetAllBaseElements<T>(BaseElement parent, SearchCondition condition) where T : BaseElement
        {
            var baseElements = new List<T>();

            var controlTypeCondition = ControlTypeDirectory.GetConditionForType<T>();
            var searchCondition = condition.And(controlTypeCondition);
            try
            {
                var automationElementCollection = AutomationElementFinder.FindAll(parent, condition);
                foreach (AutomationElement automationElement in automationElementCollection)
                {
                    T element = (T)typeof(T).GetConstructor(new Type[] { typeof(AutomationElement) })
                        .Invoke(new object[] { automationElement });
                    baseElements.Add(element);
                }
            }
            catch (ElementNotFoundException)
            {

            }
            return baseElements.ToArray();
        }

        public static T[] GetAllBaseElements<T>(BaseElement parent) where T : BaseElement
        {
            var baseElements = new List<T>();
            var controlTypeCondition = ControlTypeDirectory.GetConditionForType<T>();
            try
            {
                var automationElementCollection = AutomationElementFinder.FindAll(parent, controlTypeCondition);
                foreach (AutomationElement automationElement in automationElementCollection)
                {
                    T element = (T)typeof(T).GetConstructor(new Type[] { typeof(AutomationElement) })
                        .Invoke(new object[] { automationElement });
                    baseElements.Add(element);
                }
            }
            catch (ElementNotFoundException)
            {

            }
            return baseElements.ToArray();
        }
    }
}
