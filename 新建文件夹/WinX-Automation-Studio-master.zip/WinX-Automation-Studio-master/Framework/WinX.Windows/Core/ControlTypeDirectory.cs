﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows.Automation;
using WinX.Windows.Controls;

namespace WinX.Windows
{
    public static class ControlTypeDirectory
    {

        public static SearchCondition GetConditionForType<T>() where T : BaseElement
        {
            var fieldInfo = typeof(T).GetProperty("controlTypeCondition");
            var controlTypeCondition = (SearchCondition)fieldInfo.GetValue(null, null);
            return controlTypeCondition;
        }

    }
}
