﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;
using WinX.Windows.Controls;

namespace WinX.Windows
{
    public static class AutomationElementFinder
    {
        private const int Timeout = 1500;

        //private static readonly AppConfigImpl Configuration = new AppConfigImpl();

        private const int FindSleep = 100;


        public static AutomationElement FindFirst(this BaseElement parent, SearchCondition searchConditon)
        {
            var condition = searchConditon.CreateCondition();
            var root = parent.AutomationElement;
            AutomationElement result = null;

            Action doAction = () =>
            {
                while(result == null)
                {
                    try
                    {
                        result = root.FindFirst(searchConditon.Scope, condition);
                    }
                    catch(Exception ex)
                    {

                    }
                    FindSleep.ForMilliseconds();
                }
            };

            Action timeOutAction = () =>
            {
                WinX.Core.Logger.Write("Could not find AutomationElement with the SearchCondition " + condition);
            };

            doAction.Run(timeOutAction, Timeout);
            return result;
        }
        
        public static AutomationElementCollection FindAll(this BaseElement parent, SearchCondition searchConditon)
        {
            var condition = searchConditon.CreateCondition();
            var root = parent.AutomationElement;
            AutomationElementCollection result = null;

            Action doAction = () =>
            {
                while (result == null || result.Count == 0)
                {
                    try
                    {
                        result = root.FindAll(searchConditon.Scope, condition);
                    }
                    catch (Exception ex)
                    {

                    }
                    FindSleep.ForMilliseconds();
                }
            };

            Action timeOutAction = () =>
            {
                WinX.Core.Logger.Write("Could not find AutomationElement with the SearchCondition " + condition);
            };

            doAction.Run(timeOutAction, Timeout);
            return result;
        }

        public static AutomationElementCollection FindAll(this BaseElement parent)
        {
            var searchCondition = SearchCondition.FromAutomationCondition(Condition.TrueCondition);
            return FindAll(parent, searchCondition);
        }
    }
}
