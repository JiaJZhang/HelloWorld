﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WinX.Windows
{
    public static partial class Clock
    {
        public static void Run(this Action action, Action timeOutAction, int timeout)
        {
            var result = action.BeginInvoke(null, null);
            if (result.AsyncWaitHandle.WaitOne(timeout))
            {
                action.EndInvoke(result);
            }
            else
            {
                timeOutAction.Invoke();
            }
        }
    }
}
