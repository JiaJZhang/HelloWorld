﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WinX.Windows
{
    public class OperationNotSupportedException: UIException
    {
        public OperationNotSupportedException(string message):base(message)
        {

        }
    }
}
