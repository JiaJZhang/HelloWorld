﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;
using WinX.Core;

namespace WinX.Windows
{
    public partial class SearchCondition
    {
        public readonly List<Condition> Conditions;

        private TreeScope scope;

        public SearchCondition(List<MatchRule> matchRules)
        {
            this.scope = TreeScope.Descendants;
            this.Conditions = fromMatchRules(matchRules).Conditions;
        }


        public SearchCondition(List<Condition> conditions)
        {
            this.scope = TreeScope.Descendants;
            this.Conditions = conditions;
        }

        public static SearchCondition fromMatchRules(List<MatchRule> matchRules)
        {
            var conditionList = new List<Condition>();
            foreach (var rule in matchRules)
            {
                if (object.ReferenceEquals(rule.GetType(), typeof(ControlIdMatchRule)))
                {
                    var cmr = rule as ControlIdMatchRule;
                    var propCond = new PropertyCondition(AutomationElement.AutomationIdProperty, cmr.AutomationId);
                    conditionList.Add(propCond);
                }
                else if (object.ReferenceEquals(rule.GetType(), typeof(ControlNameMatchRule)))
                {
                    var cmr = rule as ControlNameMatchRule;
                    var propCond = new PropertyCondition(AutomationElement.NameProperty, cmr.ElementName);
                    conditionList.Add(propCond);
                }
                else if (object.ReferenceEquals(rule.GetType(), typeof(ControlClassMatchRule)))
                {
                    var cmr = rule as ControlClassMatchRule;
                    var propCond = new PropertyCondition(AutomationElement.ClassNameProperty, (cmr.Comparer as WinX.Core.StringComparer).ComparisonValue);
                    conditionList.Add(propCond);
                }
                else if (object.ReferenceEquals(rule.GetType(), typeof(LocalizedControlTypeMatchRule)))
                {
                    var cmr = rule as LocalizedControlTypeMatchRule;
                    var propCond = new PropertyCondition(AutomationElement.LocalizedControlTypeProperty, cmr.LocalizedControlType);
                    conditionList.Add(propCond);
                }
                else if (object.ReferenceEquals(rule.GetType(), typeof(WindowTitleMatchRule)))
                {
                    var cmr = rule as WindowTitleMatchRule;
                    var propCond = new PropertyCondition(AutomationElement.NameProperty, (cmr.Comparer as WinX.Core.StringComparer).ComparisonValue);
                    conditionList.Add(propCond);
                }
            }

            if (conditionList.Count > 0)
            {
                return new SearchCondition(conditionList);
            }

            throw new Exception("Search condition is null");
        }

        public SearchCondition(Condition condition)
        {
            this.scope = TreeScope.Descendants;
            this.Conditions = new List<Condition> { condition };
        }

        public TreeScope Scope
        {
            get
            {
                return this.scope;
            }
            set
            {
                this.scope = value;
            }
        }

        public static SearchCondition ByAutomationId(string automationId)
        {
            return ByAutomationProperty(AutomationElement.ControlTypeProperty, automationId);
        }

        public static SearchCondition ByClassName(string className)
        {
            return ByAutomationProperty(AutomationElement.ClassNameProperty, className);
        }

        public static SearchCondition ByName(string className)
        {
            return ByAutomationProperty(AutomationElement.NameProperty, className);
        }

        public static SearchCondition ByControlType(ControlType controlType)
        {
            return ByAutomationProperty(AutomationElement.ControlTypeProperty, controlType);
        }

        public static SearchCondition ByProcessId(int processId)
        {
            return ByAutomationProperty(AutomationElement.ProcessIdProperty, processId);
        }

        public static SearchCondition ByAutomationProperty(AutomationProperty property, object value)
        {
            var condition = new PropertyCondition(property, value);
            return new SearchCondition(condition);
        }

        public static SearchCondition FromAutomationCondition(Condition condition)
        {
            return new SearchCondition(condition);
        }

        public SearchCondition And(SearchCondition searchCondition)
        {
            var condition = searchCondition.CreateCondition();
            this.Conditions.Add(condition);
            return this;
        }

        public Condition CreateCondition()
        {
            Condition condition = null;

            if (this.Conditions.Count > 0)
            {
                condition = new AndCondition(this.Conditions.ToArray());
            }
            else
            {
                condition = this.Conditions[0];
            }

            return condition;
        }
    }
}
