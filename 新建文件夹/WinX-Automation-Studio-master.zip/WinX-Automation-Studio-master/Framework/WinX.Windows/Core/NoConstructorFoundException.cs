﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WinX.Windows
{
    public partial class NoConstructorFoundException : UIException
    {
        public NoConstructorFoundException(string message) : base(message)
        {

        }
    }
}
