﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WinX.Windows
{
    public static partial class Delay
    {
        public static void ForSeconds(this double seconds)
        {
            int milliseconds = Convert.ToInt32(seconds * 1000);
            ForMilliseconds(milliseconds);
        }

        public static void ForMilliseconds(this int milliseconds)
        {
            System.Threading.Thread.Sleep(milliseconds);
        }
    }
}
