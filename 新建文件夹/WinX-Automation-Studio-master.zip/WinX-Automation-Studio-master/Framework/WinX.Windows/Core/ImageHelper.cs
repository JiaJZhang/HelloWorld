﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Automation;
using System.Windows.Media.Imaging;

namespace WinX.Windows
{
    public static partial class ImageHelper
    {
        public static BitmapImage BitmapToImageSource(this Bitmap src)
        {
            using (var ms = new MemoryStream())
            {
                ((System.Drawing.Bitmap)src).Save(ms, System.Drawing.Imaging.ImageFormat.Bmp);
                var image = new BitmapImage();
                image.BeginInit();
                ms.Seek(0, SeekOrigin.Begin);
                image.StreamSource = ms;
                image.EndInit();
                return image;
            }
        }


        public static void BringWindowFront(AutomationElement win)
        {
            var winH = new IntPtr(win.Current.NativeWindowHandle);
            var winP = new Core.WINDOWPLACEMENT();
            if (Core.User32.GetWindowPlacement(winH, out winP))
            {
                if (winP.showCmd == 2)// if Minimized
                {
                    Core.User32.ShowWindow(winH, 1);
                }
            }
            Core.User32.SetForegroundWindow(winH);
            Core.User32.SetForegroundWindow(winH);

            System.Threading.Thread.Sleep(600);
        }

        public static Bitmap TakeScreenshot(AutomationElement win)
        {
            var bounds = System.Windows.Forms.Screen.GetBounds(System.Drawing.Point.Empty);
            int h = (int)win.Current.BoundingRectangle.Height;
            int w = (int)win.Current.BoundingRectangle.Width;
            var bitmap = new Bitmap(w, h);

            int top = (int)win.Current.BoundingRectangle.Top;
            int left = (int)win.Current.BoundingRectangle.Left;

            if (top < 0)
            {
                top = 0;
            }
            if (left < 0)
            {
                left = 0;
            }

            using (var g = Graphics.FromImage(bitmap))
            {
                System.Threading.Thread.Sleep(600);
                g.CopyFromScreen(left, top, 0, 0, new System.Drawing.Size((int)win.Current.BoundingRectangle.Width, (int)win.Current.BoundingRectangle.Height));
            }

            return bitmap;
        }

        public static BitmapImage Base64ToImage(this string base64)
        {
            var bytes = Convert.FromBase64String(base64);
            using (var stream = new MemoryStream(bytes))
            {
                var bi = new BitmapImage();
                bi.BeginInit();
                bi.CreateOptions = BitmapCreateOptions.None;
                bi.CacheOption = BitmapCacheOption.OnLoad;
                bi.StreamSource = stream;
                bi.EndInit();
                return bi;
            }
        }

        // BitmapImage --> Bitmap
        public static Bitmap BitmapImageToBitmap(this BitmapImage bitmapImage)
        {
            // BitmapImage bitmapImage = new BitmapImage(new Uri("../Images/test.png", UriKind.Relative));

            using (MemoryStream outStream = new MemoryStream())
            {
                BitmapEncoder enc = new BmpBitmapEncoder();
                enc.Frames.Add(BitmapFrame.Create(bitmapImage));
                enc.Save(outStream);
                Bitmap bitmap = new Bitmap(outStream);

                return new Bitmap(bitmap);
            }
        }


    }
}
