﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Automation;
using WinX.Core;
using WinX.Windows.Controls;

namespace WinX.Windows
{
    public static class WindowsHelper
    {
        public static Controls.Window GetWindowBySearchCondition(this SearchCondition searchCondition,int TimeOutInSec = 30)
        {
            Controls.Window window = null;
            Action action = () =>
            {
                try
                {
                    searchCondition.Scope = TreeScope.Children;

                    do
                    {
                        try
                        {
                            window = BaseElementFactory.GetBaseElement<Window>(BaseElement.RootElement, searchCondition);
                        }
                        catch (ElementNotFoundException)
                        {

                        }
                    } while (window != null);

                }
                catch (Exception ex)
                {
                    throw new ElementNotFoundException("Cound not find Window with the SearchCondition " + searchCondition.ToString() + "," + ex.Message);
                }
            };

            Action timeOutAction = () =>
            {
                throw new ElementNotFoundException("Cound not find Window with the SearchCondition " + searchCondition.ToString());
            };

            action.Run(timeOutAction, TimeOutInSec * 1000);
            return window;
        }


        public static List<WinX.Windows.Controls.Window> GetActiveWindows()
        {
            var lstWindows = new List<WinX.Windows.Controls.Window>();
            var rootElement = AutomationElement.RootElement;
            var winCollection = rootElement.FindAll(TreeScope.Children, Condition.TrueCondition);
            var curProcIdD = Process.GetCurrentProcess().Id;

            foreach(AutomationElement ele in winCollection)
            {
                try
                {
                    var proc = Process.GetProcessById(ele.Current.ProcessId);
                    if (curProcIdD != ele.Current.ProcessId)
                    {
                        lstWindows.Add(new WinX.Windows.Controls.Window(ele));
                    }
                }
                catch(Exception ex)
                {

                }
            }
            return lstWindows;
        }

        public static List<IntPtr> GetWindowHandles()
        {
            var windows = new List<IntPtr>();

            var searchData = new Win32Helper.FindChildDialog.SearchData();

            WinX.Core.Win32Helper.FindChildDialog.EnumWindows((hWnd, lParam) =>
            {
                int size = User32.GetWindowTextLength(hWnd);
                if (size++ > 0 && User32.IsWindowVisible(hWnd))
                {
                    windows.Add(hWnd);
                }
                return true;
            }, IntPtr.Zero);

            return windows;
        }

        public static RawWindow GetRawWindowFromHandle(this IntPtr hWnd)
        {
            return new RawWindow()
            {
                Handler = hWnd,
                Title = GetWindowText(hWnd),
                Class = GetClassName(hWnd),
                Location = GetWindowLocation(hWnd),
                ProcessName = GetProcessName(hWnd)
            };
        }

        public static List<RawWindow> GetAllWindows()
        {
            var windows = new List<RawWindow>();
            WinX.Core.Win32Helper.FindChildDialog.EnumWindows((hWnd, lParam) =>
            {
                int size = User32.GetWindowTextLength(hWnd);

                if (size++ > 0 && User32.IsWindowVisible(hWnd))
                {
                    var childern = new List<RawWindow>();

                    var window = new RawWindow()
                    {
                        Handler = hWnd,
                        Title = GetWindowText(hWnd),
                        Class = GetClassName(hWnd),
                        Location = GetWindowLocation(hWnd),
                        ProcessName = GetProcessName(hWnd)
                    };

                    var phWnd = GetParentSafe(hWnd);

                    if (phWnd != IntPtr.Zero)
                    {
                        window.Parent = new RawWindow()
                        {
                            Handler = phWnd,
                            Title = GetWindowText(phWnd),
                            Class = GetClassName(phWnd),
                            Location = GetWindowLocation(phWnd),
                            ProcessName = GetProcessName(phWnd)
                        };
                    }

                    var gphWnd = GetParentSafe(phWnd);
                    if (gphWnd != IntPtr.Zero)
                    {
                        window.Parent.Parent = new RawWindow()
                        {
                            Handler = gphWnd,
                            Title = GetWindowText(gphWnd),
                            Class = GetClassName(gphWnd),
                            Location = GetWindowLocation(gphWnd),
                            ProcessName = GetProcessName(gphWnd)
                        };
                        gphWnd = IntPtr.Zero;
                    }
                    phWnd = IntPtr.Zero;
                    windows.Add(window);
                }
                return true;
            }, IntPtr.Zero);

            return windows;
        }
        
        public static string GetWindowText(this IntPtr hWnd)
        {
            int size = User32.GetWindowTextLength(hWnd);
            if (size++ > 0)
            {
                var builder = new StringBuilder(size);
                User32.GetWindowText(hWnd, builder, builder.Capacity);
                var rsult = builder.ToString();
                return rsult;
            }
            return string.Empty;
        }

        public static string GetClassName(this IntPtr hWnd)
        {
            var builder = new StringBuilder();
            User32.GetClassName(hWnd, builder, builder.Capacity);
            return builder.ToString();
        }

        public static Rectangle GetWindowLocation(this IntPtr hWnd)
        {
            if(hWnd != IntPtr.Zero)
            {
                var rect = new Rectangle();
                User32.GetWindowRect(hWnd, ref rect);
                return rect;
            }
            return Rectangle.Empty;
        }

        public static string GetProcessName(this IntPtr hWnd)
        {
            if(hWnd != IntPtr.Zero)
            {
                int processID;
                User32.GetWindowThreadProcessId(hWnd, out processID);
                var p = Process.GetProcessById(processID);
                return p.ProcessName;
            }
            return string.Empty;
        }

        public static IntPtr GetParentSafe(this IntPtr handle)
        {
            var result = new IntPtr(User32.GetParent(handle));
            if(result == IntPtr.Zero)
            {

            }
            return result;
        }
        
        public static void SetFocus(this IntPtr hWnd)
        {
            if (Win16Helper.GetWindowState(hWnd) != Win16Helper.WindowState.Normal)
            {
                Win16Helper.ShowWindow(hWnd, Win16Helper.WindowState.Normal);
                System.Threading.Thread.Sleep(500);
            }

            WinX.Core.User32.SetForegroundWindow(hWnd);
            WinX.Core.User32.SetActiveWindow(hWnd);
            WinX.Core.User32.SetFocus(hWnd);
        }

        public static void SendKeys(this IntPtr Hwnd, string keys)
        {
            Hwnd.SetFocus();
            System.Threading.Thread.Sleep(100);
            System.Windows.Forms.SendKeys.Send(keys);
        }

        public static void SendKeysWait(this IntPtr Hwnd, string keys)
        {
            Hwnd.SetFocus();
            System.Threading.Thread.Sleep(100);
            System.Windows.Forms.SendKeys.SendWait(keys);
        }
    }
}
