﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using WinX.Core;

namespace WinX.Windows
{
    [DisplayName("Window")]
    [TypeConverter(typeof(OptionsConverter))]
    [Serializable()]
    public partial class RawWindow
    {
        public IntPtr Handler
        {
            get; set;
        }

        public string Title
        {
            get; set;
        }

        public string Class
        {
            get; set;
        }

        public string ProcessName
        {
            get; set;
        }

        public Rectangle Location
        {
            get; set;
        }

        public RawWindow Parent
        {
            get; set;
        }
    }
}
