﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;
using System.Windows.Forms;
using WinX.Core;
using WinX.Windows.Controls;

namespace WinX.Windows
{
    public static partial class AutomationExtns
    {
        public static AutomationElement FindFirst(this AutomationElement parent, TreeScope searchScope, Condition searchConditon, int TimeOutInSec)
        {
            AutomationElement result = null;
            if (TimeOutInSec == 0)
            {
                TimeOutInSec = 30;
            }

            Action action = () =>
            {
                while (result == null)
                {
                    try
                    {
                        result = parent.FindFirst(searchScope, searchConditon);
                    }
                    catch (Exception ex)
                    {

                    }
                    System.Threading.Thread.Sleep(500);
                }
            };

            Action timeOutAction = () =>
            {
                WinX.Core.Logger.Write("Could not find AutomationElement with the SearchCondition .");
            };

            action.Run(timeOutAction, TimeOutInSec * 1000);
            return result;
        }

        //public static System.Drawing.Rectangle GetRect(this AutomationElement automationElement)
        //{
        //    var winRect = new System.Drawing.Rectangle();

        //    if (automationElement != null)
        //    {
        //        WinX.Core.User32.GetWindowRect(new IntPtr(automationElement.Current.NativeWindowHandle), ref winRect);

        //    }

        //    return winRect;
        //}

        public static string TakeScreenshotBase64(this AutomationElement automationElement)
        {
            var bitmap = TakeScreenshotBitMap(automationElement);
            var result = string.Empty;
            if (bitmap != null)
            {
                using (var ms = new System.IO.MemoryStream())
                {
                    bitmap.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                    var byteImage = ms.ToArray();
                    result = Convert.ToBase64String(byteImage);
                }
                bitmap.Dispose();
            }
            return result;
        }

        public static System.Drawing.Bitmap TakeScreenshotBitMap(this AutomationElement automationElement)
        {
            System.Drawing.Bitmap bitmap = null;
            if (automationElement != null)
            {
                var bounds = System.Windows.Forms.Screen.GetBounds(System.Drawing.Point.Empty);
                int h = (int)automationElement.Current.BoundingRectangle.Height;
                int w = (int)automationElement.Current.BoundingRectangle.Width;


                int top = (int)automationElement.Current.BoundingRectangle.Top;
                int left = (int)automationElement.Current.BoundingRectangle.Left;

                if (top < 0)
                {
                    top = 0;
                }
                if (left < 0)
                {
                    left = 0;
                }

                bitmap = new System.Drawing.Bitmap(w, h);

                using (var g = System.Drawing.Graphics.FromImage(bitmap))
                {
                    g.CopyFromScreen(left, top, 0, 0, new System.Drawing.Size((int)automationElement.Current.BoundingRectangle.Width, (int)automationElement.Current.BoundingRectangle.Height));
                }
            }

            return bitmap;
        }

        public static void BringWindowFront(this int handleId)
        {
            if (handleId > 0)
            {
                var hwnd = new IntPtr(handleId);
                var winP = new Core.WINDOWPLACEMENT();
                if (Core.User32.GetWindowPlacement(hwnd, out winP))
                {
                    if (winP.showCmd == 2)// if Minimized
                    {
                        Core.User32.ShowWindow(hwnd, 1);
                    }
                }

                //User32.SetActiveWindow(hwnd);
                User32.SetForegroundWindow(hwnd);
                User32.SetForegroundWindow(hwnd);
                //User32.SetFocus(hwnd);

                System.Threading.Thread.Sleep(300);
            }
        }

        public static AutomationElementCollection FindAll(this AutomationElement parent, TreeScope searchScope, Condition searchConditon, int TimeOutInSec)
        {
            AutomationElementCollection result = null;
            if (TimeOutInSec == 0)
            {
                TimeOutInSec = 30;
            }

            Action action = () =>
            {
                while (result == null)
                {
                    try
                    {
                        result = parent.FindAll(searchScope, searchConditon);
                    }
                    catch (Exception ex)
                    {

                    }
                    System.Threading.Thread.Sleep(500);
                }
            };

            Action timeOutAction = () =>
            {
                WinX.Core.Logger.Write("Could not find AutomationElement with the SearchCondition .");
            };

            action.Run(timeOutAction, TimeOutInSec * 1000);
            return result;
        }

        public static BaseElement GetWinXGenericControl(this AutomationElement ele)
        {
            var controlType = ele.GetCurrentPropertyValue(AutomationElement.ControlTypeProperty, true) as ControlType;

            if(controlType.Equals(ControlType.Button))
            {
                return new WinX.Windows.Controls.Button(ele);
            }
            else if (controlType.Equals(ControlType.Hyperlink))
            {
                return new WinX.Windows.Controls.Hyperlink(ele);
            }
            else if (controlType.Equals(ControlType.Text))
            {
                return new WinX.Windows.Controls.Lable(ele);
            }
            else if (controlType.Equals(ControlType.CheckBox))
            {
                return new WinX.Windows.Controls.Checkbox(ele);
            }
            else if (controlType.Equals(ControlType.ComboBox))
            {
                return new WinX.Windows.Controls.ComboBox(ele);
            }
            else if (controlType.Equals(ControlType.DataGrid))
            {
                return new WinX.Windows.Controls.DataGridRow_ListView(ele);
            }
            else if (controlType.Equals(ControlType.Document))
            {
                return new WinX.Windows.Controls.TextBox(ele);
            }
            else if (controlType.Equals(ControlType.Edit))
            {
                return new WinX.Windows.Controls.TextBox(ele);
            }
            else if (controlType.Equals(ControlType.Group))
            {
                return new WinX.Windows.Controls.Expander(ele);
            }
            else if (controlType.Equals(ControlType.Header))
            {
                return new WinX.Windows.Controls.DataGridHeader(ele);
            }
            else if (controlType.Equals(ControlType.HeaderItem))
            {
                return new WinX.Windows.Controls.DataGridHeaderItem(ele);
            }
            else if (controlType.Equals(ControlType.List))
            {
                return new WinX.Windows.Controls.ListBox(ele);
            }
            else if (controlType.Equals(ControlType.ListItem))
            {
                return new WinX.Windows.Controls.ListBoxItem(ele);
            }
            else if (controlType.Equals(ControlType.Menu) || controlType.Equals(ControlType.MenuBar))
            {
                return new WinX.Windows.Controls.Menu(ele);
            }
            else if (controlType.Equals(ControlType.MenuItem))
            {
                return new WinX.Windows.Controls.MenuItem(ele);
            }
            else if (controlType.Equals(ControlType.RadioButton))
            {
                return new WinX.Windows.Controls.RadioButton(ele);
            }
            else if (controlType.Equals(ControlType.ScrollBar))
            {
                return new WinX.Windows.Controls.ScrollBar(ele);
            }
            else if (controlType.Equals(ControlType.Slider))
            {
                return new WinX.Windows.Controls.Slider(ele);
            }
            else if (controlType.Equals(ControlType.StatusBar))
            {
                return new WinX.Windows.Controls.StatusBar(ele);
            }
            else if (controlType.Equals(ControlType.Tab))
            {
                return new WinX.Windows.Controls.TabControl(ele);
            }
            else if (controlType.Equals(ControlType.TabItem))
            {
                return new WinX.Windows.Controls.TabItem(ele);
            }
            else if (controlType.Equals(ControlType.ToolBar))
            {
                return new WinX.Windows.Controls.ToolBar(ele);
            }
            else if (controlType.Equals(ControlType.Tree))
            {
                return new WinX.Windows.Controls.TreeView(ele);
            }
            else if (controlType.Equals(ControlType.TreeItem))
            {
                return new WinX.Windows.Controls.TreeViewItem(ele);
            }
            else if (controlType.Equals(ControlType.Window))
            {
                return new WinX.Windows.Controls.Window(ele);
            }
            else if (controlType.Equals(ControlType.Calendar))
            {
                return new WinX.Windows.Controls.Calendar(ele);
            }
            else if (controlType.Equals(ControlType.Custom))
            {
                return new WinX.Windows.Controls.CustomControl(ele);
            }

            return new Controls.BaseElement(ele);
        }
        
        public static AutomationElement FindChildElementByName(this AutomationElement rootElement, string controlName)
        {
            if (string.IsNullOrEmpty(controlName) || rootElement == null)
            {
                throw new ArgumentException("Argument cannot be null or empty.");
            }

            var propCondition = new PropertyCondition(AutomationElement.NameProperty, controlName, PropertyConditionFlags.IgnoreCase);
            return rootElement.FindFirst(TreeScope.Descendants, propCondition);
        }

        public static AutomationElement FindChildElementByID(this AutomationElement rootElement, string controlId)
        {
            if (string.IsNullOrEmpty(controlId) || rootElement == null)
            {
                throw new ArgumentException("Argument cannot be null or empty.");
            }

            var propCondition = new PropertyCondition(AutomationElement.AutomationIdProperty, controlId, PropertyConditionFlags.IgnoreCase);
            return rootElement.FindFirst(TreeScope.Descendants, propCondition);
        }

        public static AutomationElement FindChildAt(this AutomationElement parent, int index)
        {
            if (index < 0)
            {
                throw new ArgumentOutOfRangeException();
            }

            var walker = TreeWalker.RawViewWalker;
            var child = walker.GetFirstChild(parent);
            if (child != null)
            {
                for (int x = 0; x < index; x++)
                {
                    child = walker.GetNextSibling(child); ;
                    if (child == null)
                    {
                        throw new ArgumentOutOfRangeException();
                    }
                }
                return child;
            }

            return null;
        }

        public static void WalkEnabledElemnets(this AutomationElement rootElement, TreeNode treeNode)
        {
            var condition1 = new PropertyCondition(AutomationElement.IsControlElementProperty, true);
            var condition2 = new PropertyCondition(AutomationElement.IsEnabledProperty, true);

            var walker = new TreeWalker(new AndCondition(condition1, condition2));
            var elementNode = walker.GetFirstChild(rootElement);
            while (elementNode != null)
            {
                var childTreeNode = treeNode.Nodes.Add(elementNode.Current.ControlType.LocalizedControlType);
                WalkEnabledElemnets(elementNode, childTreeNode);
                elementNode = walker.GetNextSibling(elementNode);
            }
        }

        public static AutomationElement GetTopLevelWindow(this AutomationElement element)
        {
            var walker = TreeWalker.ControlViewWalker;
            var elementParent = default(AutomationElement);
            var node = element;
            if (node != AutomationElement.RootElement)
            {

                do
                {
                    elementParent = walker.GetParent(node);
                    if (elementParent == AutomationElement.RootElement)
                    {
                        break;
                    }
                    node = elementParent;
                } while (true);
            }
            return node;
        }

        public static AutomationElement GetParent(this AutomationElement ae)
        {
            var walker = TreeWalker.RawViewWalker;
            var result = walker.GetParent(ae);
            return result;
        }

        public static int GetIndex(this AutomationElement ae)
        {
            var parent = GetParent(ae);
            if (parent != null)
            {
                var childern = GetChildren(parent);
                if (childern != null && childern.Count >= 0)
                {
                    var index = childern.IndexOf(ae);
                    return index;
                }
            }
            return 100;
        }


        public static List<AutomationElement> GetChildren(this AutomationElement element)
        {
            var viewWalker = new TreeWalker(System.Windows.Automation.Automation.ControlViewCondition);
            var lstChildren = new List<AutomationElement>();

            if (element != null)
            {
                var elementNode = viewWalker.GetFirstChild(element);

                do
                {
                    if (elementNode == null)
                    {
                        break;
                    }
                    lstChildren.Add(elementNode);
                    elementNode = viewWalker.GetNextSibling(elementNode);
                } while (true);
            }

            return lstChildren;
        }

        public static void WalkControlElements(this AutomationElement rootElement, ref TreeNode treeNode)
        {
            var elementNode = TreeWalker.ControlViewWalker.GetFirstChild(rootElement);
            while (elementNode != null)
            {
                var childTreeNode = treeNode.Nodes.Add(elementNode.Current.ControlType.LocalizedControlType + "[" + elementNode.Current.AutomationId + "]");
                WalkControlElements(elementNode, ref childTreeNode);
                elementNode = TreeWalker.ControlViewWalker.GetNextSibling(elementNode);
            }
        }

        public static AutomationElement ParentWindow(this AutomationElement element)
        {
            var walker = TreeWalker.ControlViewWalker;
            var elementParent = default(AutomationElement);
            var node = element;

            if (node == AutomationElement.RootElement)
            {
                return node;
            }
            else
            {
                do
                {
                    elementParent = walker.GetParent(node);
                    if (elementParent == AutomationElement.RootElement)
                    {
                        break;
                    }
                    node = elementParent;
                } while (true);
            }
            return node;
        }

        public static Stack<AutomationElement> RootStack(this AutomationElement element)
        {
            var stack = new Stack<AutomationElement>();
            var walker = TreeWalker.ControlViewWalker;
            var elementParent = default(AutomationElement);
            var node = element;

            if (node == AutomationElement.RootElement)
            {
                stack.Push(node);
            }
            else
            {
                stack.Push(node);

                do
                {
                    elementParent = walker.GetParent(node);
                    if (elementParent == AutomationElement.RootElement)
                    {
                        break;
                    }
                    node = elementParent;
                    stack.Push(node);
                } while (true);
            }
            return stack;
        }

        public static IEnumerable<Condition> CreateConditionPathForPrepertyValues(this AutomationProperty property,IEnumerable<object> values)
        {
            var conditions = values.Select(s => new PropertyCondition(property, s));
            return conditions.Cast<Condition>();
        }
        
    }
}
