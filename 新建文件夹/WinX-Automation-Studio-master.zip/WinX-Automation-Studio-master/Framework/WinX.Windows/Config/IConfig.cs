﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WinX.Windows
{
    public interface IConfig
    {
        int ElementTimeout
        {
            get;
        }

        int WindowTimeout
        {
            get;
        }

        int CloseModalWindowsTimeout
        {
            get;
        }

        string GetLocalizedName(ElementIdentifier element);
    }
}
