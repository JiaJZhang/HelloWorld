﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WinX.Windows
{
    public enum ElementIdentifier
    {
        OPEN_FILE_DEFAULT_TITLE,
        SAVE_FILE_DEFAULT_TITLE
    }
}
