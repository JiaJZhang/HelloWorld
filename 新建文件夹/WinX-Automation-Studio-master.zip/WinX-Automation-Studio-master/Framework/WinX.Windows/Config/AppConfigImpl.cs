﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WinX.Windows
{
    public partial class AppConfigImpl : IConfig
    {
        private static readonly object LockObject = new object();
        private static AppConfigImpl instance;


        public static AppConfigImpl Instance
        {
            get
            {
                lock (LockObject)
                {
                    if (instance == null)
                    {
                        instance = new AppConfigImpl();
                    }
                    return instance;
                }
            }
        }



        public int CloseModalWindowsTimeout
        {
            get
            {
                return 1500;
            }
        }

        public int ElementTimeout
        {
            get
            {
                return 15000;
            }
        }

        public int WindowTimeout
        {
            get
            {
                return 5000;
            }
        }

        public string GetLocalizedName(ElementIdentifier element)
        {
            return LocalStrings.ResourceManager.GetString(element.ToString());
        }
    }
}
