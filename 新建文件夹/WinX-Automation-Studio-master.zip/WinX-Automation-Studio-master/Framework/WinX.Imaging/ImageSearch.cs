﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using Emgu.CV.Structure;

namespace WinX.Imaging
{
    public class ImageSearch
    {
        public static Rectangle Search(Bitmap img,Bitmap temImage,bool SearchAsGrayScale = false,double Threashold =0.9f)
        {
            if (SearchAsGrayScale)
            {
                using (var source = new Emgu.CV.Image<Gray, byte>(img))
                {
                    using (var template = new Emgu.CV.Image<Gray, byte>(temImage))
                    {
                        using (var result = source.MatchTemplate(template, Emgu.CV.CvEnum.TemplateMatchingType.CcoeffNormed))
                        {
                            double[] minValues, maxValues;
                            Point[] minLocations, maxLocations;

                            result.MinMax(out minValues, out maxValues, out minLocations, out maxLocations);

                            if (maxValues[0] >= Threashold)
                            {
                                var match = new Rectangle(maxLocations[0], template.Size);
                                return match;
                            }
                        }
                    }
                }
            }
            else
            {
                using (var source = new Emgu.CV.Image<Gray, byte>(img))
                {
                    using (var template = new Emgu.CV.Image<Gray, byte>(temImage))
                    {
                        using (var result = source.MatchTemplate(template, Emgu.CV.CvEnum.TemplateMatchingType.CcoeffNormed))
                        {
                            double[] minValues, maxValues;
                            Point[] minLocations, maxLocations;

                            result.MinMax(out minValues, out maxValues, out minLocations, out maxLocations);

                            if (maxValues[0] >= Threashold)
                            {
                                var match = new Rectangle(maxLocations[0], template.Size);
                                return match;
                            }
                        }
                    }
                }
            }

            return new Rectangle(0, 0, 0, 0);
        }

    }
}
