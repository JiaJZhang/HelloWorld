﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Windows.Media.Imaging;

namespace WinX.Imaging
{
    public partial class Compress
    {
        public static Bitmap CompressAsBitmap(Bitmap bitmap)
        {
            var jpgEncoder = GetEncoder(ImageFormat.Jpeg);
            var myEndcoder = System.Drawing.Imaging.Encoder.Quality;

            var myEncoderParameters = new EncoderParameters(1);

            var myEncoderParameter = new EncoderParameter(myEndcoder, 10L);
            myEncoderParameters.Param[0] = myEncoderParameter;

            using (var m = new MemoryStream())
            {
                bitmap.Save(m, jpgEncoder, myEncoderParameters);
                return new Bitmap(Image.FromStream(m));
            }
        }

        public static BitmapImage CompressAsBitmapImage(Bitmap b)
        {
            var jgpEncoder = GetEncoder(ImageFormat.Jpeg);
            var myEndcoder = System.Drawing.Imaging.Encoder.Quality;

            var myEncoderParameters = new EncoderParameters(1);

            var myEncoderParameter = new EncoderParameter(myEndcoder, 100L);
            myEncoderParameters.Param[0] = myEncoderParameter;

            using (var m = new MemoryStream())
            {
                b.Save(m, jgpEncoder, myEncoderParameters);

                var bImg = new BitmapImage();
                bImg.StreamSource = new MemoryStream(m.ToArray());
                bImg.EndInit();

                return bImg;
            }
        }

        public static ImageCodecInfo GetEncoder(ImageFormat format)
        {
            var codecs = ImageCodecInfo.GetImageDecoders();


            foreach (ImageCodecInfo codec in codecs)
            {
                if (codec.FormatID == format.Guid)
                    return codec;
            }
            return null;
        }


        public static byte[] CompressToByte(byte[] raw)
        {
            using (var memory = new MemoryStream())
            {
                using (var gzip = new GZipStream(memory, CompressionMode.Compress, true))
                {
                    gzip.Write(raw, 0, raw.Length);
                }
                return memory.ToArray();
            }
        }


        public static byte[] Decompress(byte[] gzip)
        {
            using (var stream = new GZipStream(new MemoryStream(gzip), CompressionMode.Decompress))
            {
                const int size = 4096;
                byte[] buffer = new byte[size];

                using (var memory = new MemoryStream())
                {
                    int count = 0;

                    do
                    {
                        count = stream.Read(buffer, 0, size);
                        if (count > 0)
                        {
                            memory.Write(buffer, 0, count);
                        }
                    } while (count > 0);

                    return memory.ToArray();
                }
            }
        }
    }
}
