﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Media.Imaging;

namespace WinX.Imaging
{
    public partial class ImageToBitmapSource
    {

        [DllImport("gdi32.dll")]
        public static extern bool DeleteObject(IntPtr hObject);


        public static BitmapSource From(Image img)
        {
            var bitmap = new Bitmap(img);
            var bmpPt = bitmap.GetHbitmap();
            var bitmapSource = System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(bmpPt, IntPtr.Zero, System.Windows.Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());

            bitmapSource.Freeze();
            DeleteObject(bmpPt);
            return bitmapSource;
        }
    }
}
