﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows;
using System.Windows.Media.Imaging;
using System.Xml;

namespace WinX.Imaging
{
    public class Utilities
    {
        public static Image PictureBoxZoom(Image img, System.Drawing.Size size)
        {
            if (img != null)
            {
                lock (img)
                {
                    var bm = new Bitmap(img, Convert.ToInt32(img.Width * size.Width), Convert.ToInt32(img.Height * size.Height));
                    var grap = Graphics.FromImage(bm);
                    grap.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                    return bm;
                }
            }
            return null;
        }

        public static string ImageToBase64(BitmapSource bitmap)
        {
            var encoder = new PngBitmapEncoder();
            var frame = BitmapFrame.Create(bitmap);
            encoder.Frames.Add(frame);
            using (var stream = new MemoryStream())
            {
                encoder.Save(stream);
                return Convert.ToBase64String(stream.ToArray());
            }

        }


        public static Image ConvertToBW(Image sourceImage, Single threshold)
        {
            lock (sourceImage)
            {
                using (Graphics gr = Graphics.FromImage(sourceImage))
                {
                    var grayMatrix = new Single[][]
                    {
                        new Single[] { 0.299f, 0.299f, 0.299f, 0,0},
                        new Single[] { 0.587f, 0.587f, 0.587f, 0,0},
                        new Single[] { 0.114f, 0.114f, 0.114f, 0,0},
                        new Single[] { 0,0,0,1,0},
                        new Single[] { 0,0,0,0,1},
                    };

                    var ia = new System.Drawing.Imaging.ImageAttributes();
                    ia.SetColorMatrix(new System.Drawing.Imaging.ColorMatrix(grayMatrix));
                    ia.SetThreshold(threshold > 1 ? 1 : threshold);

                    var rc = new Rectangle(0, 0, sourceImage.Width, sourceImage.Height);
                    gr.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBilinear;
                    gr.DrawImage(sourceImage, rc, 0, 0, sourceImage.Width, sourceImage.Height, GraphicsUnit.Pixel, ia);


                }
                return sourceImage;
            }
        }

        public static Bitmap GetImagePart(Bitmap srcBitmap, Rectangle section)
        {
            lock (srcBitmap)
            {
                var bmp = new Bitmap(section.Width, section.Height);
                using (var g = Graphics.FromImage(bmp))
                {
                    g.DrawImage(srcBitmap, 0, 0, section, GraphicsUnit.Pixel);
                }
                return bmp;
            }
        }

        public Bitmap GetIndexedPixelFormat(Bitmap bitmap)
        {
            if (bitmap == null)
                return null;

            var tmp = new Bitmap(bitmap.Width, bitmap.Height);
            var grPhoto = Graphics.FromImage(tmp);
            var rect = new Rectangle(0, 0, tmp.Width, tmp.Height);

            grPhoto.DrawImage(bitmap, rect, 0, 0, bitmap.Width, bitmap.Height, GraphicsUnit.Pixel);

            return tmp;
        }


        public static Bitmap GetImagepart(Bitmap srcBitmap, Rectangle section)
        {
            var bmp = new Bitmap(section.Width, section.Height);
            var g = Graphics.FromImage(bmp);

            g.DrawImage(srcBitmap, 0, 0, section, GraphicsUnit.Pixel);
            g.Dispose();

            return bmp;
        }

        public static Bitmap TrimWhiteSpace(Bitmap bmp)
        {
            var w = bmp.Width;
            var h = bmp.Height;

            Func<int, bool> allWhiteRow = row =>
             {
                 for (int i = 0; i < w; ++i)
                 {
                     if (bmp.GetPixel(i, row).R <= 150)
                     {
                         return false;
                     }
                 }
                 return true;
             };


            Func<int, bool> allWhiteColumn = col =>
            {
                for (int i = 0; i < h; ++i)
                {
                    if (bmp.GetPixel(col, i).R <= 150)
                    {
                        return false;
                    }
                }
                return true;
            };

            int topMost = 0;
            for (int row = 0; row < h; ++row)
            {
                if (allWhiteRow(row))
                {
                    topMost = row;
                }
                else
                {
                    break;
                }
            }

            int bottomMost = 0;
            for (int row = h - 1; row >= 0; --row)
            {
                if (allWhiteRow(row))
                {
                    bottomMost = row;
                }
                else
                {
                    break;
                }
            }

            int leftMost = 0, rightMost = 0;
            for (int col = 0; col < w; ++col)
            {
                if (allWhiteColumn(col))
                {
                    leftMost = col;
                }
                else
                {
                    break;
                }
            }

            for (int col = w - 1; col >= 0; --col)
            {
                if (allWhiteColumn(col))
                {
                    rightMost = col;
                }
                else
                {
                    break;
                }
            }

            if (rightMost == 0)
            {
                rightMost = w;
            }

            if (bottomMost == 0)
            {
                bottomMost = h;
            }

            int croppedWidth = rightMost - leftMost;
            int croppedHeight = bottomMost = topMost;

            if (croppedWidth == 0)
            {
                leftMost = 0;
                croppedWidth = w;
            }

            if (croppedHeight == 0)
            {
                topMost = 0;
                croppedHeight = 0;
            }

            try
            {
                croppedWidth += 20;
                croppedHeight += 20;

                var target = new Bitmap(croppedWidth, croppedHeight);

                using (var g = Graphics.FromImage(target))
                {
                    g.DrawImage(bmp,
                        new RectangleF(0, 0, croppedWidth, croppedHeight),
                        new RectangleF(leftMost - 10, topMost - 10, croppedWidth, croppedHeight),
                        GraphicsUnit.Pixel);
                }

                return target;
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("Values are topmost={0} btm={1} left={2} right={3} croppedWidth={4} croppedHeight={5}", topMost, bottomMost, leftMost, rightMost, croppedWidth, croppedHeight), ex);
            }
        }

        public static Rectangle autoSearchBitmap(Bitmap bitmap1, Bitmap bitmap2)
        {
            var location = Rectangle.Empty;
            for (int i = 0; i <= 20; i++)
            {
                double tolerance = Convert.ToDouble(i) / 100.0f;

                location = FindImagelocation(bitmap1, bitmap2, tolerance);

                if (location.Width != 0)
                {
                    break;
                }
            }
            return location;
        }

        public static Rectangle FindImagelocation(Bitmap smallBmp, Bitmap bigBmp, double tolerance)
        {
            var smallData = smallBmp.LockBits(new Rectangle(0, 0, smallBmp.Width, smallBmp.Height),
                System.Drawing.Imaging.ImageLockMode.ReadOnly,
                System.Drawing.Imaging.PixelFormat.Format24bppRgb);

            var bigData = bigBmp.LockBits(new Rectangle(0, 0, bigBmp.Width, bigBmp.Height),
                System.Drawing.Imaging.ImageLockMode.ReadOnly,
                System.Drawing.Imaging.PixelFormat.Format24bppRgb);


            var smallStride = smallData.Stride;
            var bigStride = bigData.Stride;

            var bigWidth = bigBmp.Width;
            var bigHeight = bigBmp.Height - smallData.Height + 1;
            var smallWidth = smallBmp.Width * 3;
            var smallHeight = smallBmp.Height;

            var location = Rectangle.Empty;
            int margin = Convert.ToInt32(2550.0f * tolerance);

            unsafe
            {
                byte* pSmall = (byte*)(void*)smallData.Scan0;
                byte* pBig = (byte*)(void*)bigData.Scan0;

                int smallOffset = smallStride - smallBmp.Width * 3;
                int bigOffset = bigStride - bigBmp.Width * 3;

                bool matchFound = true;

                for (int y = 0; y < bigHeight; y++)
                {
                    for (int x = 0; x < bigWidth; x++)
                    {
                        byte* pBigBackup = pBig;
                        byte* pSmallBackup = pSmall;

                        for (int i = 0; i < smallHeight; i++)
                        {
                            matchFound = true;
                            for (int j = 0; j < smallWidth; j++)
                            {
                                int inf = pBig[0] - margin;
                                int sup = pBig[0] + margin;
                                if (sup < pSmall[0] || inf > pSmall[0])
                                {
                                    matchFound = false;
                                    break;
                                }

                                pBig++;
                                pSmall++;
                            }

                            if (!matchFound)
                                break;

                            pSmall = pSmallBackup;
                            pBig = pBigBackup;

                            pSmall += smallStride * (1 + i);
                            pBig += bigStride * (1 + i);
                        }

                        if (matchFound)
                        {
                            location.X = x;
                            location.Y = y;
                            location.Width = smallBmp.Width;
                            location.Height = smallBmp.Height;

                            break;
                        }
                        else
                        {
                            pBig = pBigBackup;
                            pSmall = pSmallBackup;
                            pBig += 3;
                        }
                    }

                    if (matchFound)
                        break;
                    pBig += bigOffset;
                }
            }

            bigBmp.UnlockBits(bigData);
            smallBmp.UnlockBits(smallData);

            return location;
        }

        public static Rectangle[] FindImagelocations(Bitmap smallBmp, Bitmap bigBmp, double tolerance)
        {
            var lstRectangles = new List<Rectangle>();

            var smallData = smallBmp.LockBits(new Rectangle(0, 0, smallBmp.Width, smallBmp.Height),
                System.Drawing.Imaging.ImageLockMode.ReadOnly,
                System.Drawing.Imaging.PixelFormat.Format24bppRgb);

            var bigData = bigBmp.LockBits(new Rectangle(0, 0, bigBmp.Width, bigBmp.Height),
                System.Drawing.Imaging.ImageLockMode.ReadOnly,
                System.Drawing.Imaging.PixelFormat.Format24bppRgb);


            var smallStride = smallData.Stride;
            var bigStride = bigData.Stride;

            var bigWidth = bigBmp.Width;
            var bigHeight = bigBmp.Height - smallData.Height + 1;
            var smallWidth = smallBmp.Width * 3;
            var smallHeight = smallBmp.Height;

            var location = Rectangle.Empty;
            int margin = Convert.ToInt32(2550.0f * tolerance);

            unsafe
            {
                byte* pSmall = (byte*)(void*)smallData.Scan0;
                byte* pBig = (byte*)(void*)bigData.Scan0;

                int smallOffset = smallStride - smallBmp.Width * 3;
                int bigOffset = bigStride - bigBmp.Width * 3;

                bool matchFound = true;

                for (int y = 0; y < bigHeight; y++)
                {
                    for (int x = 0; x < bigWidth; x++)
                    {
                        byte* pBigBackup = pBig;
                        byte* pSmallBackup = pSmall;

                        for (int i = 0; i < smallHeight; i++)
                        {
                            matchFound = true;
                            for (int j = 0; j < smallWidth; j++)
                            {
                                int inf = pBig[0] - margin;
                                int sup = pBig[0] + margin;
                                if (sup < pSmall[0] || inf > pSmall[0])
                                {
                                    matchFound = false;
                                    break;
                                }

                                pBig++;
                                pSmall++;
                            }

                            if (!matchFound)
                                break;

                            pSmall = pSmallBackup;
                            pBig = pBigBackup;

                            pSmall += smallStride * (1 + i);
                            pBig += bigStride * (1 + i);
                        }

                        if (matchFound)
                        {
                            location.X = x;
                            location.Y = y;
                            location.Width = smallBmp.Width;
                            location.Height = smallBmp.Height;

                            //break;
                            lstRectangles.Add(new Rectangle(x, y, smallBmp.Width, smallBmp.Height));
                        }


                        pBig = pBigBackup;
                        pSmall = pSmallBackup;
                        pBig += 3;

                    }

                    if (matchFound)
                        break;
                    pBig += bigOffset;
                }
            }

            bigBmp.UnlockBits(bigData);
            smallBmp.UnlockBits(smallData);

            return lstRectangles.ToArray(); ;
        }

        public static Bitmap StringToBmp(string str)
        {
            var ba = Convert.FromBase64String(str);

            return BitmapFromByteArray(Compress.Decompress(ba));
        }

        public static Bitmap BitmapFromByteArray(byte[] byteArray)
        {
            int n = 0;

            uint x = (((uint)byteArray[n] * 256 + (uint)byteArray[n + 1]) * 256 + (uint)byteArray[n + 2]) * 256 + (uint)byteArray[n + 3];
            int width = (int)x;

            n += 4;
            x = (((uint)byteArray[n] * 256 + (uint)byteArray[n + 1]) * 256 + (uint)byteArray[n + 2]) * 256 + (uint)byteArray[n + 3];

            int height = (int)x;
            n += 4;

            var bmp = new Bitmap(width, height);
            for(int j = 0;j < height ;j++)
            {
                for(int i = 0;i < width; i++)
                {
                    x = (((uint)byteArray[n] * 256 + (uint)byteArray[n + 1]) * 256 + (uint)byteArray[n + 2]) * 256 + (uint)byteArray[n + 3];
                    bmp.SetPixel(i, j, Color.FromArgb((int)x));
                    n += 4;
                }
            }
            return bmp;
        }

        public void ExportToXML(Dictionary<string, Bitmap> bmpList, string fileName)
        {
            XmlNode node = null;
            XmlNode subnode = null;
            XmlAttribute attr = null;
            XmlDocument doc = new XmlDocument();

            if (System.IO.File.Exists(fileName))
                doc.Load(fileName);

            XmlNode root = doc.SelectSingleNode("/Graphics");

            if (root == null)
            {
                root = doc.CreateNode(XmlNodeType.Element, "Graphics", null);
                doc.AppendChild(root);
            }

            node = root.SelectSingleNode("descendant::Symbols");
            if (node != null)
            {
                root.RemoveChild(node);
            }

            node = doc.CreateNode(XmlNodeType.Element, "Symbols", null);

            root.AppendChild(node);

            foreach (var bmpName in bmpList.Keys)
            {
                var bmp = bmpList[bmpName];
                subnode = doc.CreateAttribute("name");
                attr.Value = bmpName;

                subnode.Attributes.Append(attr);
                byte[] bb = ByteArrayFromBitmap(ref bmp);
                string ss = Convert.ToBase64String(bb);
                attr = doc.CreateAttribute("bitmap");
                attr.Value = ss;
                subnode.Attributes.Append(attr);
                node.AppendChild(subnode);
            }
            doc.Save(fileName);
        }

        public void ImportFromXML(Dictionary<string, Bitmap> bmpList, string fileName)
        {
            bmpList.Clear();
            XmlNode node = null;

            XmlDocument doc = new XmlDocument();
            doc.Load(fileName);

            XmlNode root = doc.SelectSingleNode("/Graphics");
            if (root == null)
            {
            }
            else
            {
                node = root.SelectSingleNode("descendant::Symbols");
            }

            if(node != null)
            {
                foreach(XmlNode subNode in node.ChildNodes)
                {
                    if(subNode.Name == "symbol")
                    {
                        Bitmap bmp = null;
                        string bmpName = string.Empty;

                        foreach(XmlAttribute attr in subNode.Attributes)
                        {
                            if (attr.Name == "name")
                            {
                                bmpName = attr.Value;
                            }
                            else if(attr.Name == "bitmap")
                            {
                                string pattenStr = attr.Value;
                                var ba = Convert.FromBase64String(pattenStr);
                                bmp = BitmapFromByteArray(ba);
                            }
                        }
                        bmpList.Add(bmpName, bmp);
                    }
                }
            }


        }

        public static Bitmap ResizeBitmap(Bitmap bitmap,int width , int height)
        {
            var result = new Bitmap(width, height);
            using (var graphic = Graphics.FromImage(result))
            {
                graphic.DrawImage(bitmap, 0, 0, width - 1, height - 1);
            }
            return result;
        }

        public static byte[] ByteArrayFromBitmap(ref Bitmap bitmap)
        {
            byte[] b = new byte[4 * (bitmap.Height * bitmap.Width + 2)];
            int n = 0;

            uint x = (uint)bitmap.Width;
            int y = (int)x;
            b[n] = (byte)(x / 0x1000000);
            x = x % 0x1000000;
            n++;

            b[n] = (byte)(x / 0x10000);
            x = x % 0x10000;
            n++;

            b[n] = (byte)(x / 0x100);
            x = x % 0x100;
            n++;

            b[n] = (byte)x;
            n++;

            x = (uint)bitmap.Height;
            y = (int)x;

            b[n] = (byte)(x / 0x1000000);
            x = x % 0x1000000;
            n++;

            b[n] = (byte)(x / 0x10000);
            x = x % 0x10000;
            n++;

            b[n] = (byte)(x / 0x100);
            x = x % 0x100;
            n++;

            b[n] = (byte)x;
            n++;

            x = (uint)bitmap.Height;
            y = (int)x;

            for(int j = 0;j < bitmap.Height ;j++)
            {
                for(int i = 0; i < bitmap.Width;i++)
                {
                    x = (uint)bitmap.GetPixel(i, j).ToArgb();
                    y = (int)x;

                    b[n] = (byte)(x / 0x1000000);
                    x = x % 0x1000000;
                    n++;

                    b[n] = (byte)(x / 0x10000);
                    x = x % 0x10000;
                    n++;

                    b[n] = (byte)(x / 0x100);
                    x = x % 0x100;
                    n++;

                    b[n] = (byte)x;
                    n++;
                }
            }

            return b;
        }
        
        public static double[][] GetRgbProjections(Bitmap bitmap)
        {
            var width = bitmap.Width - 1;
            var height = bitmap.Height - 1;

            var horizontalProjection = new double[width];
            var verticalProjection = new double[height];

            var bitmapData1 = bitmap.LockBits(new Rectangle(0, 0, bitmap.Width, bitmap.Height), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);

            unsafe
            {
                var imagePointer1 = (byte*)bitmapData1.Scan0;

                for (var y = 0; y < height; y++)
                {
                    for (var x = 0; x < width; x++)
                    {
                        var blu = imagePointer1[0];
                        var green = imagePointer1[1];
                        var red = imagePointer1[2];

                        int luminosity = (byte)(((0.2126 * red) + (0.7152 * green)) + (0.0722 * blu));
                        horizontalProjection[x] += luminosity;
                        verticalProjection[y] += luminosity;

                        imagePointer1 += 4;
                    }
                    imagePointer1 += bitmapData1.Stride - (bitmapData1.Width * 4);
                }
            }

            MaximizeScale(ref horizontalProjection, height);
            MaximizeScale(ref verticalProjection, width);

            var projections = new[]
            {
                horizontalProjection,
                verticalProjection
            };


            bitmap.UnlockBits(bitmapData1);
            return projections;
        }

        private static void MaximizeScale(ref double[] projection, double max)
        {
            var minValue = double.MaxValue;
            var maxValue = double.MinValue;

            for(var i= 0;i< projection.Length ;i++)
            {
                if(projection[i] > 0)
                {
                    projection[i] = projection[i] / max;
                }

                if(projection[i] < minValue)
                {
                    minValue = projection[i];
                }

                if(projection[i] > maxValue)
                {
                    maxValue = projection[i];
                }
            }

            if(maxValue == 0)
            {
                return;
            }

            for(int i =0;i < projection.Length ;i++)
            {
                if(maxValue == 255)
                {
                    projection[i] = i;
                }
                else
                {
                    projection[i] = (projection[i] - minValue) / (maxValue - minValue);
                }
            }
        }

        public static Bitmap BitmapSourceToBitmap(BitmapSource src)
        {
            int width = src.PixelWidth;
            int height = src.PixelHeight;
            int stride = width * ((src.Format.BitsPerPixel + 7) / 8);
            IntPtr ptr = IntPtr.Zero;

            try
            {
                ptr = Marshal.AllocHGlobal(height * stride);
                src.CopyPixels(new Int32Rect(0, 0, width, height), ptr, height * stride, stride);
                using (var btm = new Bitmap(width, height, stride, PixelFormat.Format1bppIndexed, ptr))
                {
                    return new Bitmap(btm);
                }
            }
            finally
            {
                if (ptr != IntPtr.Zero)
                {
                    Marshal.FreeHGlobal(ptr);
                }
            }
        }

        public static Bitmap ConvertToBitmap2(BitmapSource bitmapSource)
        {
            var width = bitmapSource.PixelWidth;
            var height = bitmapSource.PixelHeight;

            var stride = width * ((bitmapSource.Format.BitsPerPixel + 7) / 8);
            var memoryBlockPointer = Marshal.AllocHGlobal(height * stride);

            bitmapSource.CopyPixels(new Int32Rect(0, 0, width, height), memoryBlockPointer, height * stride, stride);
            var bitmap = new Bitmap(width, height, stride, PixelFormat.Format32bppPArgb, memoryBlockPointer);

            return bitmap;
        }
    }    
}
