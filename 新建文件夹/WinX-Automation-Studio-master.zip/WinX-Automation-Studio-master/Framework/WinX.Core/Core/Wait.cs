﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace WinX.Core
{
    public class Wait
    {
        public static void ForAll(int timeOutInSec,params Action[] funcs)
        {
            try
            {
                var autoEvent = new AutoResetEvent(false);

                var taskCount = 0;

                for (int i = 0; i < funcs.Count(); i++)
                {
                    var index = i;
                    Interlocked.Increment(ref taskCount);

                    ThreadPool.QueueUserWorkItem(evt => 
                        {

                            try
                            {
                                var action = funcs[i];

                                action.Invoke();

                            }
                            catch(Exception ex)
                            {
                            }
                            finally
                            {
                                if(Interlocked.Decrement(ref taskCount) == 0)
                                {

                                }
                            }
                        }
                    );

                }

            }
            catch(Exception ex)
            {

            }
            
        }

        public static T RunOnSTA<T>(Func<T> func, int timeOutInSec = 30)
        {
            object returnObj = null;

            try
            {
                if (func != null)
                {
                    var aEvt = new AutoResetEvent(false);
                    var th = new System.Threading.Thread((obj) =>
                    {
                        var data = obj as object[];
                        try
                        {
                            Func<object> f = data[1] as Func<object>;
                            returnObj = f.Invoke();
                        }
                        catch (Exception ex)
                        {
                            Logger.Write(ex, "An exception occured while trying to invoke function on STA thread.");
                        }
                        finally
                        {
                            ((AutoResetEvent)data[0]).Set();
                        }
                    });

                    th.SetApartmentState(ApartmentState.STA);
                    th.Start(new object[] { aEvt, func });

                    if (aEvt.WaitOne(TimeSpan.FromSeconds(timeOutInSec)))
                    {
                        Logger.Write("ExecuteOnSTA method was executed successfully.");
                    }
                    else
                    {
                        Logger.Write("A time of out occured for ExcuteOnSTA motho.", Logger.MsgType.Error);
                    }
                }
            }
            catch(Exception ex)
            {
                Logger.Write(ex, "An exception occured while trying to invoke ExecutOnSTA method.");
            }

            return (T)returnObj;

        }

    }
}
