﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;

namespace WinX.Core
{
    [Serializable]
    public partial class Profiler
    {
        public static ObservableCollection<CheckPoint> CheckPoints;


        public static void CheckIn(string checkPoint)
        {
            var proc = System.Diagnostics.Process.GetCurrentProcess();

            Profiler.CheckPoints.Add(new CheckPoint()
            {
                Name = checkPoint,
                ProcessorTime = proc.TotalProcessorTime.TotalSeconds,
                Memory = proc.WorkingSet64,
                TotalThreads = proc.Threads.Count,
                CurrentThread = System.Threading.Thread.CurrentThread.ManagedThreadId,
                Time = DateTime.Now
            });
        }

        public static void SavetoFile(string fileName)
        {
            WinX.Core.Serializers.ObjectToXMLFile(CheckPoints, CheckPoints.GetType(), fileName);
        }

    }


    [Serializable]
    public partial class CheckPoint
    {
        public string Name
        {
            get;
            set;
        }

        public double ProcessorTime
        {
            get;
            set;
        }

        public double Memory
        {
            get;
            set;
        }


        public int TotalThreads
        {
            get;
            set;
        }

        public int CurrentThread
        {
            get;
            set;
        }


        public DateTime Time
        {
            get;
            set;
        }
    }
}
