﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WinX.Core
{
    public partial class Try
    {
        public static void Execute(Action func)
        {
            try
            {
                func.Invoke();
            }
            catch (Exception ex)
            {

            }
        }

        public static object Execute(Func<object> func)
        {
            object result = null;//new object();

            try
            {
                result = func.Invoke();

            }
            catch (Exception ex)
            {

            }
            return result;
        }


        public static T Execute<T>(Func<T> func)
        {
            T result = default(T);

            try
            {
                result = func.Invoke();

            }
            catch(Exception ex)
            {
                
            }
            return result;
        }
        
        public static object Get(Func<object> func)
        {
            return Try.Execute(func);
        }

        public static T Get<T>(Func<T> func)
        {
            return Try.Execute(func);
        }

    }
}
