﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
using System.ComponentModel;

namespace WinX.Core
{
    [TypeConverter(typeof(OptionsConverter))]
    [Serializable()]
    public abstract class MatchRule : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged(string propertyName)
        {
            if (this.PropertyChanged != null)
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        [Browsable(false)]
        public Guid ID = Guid.NewGuid();

        private bool pStatus;

        [Browsable(false), XmlIgnore()]

        public bool Status
        {
            get
            {
                return pStatus;
            }
            set
            {
                this.pStatus = value;
                NotifyPropertyChanged("Status");
            }
        }

        protected abstract bool MatchEle(object ele);

        public abstract void WriteDescription(System.IO.TextWriter writer);
        
        public bool Match(object element)
        {
            if (element == null)
            {
                throw new ArgumentException("Element isnull");
            }

            this.Status = this.MatchEle(element);
            return this.Status;
        }

        public override string ToString()
        {
            var writer = new System.IO.StringWriter();
            WriteDescription(writer);
            return writer.ToString();
        }
    }
}
