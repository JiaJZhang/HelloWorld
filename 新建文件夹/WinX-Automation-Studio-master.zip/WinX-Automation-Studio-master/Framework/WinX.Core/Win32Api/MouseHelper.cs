﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;

namespace WinX.Core
{


    public static partial class MouseHelper
    {

        [DllImport("user32.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
        public static extern void mouse_event(MouseEvent dwFlags, uint dx, uint dy, uint cButtons, int dwExtraInfo);


        [DllImport("user32.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
        public static extern int GetSystemMetrics(SysteamMetric nIndex);


        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool SwapMouseButton([param: MarshalAs(UnmanagedType.Bool)]bool fSwap);

        public static void MakeRightButtonPrimary()
        {
            SwapMouseButton(true);
        }

        public static void MakeLeftButtonPrimary()
        {
            SwapMouseButton(false);
        }

        public static void DoMosuseLeftClick(int x, int y)
        {
            System.Windows.Forms.Cursor.Position = new System.Drawing.Point(x, y);
            if (GetSystemMetrics(SysteamMetric.SM_SWAPBUTTON) != 0)
            {
                mouse_event(MouseEvent.RIGHT_DOWN | MouseEvent.RIGHT_UP, (uint)x, (uint)y, 0, 0);
            }
            else
            {
                mouse_event(MouseEvent.LEFT_DOWN | MouseEvent.LEFT_UP, (uint)x, (uint)y, 0, 0);
            }
        }

        public static void DoMouseRightClick(int x, int y)
        {
            System.Windows.Forms.Cursor.Position = new System.Drawing.Point(x, y);
            if (GetSystemMetrics(SysteamMetric.SM_SWAPBUTTON) != 0)
            {
                mouse_event(MouseEvent.LEFT_DOWN | MouseEvent.LEFT_UP, (uint)x, (uint)y, 0, 0);
            }
            else
            {
                mouse_event(MouseEvent.RIGHT_DOWN | MouseEvent.RIGHT_UP, (uint)x, (uint)y, 0, 0);
            }

        }
    }
}
