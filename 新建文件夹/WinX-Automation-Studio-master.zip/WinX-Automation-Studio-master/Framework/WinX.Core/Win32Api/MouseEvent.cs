﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WinX.Core
{
    public enum MouseEvent : int
    {
        // <summary>
        /// 模拟鼠标移动
        /// </summary>
        LEFT_DOWN = 0x0002,
        /// <summary>
        /// 模拟鼠标左键按下
        /// </summary>
        MOVE = 0x0001,
        /// <summary>
        /// 模拟鼠标左键抬起
        /// </summary>
        LEFT_UP = 0x0004,
        /// <summary>
        /// 鼠标绝对位置
        /// </summary>
        ABSOLUTE = 0x8000,
        /// <summary>
        /// 模拟鼠标右键按下 
        /// </summary>
        RIGHT_DOWN = 0x0008,
        /// <summary>
        /// 模拟鼠标右键抬起 
        /// </summary>
        RIGHT_UP = 0x0010,
        /// <summary>
        /// 模拟鼠标中键按下 
        /// </summary>
        MIDDLE_DOWN = 0x0020,
        /// <summary>
        /// 模拟鼠标中键抬起 
        /// </summary>
        MIDDLE_UP = 0x0040,
    }
}
