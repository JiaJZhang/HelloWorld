﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;

namespace WinX.Core
{
    public partial class Win16Helper
    {
        public static Guid IID_IWebBrowserApp = new Guid("0002DF05-0000-0000-C000-000000000046");
        public static Guid IID_IWebBrowser2 = new Guid("D30C1661-CDAF-11D0-8A3E-00C04FC9E26E");
        public const int E_ACCESSDENIED = unchecked((int)0x80070005);
        
        [DllImport("user32.dll", CharSet = CharSet.Auto, ExactSpelling = true)]
        public static extern bool ShowWindow(int hWnd, int nCmdShow);

        [DllImport("user32.dll", CharSet = CharSet.Auto, ExactSpelling = true)]
        public static extern bool ShowWindow(IntPtr hWnd, WindowState nCmdShow);

        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        public static extern IntPtr SetFocus(int hWnd);

        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        static public extern bool SetForegroundWindow(int hWnd);
        
        [DllImport("user32.dll")]
        public static extern IntPtr SetActiveWindow(int hWnd);

        [DllImport("user32.dll", EntryPoint = "GetWindowLongA", SetLastError = true)]
        private static extern long GetWindowLong(int hwnd, int nIndex);


        [DllImport("user32.dll")]
        public static extern int IsIconic(int hWnd);

        [DllImport("user32.dll")]
        public static extern int IsIconic(IntPtr hWnd);


        [DllImport("user32.dll")]
        public static extern int IsZoomed(int hWnd);


        [DllImport("user32.dll")]
        public static extern int IsWindowEnabled(int hWnd);


        public enum WindowState : int
        {
            UNKNOW = 0,
            Normal = 1,
            MINIMIZED = 2,
            MAXIMIZED = 3

        }

        public const int SW_SHOWNORMAL = 1;
        public const int SW_SHOWMINIMIZED = 2;
        public const int SW_SHOWMAXIMIZED = 3;


        public static void BringWindowTop(int hwnd)
        {
            if (GetWindowState(hwnd) == WindowState.MINIMIZED)
            {
                ShowWindow(hwnd, SW_SHOWNORMAL);
            }

            SetActiveWindow(hwnd);
            SetForegroundWindow(hwnd);
            SetFocus(hwnd);
        }

        public static WindowState GetWindowState(IntPtr hwnd)
        {
            return GetWindowState(hwnd.ToInt32());
        }

        public static WindowState GetWindowState(int hwnd)
        {           
            if(IsIconic(hwnd) == 1)
            {
                return WindowState.MINIMIZED;
            }
            else if (IsZoomed(hwnd) == 1)
            {
                return WindowState.MAXIMIZED;
            }
            else if(IsWindowEnabled(hwnd) == 1)
            {
                return WindowState.Normal;
            }

            return WindowState.UNKNOW;

        }

    }

}