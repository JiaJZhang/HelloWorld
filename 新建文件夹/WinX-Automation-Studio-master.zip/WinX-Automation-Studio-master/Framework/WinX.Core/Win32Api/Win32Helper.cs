﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;

namespace WinX.Core
{
    public partial class Win32Helper
    {
        public static IntPtr GetTopLevelWindow(IntPtr hwnd)
        {
            var parent = new IntPtr(User32.GetParent(hwnd));
            if (parent == IntPtr.Zero)
            {
                return hwnd;
            }
            else
            {
                return new IntPtr(User32.GetTopWindow(hwnd));
            }
        }

        public static string GetWindowRawText(IntPtr hwnd)
        {
            var windowTextLength = User32.SendMessage(hwnd, User32.WM_GETTEXTLENGTH, 0, 0);
            var stringBuilder = new StringBuilder(windowTextLength + 1);

            User32.SendMessage(hwnd, User32.WM_GETTEXT, stringBuilder.Capacity, stringBuilder);

            return stringBuilder.ToString();
        }


        public static string GetWindowText(IntPtr hwnd)
        {
            var builder = new StringBuilder(User32.GetWindowTextLength(hwnd) + 1);
            User32.GetWindowText(hwnd, builder, builder.Capacity);
            return builder.ToString();
        }

        public static string GetClassName(IntPtr hwnd)
        {
            var builder = new StringBuilder(255);
            var lRes = User32.GetClassName(hwnd, builder, builder.Capacity);
            if (lRes == 0)
            {
                return string.Empty;
            }
            return builder.ToString();
        }

        public static string GetDlgItemText(IntPtr hwnd)
        {
            var builder = new StringBuilder(255);
            var lRes = User32.GetDlgItemText(hwnd, 0, builder, builder.Capacity);

            if (lRes == 0)
            {
                return string.Empty;
            }
            return builder.ToString();
        }

        //public static string GetFieldTypeFromClass(string ctrlClass)
        //{

        //}

        public static IntPtr GetChildWindowHwnd(IntPtr parentHwnd, string className)
        {
            var hWnd = IntPtr.Zero;
            User32.EnumChildWindows(parentHwnd, (childHwnd, lParam) =>
                                                {
                                                    if (CompareClassNames(childHwnd, className))
                                                    {
                                                        hWnd = childHwnd;
                                                        return false;
                                                    }
                                                    return true;
                                                }, IntPtr.Zero);
            return hWnd;
        }

        public static bool CompareClassNames(IntPtr hWnd, string expectedClassName)
        {
            if (hWnd == IntPtr.Zero)
            {
                return false;
            }

            if (string.IsNullOrEmpty(expectedClassName))
            {
                return false;
            }
            var className = GetClassName(hWnd);

            return className.Equals(expectedClassName);
        }


        public static string GetWindowID(IntPtr hwnd)
        {
            return User32.GetDlgCtrlID(hwnd).ToString();
        }

        public static bool WinButtonClick(string WinClass, string winTitle, string buttonText)
        {
            try
            {
                var hwndWindow = new IntPtr(User32.FindWindow(WinClass, winTitle));
                if (hwndWindow != IntPtr.Zero)
                {
                    return WinButtonClick(hwndWindow, buttonText);
                }

            }
            catch (Exception ex)
            {

            }
            return false;
        }

        public static bool WinButtonClick(IntPtr winHandle, string buttonText)
        {
            try
            {
                if (winHandle != IntPtr.Zero)
                {
                    var hwndSaveBtn = new IntPtr(User32.FindWindowEx(winHandle, IntPtr.Zero, "Button", buttonText));

                    if (hwndSaveBtn != IntPtr.Zero)
                    {
                        User32.PostMessage(hwndSaveBtn, 0x00F5, 0, IntPtr.Zero.ToInt32());
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {

            }
            return false;
        }

        public static void Highlight(IntPtr ctrlHwnd, System.Drawing.Brush b = null)
        {
            var drawPen = new System.Drawing.Pen(System.Drawing.Brushes.Lime, 2);

            if (b != null)
            {
                drawPen = new System.Drawing.Pen(b, 2);
            }

            IntPtr windowDC;
            var windowRect = new System.Drawing.Rectangle();
            User32.GetWindowRect(ctrlHwnd,ref windowRect);

            windowDC = new IntPtr(User32.GetWindowDC(ctrlHwnd));
            if (windowDC != IntPtr.Zero)
            {
                var graph = System.Drawing.Graphics.FromHdc(windowDC, ctrlHwnd);
                graph.DrawRectangle(drawPen, 1, 1, windowRect.Right - windowRect.Left - 2, windowRect.Bottom - windowRect.Top - 2);
                graph.Dispose();
                User32.ReleaseDC(ctrlHwnd, windowDC);

            }
        }
        public static void UnHighlight(IntPtr ctrlHwnd)
        {
            var parentWindow = new IntPtr(User32.GetParent(ctrlHwnd));

            if (parentWindow != IntPtr.Zero)
            {
                ctrlHwnd = parentWindow;
            }

            User32.InvalidateRect(ctrlHwnd, IntPtr.Zero, true);
            User32.UpdateWindow(ctrlHwnd);
            User32.RedrawWindow(ctrlHwnd, IntPtr.Zero, IntPtr.Zero, User32.RDW_FRAME | User32.RDW_INVALIDATE | User32.RDW_UPDATENOW | User32.RDW_ERASENOW | User32.RDW_ALLCHILDREN);
        }

        public static void HighlightControl(IntPtr ctrlHwnd)
        {
            Highlight(ctrlHwnd, System.Drawing.Brushes.Red);
            System.Threading.Thread.Sleep(500);
            UnHighlight(ctrlHwnd);

            Highlight(ctrlHwnd, System.Drawing.Brushes.Yellow);
            System.Threading.Thread.Sleep(500);
            UnHighlight(ctrlHwnd);

            Highlight(ctrlHwnd, System.Drawing.Brushes.Red);
            System.Threading.Thread.Sleep(500);
            UnHighlight(ctrlHwnd);

            Highlight(ctrlHwnd, System.Drawing.Brushes.Yellow);
            System.Threading.Thread.Sleep(500);
            UnHighlight(ctrlHwnd);
        }


        public static Process GetProcessFromHandle(IntPtr handle)
        {
            try
            {
                var procID = 0;
                User32.GetWindowThreadProcessId(handle, out procID);

                if (procID != 0)
                {
                    return Process.GetProcessById(procID);
                }
            }
            catch (Exception ex)
            {

            }
            return null;
        }

        public static void FocusWindow(IntPtr ctrlHwnd)
        {
            User32.SetForegroundWindow(ctrlHwnd);
        }


        public class FindChildDialog
        {
            public struct SearchData
            {
                public int ID { get; set; }
                public string WindowText { get; set; }
                public string ClassName { get; set; }

                public IntPtr ParentHandle { get; set; }
                public IntPtr ResultHandle { get; set; }
            }

            public delegate bool EnumWindowsCallback(IntPtr currentWindowHandle, ref SearchData searchData);

            public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);

            [DllImport("user32.dll")]
            public static extern bool EnumWindows(EnumWindowsCallback callback,ref SearchData searchData);


            [DllImport("user32.dll")]
            public static extern bool EnumWindows(EnumWindowsProc enumProc, IntPtr lParam);



            private static bool Callback(IntPtr currentWindowHandle,ref SearchData searchData)
            {
                var continueEnumeration = true;

                try
                {
                    var currentWindowParentHandle = new IntPtr(User32.GetParent(currentWindowHandle));

                    var classMatch = false;
                    var textMatch = false;


                    if(!string.IsNullOrEmpty(searchData.ClassName))
                    {
                        if(searchData.ClassName.Equals(Win32Helper.GetClassName(currentWindowHandle)))
                        {
                            classMatch = true;
                        }
                    }
                    else
                    {
                        classMatch = true;
                    }

                    if(!string.IsNullOrEmpty(searchData.WindowText))
                    {
                        if(searchData.WindowText.Equals(Win32Helper.GetWindowText(currentWindowHandle)))
                        {
                            textMatch = true;
                        }
                    }
                    else
                    {
                        textMatch = true;
                    }

                    if(classMatch && textMatch)
                    {
                        searchData.ResultHandle = currentWindowHandle;
                        continueEnumeration = false;
                    }
                }
                catch(Exception ex)
                {

                }
                return continueEnumeration;
            }

            public static IntPtr ByTextandClass(IntPtr parentHandle, string windowText, string className)
            {
                var searchData = new SearchData()
                {
                    ParentHandle = parentHandle,
                    WindowText = windowText,
                    ClassName = className,
                };

                EnumWindows(Callback,ref searchData);

                return searchData.ResultHandle;
            }


            public static IntPtr ByText(IntPtr parentHandle,string windowText)
            {
                var searchData = new SearchData()
                {
                    ParentHandle = parentHandle,
                    WindowText = windowText,
                    ClassName = "",
                };

                EnumWindows(Callback, ref searchData);

                return searchData.ResultHandle;
            }

            public static IntPtr ByClass(IntPtr parentHandle,string className)
            {
                var searchData = new SearchData()
                {
                    ParentHandle = parentHandle,
                    ClassName = className,
                };

                EnumWindows(Callback ,ref searchData);

                return searchData.ResultHandle;
            }
        }
    }
}
