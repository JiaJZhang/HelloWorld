﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;

namespace WinX.Core
{
    public partial class WindowsHelper
    {

        [DllImport("user32.dll")]
        private static extern bool EnumChildWindows(IntPtr windowHandle, EnumWindowProcess callBack, IntPtr lParam);

        public delegate bool EnumWindowProcess(IntPtr handle, IntPtr parameter);

        public class ControlInfo
        {
            public IntPtr Handle { get; set; }
            public string ID { get; set; }
            public string Name { get; set; }
            public string ClassName { get; set; }

            public override string ToString()
            {
                return Handle.ToInt32() + " - " + ID + " - " + Name + " - " + ClassName;
            }
        }

        public static List<ControlInfo> GetChildWindows(IntPtr parentHandle)
        {
            var childrenList = new List<IntPtr>();
            var listHandle = GCHandle.Alloc(childrenList);

            try
            {
                EnumChildWindows(parentHandle, EnumWindow, GCHandle.ToIntPtr(listHandle));

            }
            catch (Exception ex)
            {

            }
            finally
            {
                if (listHandle.IsAllocated)
                    listHandle.Free();
            }

            var lst = new List<ControlInfo>();

            foreach (var handle in childrenList)
            {
                var ctrl = new ControlInfo();
                ctrl.Handle = handle;
                ctrl.ID = Win32Helper.GetWindowID(handle);
                ctrl.ClassName = Win32Helper.GetClassName(handle);

                var len = User32.GetWindowTextLength(handle);
                if (len > 0)
                {
                    var b = new System.Text.StringBuilder(Microsoft.VisualBasic.Strings.ChrW(0), len + 1);
                    var ret = User32.GetWindowText(handle, b, b.Length);
                    if (ret != 0)
                    {
                        ctrl.Name = b.ToString();
                    }

                }
                lst.Add(ctrl);
            }

            return lst;
        }

        private static bool EnumWindow(IntPtr handle, IntPtr parameter)
        {
            var childrenList = GCHandle.FromIntPtr(parameter).Target as List<IntPtr>;

            if (childrenList == null)
            {
                throw new Exception("GCHandle target could not be cast as List<Intptr>");
            }

            childrenList.Add(handle);

            return true;
        }

    }
}
