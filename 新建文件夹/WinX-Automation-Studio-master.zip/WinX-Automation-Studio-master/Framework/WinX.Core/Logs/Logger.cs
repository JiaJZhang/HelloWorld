﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Globalization;
using System.Diagnostics;

namespace WinX.Core
{
    public partial class Logger
    {
        public enum MsgType : int
        {
            Information = 1,
            Warning = 2,
            Error = 3,
            Exception = 4
        }

        public delegate void NotifyUserEventHandler(string Msg);

        public static event NotifyUserEventHandler NotifyUser;


        private static bool isLogEnabled = true;
        public static bool IsLogEnabled
        {
            get
            {
                return isLogEnabled;
            }
            set
            {
                isLogEnabled = value;
            }
        }

        public static string LogsDirectory
        {
            get
            {
                return Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            }
        }

        private static string logFileName = "WinX.Log";

        public static string LogFileName
        {
            get
            {
                return logFileName;
            }
            set
            {
                logFileName = value;
            }
        }


        public static string SettingsFileName
        {
            get
            {
                return "WinXLogSettings.xml";
            }
        }

        public Logger()
        {
            LogFileName = "WinX_" + System.Environment.MachineName + ".log";
        }

        private static LogSettings pSettings;

        public static LogSettings Settings
        {
            get
            {
                if (pSettings == null)
                {
                    try
                    {
                        pSettings = Serializers.XMLFileToObject<LogSettings>(LogsDirectory + @"\" + SettingsFileName);

                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }


                    if (pSettings == null)
                    {
                        pSettings = new LogSettings() { Mode = LogSettings.LogMode.Normal, MaxLogSize = 1048576 };
                        Serializers.ObjectToXMLFile(pSettings,pSettings.GetType(), LogsDirectory + @"\" + SettingsFileName);
                    }

                }
                return pSettings;
            }
            set
            {
                pSettings = value;
            }
        }

        public static void CleanupLogs()
        {
            try
            {
                var logsDir = new DirectoryInfo(LogsDirectory);

                if (logsDir.Exists)
                {
                    var logfile = new FileInfo(LogsDirectory + @"\" + LogFileName);

                    //if(logfile.Length > LogSettings.ma)

                }

            }
            catch (Exception ex)
            {
            }
        }

        private static string formatException(Exception ex)
        {
            try
            {
                if (ex != null)
                {
                    var trace = new System.Diagnostics.StackTrace(ex, true);
                    var stackFrame = WinX.Core.Try.Get(() => trace.GetFrame(trace.FrameCount - 1));
                    var fileName = WinX.Core.Try.Get(() => stackFrame.GetFileName());
                    var methodName = WinX.Core.Try.Get(() => stackFrame.GetMethod().Name);
                    var Position = WinX.Core.Try.Get(() => stackFrame.GetFileLineNumber() + "," + stackFrame.GetFileColumnNumber());

                    return string.Format("<Exception Position='{0}' methodName'{1}' fileName='{2}'><Message>{3}</Message><StackTrace>{4}</StackTrace>{5}</Exception>",
                                        Position, methodName, fileName, ex.Message, ex.StackTrace, formatException(ex.InnerException));

                }
            }
            catch(Exception ex1)
            {

            }
            return string.Empty;
        }


        private delegate void WriteDelegate(string Message, int ThreadId);


        public static void Write(Exception ex ,string mesasge = "",bool NotifyUser = false)
        {
            if (!IsLogEnabled)
                return;
            Logger.Write(mesasge + formatException(ex), MsgType.Exception);

        }
        /// <summary>
        /// WinXLogSettings里verbose，才会记录Info的日志
        /// </summary>
        /// <param name="message"></param>
        /// <param name="mode"></param>
        public static void Write(string message, MsgType mode = MsgType.Information)
        {
            if (!IsLogEnabled)
                return;

            try
            {
                var writeDelegate = new WriteDelegate((msg, threadId) =>
                {
                    try
                    {
                        if (Logger.Settings == null)
                        {
                            Logger.Settings = new LogSettings();
                            var LogMode = System.Configuration.ConfigurationManager.AppSettings["LogMode"];

                            if (string.IsNullOrEmpty(LogMode))
                            {
                                Logger.Settings.Mode = LogSettings.LogMode.Normal;
                            }
                            else if (LogMode.Equals("verbose", StringComparison.InvariantCultureIgnoreCase))
                            {
                                Logger.Settings.Mode = LogSettings.LogMode.Verbose;
                            }
                            else
                            {
                                Logger.Settings.Mode = LogSettings.LogMode.Normal;
                            }
                        }

                        if (mode == MsgType.Error)
                        {
                            WriteToFile("<E AT =\"" + DateTime.Now.ToString("dd-MM-yyyy hh:mm:ss.fff tt") + "\" SYS=\"" + getProcInfomation(threadId) + "\" TYP=\"Eror\"" + msg + "</E>");
                        }
                        else if (mode == MsgType.Exception)
                        {
                            WriteToFile("<E AT =\"" + DateTime.Now.ToString("dd-MM-yyyy hh:mm:ss.fff tt") + "\" SYS=\"" + getProcInfomation(threadId) + "\" TYP=\"Excp\"" + msg + "</E>");
                        }
                        else if (mode == MsgType.Warning)
                        {
                            WriteToFile("<E AT =\"" + DateTime.Now.ToString("dd-MM-yyyy hh:mm:ss.fff tt") + "\" SYS=\"" + getProcInfomation(threadId) + "\" TYP=\"Warn\"" + msg + "</E>");
                        }
                        else if (Settings.Mode == LogSettings.LogMode.Verbose)
                        {
                            WriteToFile("<E AT =\"" + DateTime.Now.ToString("dd-MM-yyyy hh:mm:ss.fff tt") + "\" SYS=\"" + getProcInfomation(threadId) + "\" TYP=\"Info\"" + msg + "</E>");
                        }
                    }
                    catch (Exception ex)
                    {

                    }

                });

                writeDelegate.BeginInvoke(message, System.Threading.Thread.CurrentThread.ManagedThreadId, null, null);

            }
            catch (Exception ex)
            {
            }
        }


        private static string getProcInfomation(int SourcethreadID)
        {
            var proc = System.Diagnostics.Process.GetCurrentProcess();
            var sysUsage = string.Format(
                "[T{0}:{1}|M{2}|FM{3}|P{4}]"
                , SourcethreadID.ToString("D3"),
                proc.Threads.Count.ToString("D3"),
                (proc.WorkingSet64 / 1024 / 1024).ToString("F", CultureInfo.InvariantCulture),
                (new Microsoft.VisualBasic.Devices.ComputerInfo().AvailablePhysicalMemory / 1024 / 1024).ToString("F", CultureInfo.InvariantCulture),
                proc.TotalProcessorTime.TotalSeconds.ToString("F", CultureInfo.InvariantCulture)
                );

            return sysUsage;

        }

        private static void WriteToFile(string Line)
        {

            lock (LogFileName)
            {
                StreamWriter sw = null;

                try
                {
                    if (!File.Exists(LogsDirectory + @"\" + LogFileName))
                    {
                        sw = File.CreateText(LogsDirectory + @"\" + LogFileName);
                        sw.WriteLine("<SysInfo>");
                        sw.WriteLine("=============================================== WinX Log File  ==========================================================");
                        sw.WriteLine("HOSTNAME               :" + System.Environment.MachineName);
                        sw.WriteLine("USERNAME               :" + System.Environment.UserName);
                        sw.WriteLine("DOMAIN                 :" + System.Environment.UserDomainName);
                        sw.WriteLine("CLR VERSION            :" + System.Environment.Version.ToString());
                        sw.WriteLine("OS NAME                :" + new Microsoft.VisualBasic.Devices.ComputerInfo().OSFullName);
                        sw.WriteLine("OS VERSION             :" + new Microsoft.VisualBasic.Devices.ComputerInfo().OSVersion);
                        sw.WriteLine("BUILD_NAME             :" + System.Environment.GetEnvironmentVariable("BUTLD_NAME", EnvironmentVariableTarget.Machine));
                        sw.WriteLine("BUILD_VERSION          :" + System.Environment.GetEnvironmentVariable("BUILD_VERSION", EnvironmentVariableTarget.Machine));
                        sw.WriteLine("BUILD_DATE             :" + System.Environment.GetEnvironmentVariable("BUILD_DATE", EnvironmentVariableTarget.Machine));
                        sw.WriteLine("BUILD_FINISHED         :" + System.Environment.GetEnvironmentVariable("BUILD_FINISHED", EnvironmentVariableTarget.Machine));
                        sw.WriteLine("BUILD_COUNTRY          :" + System.Environment.GetEnvironmentVariable("BUILD_COUNTRY", EnvironmentVariableTarget.Machine));
                        sw.WriteLine("BUILD_MTYPE            :" + System.Environment.GetEnvironmentVariable("BUILD_MTYPE", EnvironmentVariableTarget.Machine));
                        sw.WriteLine("BUILD_RUNFROMTS        :" + System.Environment.GetEnvironmentVariable("BUILD_RUNFROMTS", EnvironmentVariableTarget.Machine));
                        sw.WriteLine("BUILDAPPSVER           :" + System.Environment.GetEnvironmentVariable("BUILDAPPSVER", EnvironmentVariableTarget.Machine));
                        sw.WriteLine("PROCESSOR_ARCHITECTURE :" + System.Environment.GetEnvironmentVariable("PROCESSOR_ARCHITECTURE", EnvironmentVariableTarget.Machine));
                        sw.WriteLine("PROCESSOR_IDENTIFIER   :" + System.Environment.GetEnvironmentVariable("PROCESSOR_IDENTIFIER=", EnvironmentVariableTarget.Machine));
                        sw.WriteLine("PROCESSOR_COUNT        :" + System.Environment.GetEnvironmentVariable("PROCESSOR_COUNT", EnvironmentVariableTarget.Machine));
                        sw.WriteLine("TOTAL PMEMORY          :" + new Microsoft.VisualBasic.Devices.ComputerInfo().TotalPhysicalMemory);
                        sw.WriteLine("TOTAL VMEMORY          :" + new Microsoft.VisualBasic.Devices.ComputerInfo().TotalVirtualMemory);
                        sw.WriteLine("AVAIL PMEMORY          :" + new Microsoft.VisualBasic.Devices.ComputerInfo().AvailablePhysicalMemory);
                        sw.WriteLine("UI CULTURE             :" + new Microsoft.VisualBasic.Devices.ComputerInfo().InstalledUICulture.DisplayName);
                        sw.WriteLine("CREATED AT          :" + DateTime.Now.ToString());
                        sw.WriteLine("=============================================================================================================================");
                        sw.WriteLine("</SysInfo>");
                        sw.Flush();
                        sw.Close();
                    }

                    sw = File.AppendText(LogsDirectory + @"\" + LogFileName);
                    sw.WriteLine(Line);
                    sw.Flush();
                    sw.Close();
                }
                catch (Exception ex)
                {

                }
                finally
                {
                    if (sw != null)
                    {
                        sw.Close();
                        sw = null;
                    }
                }
            }
        }
    }

    public partial class LogSettings
    {
        public enum LogMode : int
        {
            Normal = 1,
            Verbose = 2
        }

        public LogSettings.LogMode Mode;

        public int MaxLogSize = 1;

    }
}
