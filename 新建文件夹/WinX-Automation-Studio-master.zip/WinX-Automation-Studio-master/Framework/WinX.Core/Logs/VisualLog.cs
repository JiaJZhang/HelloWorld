﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading;

namespace WinX.Core
{
    public static partial class VisualLog
    {
        public static ObservableCollection<VisualLogEntry> LogEntries;

        private static ObservableCollection<object> lstWaitHandles;

        public delegate void OnWaitDelegate(object source, int timeLeftInSec);
        public delegate void OnWaitCompleteDelegate(object source);

        public static event OnWaitDelegate Wait;
        public static event OnWaitCompleteDelegate WaitComplete;

        public static void OnWait(object source, int timeLeftInSec)
        {
            if (Wait != null)
            {
                Wait(source, timeLeftInSec);
            }
        }
        public static void OnWaitComplete(object source)
        {
            if (WaitComplete != null)
            {
                WaitComplete(source);
            }
        }

        public static int WaitHandles
        {
            get
            {
                return lstWaitHandles.Count();
            }
        }

        public static bool Cancelled = false;

        public static void RaiseOnWaitEvent(object source, int timeLeftInSec, object waitHandle)
        {
            try
            {
                Cancelled = false;
                var objWait = new OnWaitDelegate((s, t) =>
                {
                    try
                    {
                        dynamic obj = s;

                        OnWait(s, t);
                        var entry = LogEntries.Where(m => m.ID == obj.ID).FirstOrDefault();

                        if (entry == null)
                        {
                            LogEntries.Add(new VisualLogEntry()
                            {
                                ID = obj.ID,
                                Source = s,
                                TimeLeftInSec = t
                            });
                        }
                        else
                        {
                            entry.ID = obj.ID;
                            entry.Source = s;
                            entry.TimeLeftInSec = t;
                        }
                    }
                    catch (Exception ex)
                    {
                        Logger.Write(ex, "There was an exception on the OnWaitDelegate.");
                    }

                });

                objWait.BeginInvoke(source, timeLeftInSec, null, null);

                if (waitHandle != null && !lstWaitHandles.Contains(waitHandle))
                {
                    lstWaitHandles.Add(waitHandle);
                }
            }
            catch (Exception ex)
            {
                Logger.Write(ex, "There was an exception while processing 'OnWaitEvent'.");
            }
        }

        public static void RaiseWaitCompleteEvent(object source, object waitHandle)
        {
            try
            {
                var objWait = new OnWaitCompleteDelegate(s =>
                {
                    try
                    {
                        dynamic obj = s;

                        OnWaitComplete(s);


                        var entry = LogEntries.Where(m => m.ID == obj.ID).FirstOrDefault();

                        if(entry != null)
                        {
                            LogEntries.Remove(entry);
                        }
                    }
                    catch (Exception ex)
                    {
                        Logger.Write(ex, "There was an exception on the OnWaitCompleteDelegate");
                    }
                });

                objWait.BeginInvoke(source, null, null);
                if (waitHandle != null && !lstWaitHandles.Contains(waitHandle))
                {
                    lstWaitHandles.Add(waitHandle);
                }
            }
            catch(Exception ex)
            {
                Logger.Write(ex, "There was an exception while processing 'WaitCompleteEvent'.");
            }
        }

        public static void CancelAllWaits()
        {
            try
            {
                foreach(var obj in lstWaitHandles)
                {
                    if(obj != null && obj is ManualResetEvent)
                    {
                        ((ManualResetEvent)obj).Set();
                    }
                    else if (obj != null && obj is AutoResetEvent)
                    {
                        ((AutoResetEvent)obj).Set();
                    }
                }
                Cancelled = true;
            }
            catch(Exception ex)
            {
                Logger.Write(ex, "There was an exception while processing 'CancelAllWaits'.");
            }
        }



    }

    public partial class VisualLogEntry : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged(string propertyName)
        {
            if (this.PropertyChanged != null)
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        private object id;
        public object ID
        {
            get
            {
                return id;
            }
            set
            {
                this.id = value;
                NotifyPropertyChanged("ID");
            }
        }

        private object source;
        public object Source
        {
            get
            {
                return source;
            }
            set
            {
                this.source = value;
                NotifyPropertyChanged("Source");
            }
        }


        private int timeLeftInSec;
        public int TimeLeftInSec
        {
            get
            {
                return timeLeftInSec;
            }
            set
            {
                this.timeLeftInSec = value;
                NotifyPropertyChanged("TimeLeftInSec");
            }
        }


        private string status;
        public string Status
        {
            get
            {
                return status;
            }
            set
            {
                this.status = value;
                NotifyPropertyChanged("Status");
            }
        }
    }

}
