﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace WinX.Core
{
    [Serializable]
    [TypeConverter(typeof(OptionsConverter))]
    public partial class Field : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged(string propertyName)
        {
            if (this.PropertyChanged != null)
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        public string ElementType
        {
            get; set;
        }

        [Browsable(false)]
        public Guid ID
        {
            get; set;
        }

        [Browsable(false)]
        public Guid ApplicationID
        {
            get; set;
        }

        [Browsable(false)]
        public Guid ScreenID
        {
            get; set;
        }

        private bool status;

        [Browsable(false), XmlIgnore()]

        public bool Status
        {
            get
            {
                return status;
            }
            set
            {
                this.status = value;
                NotifyPropertyChanged("Status");
            }
        }

        private int targetsCount;


        [Browsable(false), XmlIgnore()]

        public int TargetsCount
        {
            get
            {
                return targetsCount;
            }
            set
            {
                this.targetsCount = value;
                NotifyPropertyChanged("TargetsCount");
            }
        }

        private string name;
        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                this.name = value;
                NotifyPropertyChanged("Name");
            }
        }

        public string Description
        {
            get; set;
        }

        private int timeoutInSec = 30;
        public int TimeoutInSec
        {
            get
            {
                return this.timeoutInSec;
            }
            set
            {
                this.timeoutInSec = value;
            }
        }

        private ObservableCollection<MatchRule> pMatchRules = new ObservableCollection<MatchRule>();

        public ObservableCollection<MatchRule> MatchRules
        {
            get
            {
                return pMatchRules;
            }
            set
            {
                pMatchRules = value;
            }
        }

    }
}
