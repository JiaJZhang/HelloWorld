﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace WinX.Core
{
    [Serializable]
    [TypeConverter(typeof(OptionsConverter))]
    public abstract partial class Screen : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged(string propertyName)
        {
            if (this.PropertyChanged != null)
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        private bool status;


        [Browsable(false), XmlIgnore()]

        public bool Status
        {
            get
            {
                return status;
            }
            set
            {
                this.status = value;
                NotifyPropertyChanged("Status");
            }
        }

        private int targetsCount;


        [Browsable(false), XmlIgnore()]

        public int TargetsCount
        {
            get
            {
                return targetsCount;
            }
            set
            {
                this.targetsCount = value;
                NotifyPropertyChanged("TargetsCount");
            }
        }

        private string name;
        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                this.name = value;
                NotifyPropertyChanged("Name");
            }
        }

        [Browsable(false)]
        public Guid ID
        {
            get; set;
        }

        [Browsable(false)]
        public Guid ApplicationID
        {
            get; set;
        }

        public string Description
        {
            get; set;
        }
        

        private int timeoutInSec = 30;
        public int TimeoutInSec
        {
            get
            {
                return this.timeoutInSec;
            }
            set
            {
                this.timeoutInSec = value;
            }
        }

        private ObservableCollection<Field> pFields = new ObservableCollection<Field>();

        public ObservableCollection<Field> Fields
        {
            get
            {
                return pFields;
            }
            set
            {
                pFields = value;
            }
        }

        private ObservableCollection<MatchRule> pMatchRules = new ObservableCollection<MatchRule>();

        public ObservableCollection<MatchRule> MatchRules
        {
            get
            {
                return pMatchRules;
            }
            set
            {
                pMatchRules = value;
            }
        }

        public abstract bool Refresh(bool MatchAllChildern = false);

        public Screen()
        {
            if(this.GetType().BaseType.BaseType.Equals(typeof(WinX.Core.Screen)))
            {
                var assembly = this.GetType().Assembly;

                if (assembly != null)
                {
                    var ResArr = assembly.GetManifestResourceNames();
                    var fileName = this.GetType().FullName.Replace("+", ".") + ".WINX";

                    var WinxFile = ResArr.Where(x => x.Equals(fileName, StringComparison.InvariantCultureIgnoreCase) || sbyte.Equals(this.GetType().Name + "WINX", StringComparison.InvariantCultureIgnoreCase)).FirstOrDefault();

                    if (WinxFile != null)
                    {
                        try
                        {
                            var derivedTypes = ReflectionHelper.FindDerivedTypes(this.GetType().BaseType.Assembly, typeof(Application),
                                                                                                                    typeof(Screen),
                                                                                                                    typeof(Field),
                                                                                                                    typeof(MatchRule));

                            if (derivedTypes != null)
                            {
                                var formatter = new System.Xml.Serialization.XmlSerializer(this.GetType().BaseType, derivedTypes.ToArray());
                                dynamic doc = formatter.Deserialize(assembly.GetManifestResourceStream(WinxFile));
                                if (doc != null)
                                {
                                    this.ID = doc.ID;
                                    this.Fields = doc.Fields;
                                    this.MatchRules = doc.MatchRules;
                                    this.name = doc.Name;
                                    this.ApplicationID = doc.ApplicationID;
                                }
                                else
                                {
                                    throw new Exception("There was an error while trying to descrialize resource '" + WinxFile + "'.");
                                }
                            }
                            else
                            {
                                throw new Exception("Derived adapter types are empty,can not deserialize resource '" + WinxFile + "'.");
                            }
                        }
                        catch (Exception ex)
                        {
                            throw new Exception("The resource '" + WinxFile + "' could not be deserialized to an object." + ex);
                        }
                    }
                    else
                    {
                        throw new Exception("No WinxX resource found with the name '" + fileName + "' in the assembly '" + assembly.FullName + "',Resources -> [" + ResArr.ToString());
                    }
                }
            }
        }

        public virtual bool WaitForCreate(int timeoutInSeconds = 30,bool MatchAllChildern = false)
        {
            return false;
        }

        public virtual object GetField(Guid Id)
        {
            return null;
        }

        public virtual List<object> GetFields(Guid Id)
        {
            return null;
        }

        public override string ToString()
        {
            return string.Concat(Name, "(", base.ToString(), ")");
        }
    }
}
