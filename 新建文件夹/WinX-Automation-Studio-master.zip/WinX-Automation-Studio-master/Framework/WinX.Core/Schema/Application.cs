﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace WinX.Core
{
    [Serializable]
    public enum ApplicationType : int
    {
        Generic =1,
        Web =2 ,
        Pcom = 3
    }

    [Serializable]
    [TypeConverter(typeof(OptionsConverter))]
    public partial class Application : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        public Application()
        {

        }

        private void NotifyPropertyChanged(string propertyName)
        {
            if (this.PropertyChanged != null)
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }


        [Browsable(false)]
        public Guid ID
        {
            get; set;
        }

        private string name;

        [Browsable(false)]
        public string Name
        {
            get
            {
                return this.name;
            }
            set
            {
                this.name = value;
                NotifyPropertyChanged("Name");
            }
        }


        private string description;

        [Browsable(false)]
        public string Description
        {
            get
            {
                return this.description;
            }
            set
            {
                this.description = value;
                NotifyPropertyChanged("Description");
            }
        }


        private ApplicationType type;

        [Browsable(false)]
        public ApplicationType Type
        {
            get
            {
                return this.type;
            }
            set
            {
                this.type = value;
                NotifyPropertyChanged("Type");
            }
        }

        private System.Collections.ObjectModel.ObservableCollection<Screen> pScreens = new System.Collections.ObjectModel.ObservableCollection<Screen>();

        [Browsable(false)]
        public System.Collections.ObjectModel.ObservableCollection<Screen> Screens
        {
            get
            {
                return pScreens;
            }
            set
            {
                pScreens = value;
            }

        }

        protected object GetScreen(Guid ID)
        {
            return this.Screens.Where(s => s.ID == ID).FirstOrDefault();
        }

        public override string ToString()
        {
            return string.Concat(name, "(", base.ToString(), ")");
        }
    }
}
