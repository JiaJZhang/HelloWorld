﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace WinX.Core
{
    [TypeConverter(typeof(OptionsConverter))]
    public partial class Table
    {
        public List<Row> Rows = new List<Row>();

        public override string ToString()
        {
            var result = "NULL";

            try
            {
                result = XmlSerializer.Serializer(this, typeof(Table), typeof(Row), typeof(Cell));
            }
            catch (Exception ex)
            {

            }

            return result;
        }
    }


    [Serializable]
    public partial class Row
    {
        public bool IsHeader = false;
        public List<Cell> Cells = new List<Cell>();

        public override string ToString()
        {

            var result = "NULL";

            try
            {
                foreach (var cell in Cells)
                {
                    if (result.Equals("NULL"))
                    {
                        result = cell.ToString();
                    }
                    else
                    {
                        result += "," + cell.ToString();
                    }
                }
            }
            catch (Exception ex)
            {

            }

            return result;

        }

    }


    public partial class Cell
    {
        public string Name
        {
            get;set;
        }

        public int Row
        {
            get; set;
        }

        public int Col
        {
            get; set;
        }

        public int Length
        {
            get; set;
        }


        public string Value
        {
            get; set;
        }

        public override string ToString()
        {
            return string.Format("'{0}'", Value);
        }
    }


}
