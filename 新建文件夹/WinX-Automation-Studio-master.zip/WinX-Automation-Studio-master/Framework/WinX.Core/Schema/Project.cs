﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Management;
using System.Text;

namespace WinX.Core
{
    [TypeConverter(typeof(OptionsConverter))]
    public partial class Project : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged(string propertyName)
        {
            if (this.PropertyChanged != null)
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }


        [Browsable(false), ReadOnly(true)]
        public Guid ID
        {
            get; set;
        }

        private string pName;

        [ReadOnly(true)]
        public string Name
        {
            get
            {
                return pName;
            }
            set
            {
                this.pName = value;
                NotifyPropertyChanged("Name");
            }
        }

        private string pDescription;
        public string Description
        {
            get
            {
                return pDescription;
            }
            set
            {
                this.pDescription = value;
                NotifyPropertyChanged("Description");
            }
        }

        private ObservableCollection<Application> pApplications = new ObservableCollection<Application>();

        [ReadOnly(true), Browsable(false)]
        public ObservableCollection<Application> Applications
        {
            get
            {
                return pApplications;
            }
            set
            {
                pApplications = value;
            }

        }

        public override string ToString()
        {
            return string.Concat(Name, "(", base.ToString(), ")");
        }

        [Browsable(false), ReadOnly(true)]
        public string Company
        {
            get
            {
                return "Dada PP";
            }
        }


        [Browsable(false), ReadOnly(true)]
        public string Copyright
        {
            get
            {
                return "WinX,(c) All rights reserved.";
            }
        }

        [Browsable(false), ReadOnly(true)]
        public string Trademark
        {
            get
            {
                return "WinX";
            }
        }

        private double mBuildVersion = 1.0f;

        [Browsable(false), ReadOnly(true)]
        public double BuildVersion
        {
            get
            {
                return mBuildVersion;
            }
            set
            {
                mBuildVersion = value;
            }
        }

        [Browsable(false), ReadOnly(true)]
        public string DotNetRuntimeVersion
        {
            get
            {
                return "4.0";
            }
        }

        public static void Terminate(int parentProcessId = 0)
        {
            try
            {
                if (parentProcessId == 0)
                {
                    parentProcessId = Process.GetCurrentProcess().Id;
                }

                Logger.Write("Finding processes spawned by WinX Project");

                var searcher = new ManagementObjectSearcher("SELECT * FROM Win32_Process WHERE ParentProcessId=" + parentProcessId);
                var collection = searcher.Get();
                if (collection.Count > 0)
                {
                    Logger.Write("Terminating [" + collection.Count + "] processes spawned by process WinX project.");

                    foreach (var item in collection)
                    {
                        var childProcessId = (Int32)item["ProcessId"];
                        if (childProcessId != Process.GetCurrentProcess().Id)
                        {
                            Terminate(childProcessId);

                            var childProcess = Process.GetProcessById(childProcessId);
                            Logger.Write("Terminating child process [" + childProcess.ProcessName + "] with Id [" + childProcessId + "]");
                            childProcess.Kill();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Write(ex, "There was an exception while trying to terminate processes spawned by WinX project.");
            }
        }
    }
}
