﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;

namespace WinX.Core
{
    public partial class XmlSerializer
    {
        public static string Serializer(object data, Type dataType, params Type[] eXtraTypes)
        {
            var xmlDoc = new XmlDocument();

            var xmlSerializer = new System.Xml.Serialization.XmlSerializer(dataType, eXtraTypes);

            using (var xmlStream = new MemoryStream())
            {
                xmlSerializer.Serialize(xmlStream, data);
                xmlStream.Position = 0;
                xmlDoc.Load(xmlStream);
            }

            return xmlDoc.InnerXml;
        }

        public static object Deserialize(string xml, Type dataType, params Type[] eXtraTypes)
        {
            object result = null;
            var reader = new System.IO.StringReader(xml);
            var xmlSerializer = new System.Xml.Serialization.XmlSerializer(dataType, eXtraTypes);

            result = xmlSerializer.Deserialize(reader);
            reader.Close();
            return result;
        }

    }
}
