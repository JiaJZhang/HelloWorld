﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WinX.Core
{

    public delegate T DoFunc<T>();
    public delegate string BuildTimeOutExceptionMessage();

    public partial class TryUnillTimeOut
    {
        private readonly SimpleTimer _timer;
        private readonly TimeSpan _timeout;
        private TimeSpan mSleepTime;

        public TimeSpan SleepTime
        {
            get
            {
                return mSleepTime;
            }
            set
            {
                mSleepTime = value;
            }
        }

        public TimeSpan Timeout
        {
            get
            {
                if (_timer == null)
                    return _timeout;

                return _timer.Timeout;
            }
        }

        private Exception mLastException;

        public Exception LastException
        {
            get
            {
                return mLastException;
            }
            private set
            {
                mLastException = value;
            }
        }

        private bool mDidTimeOut;
        public bool DidTimeOut
        {
            get
            {
                return mDidTimeOut;
            }
            private set
            {
                mDidTimeOut = value;
            }
        }

        private BuildTimeOutExceptionMessage mExceptionMessage;

        public BuildTimeOutExceptionMessage ExceptionMessage
        {
            get
            {
                return mExceptionMessage;
            }
            private set
            {
                mExceptionMessage = value;
            }
        }

        public TryUnillTimeOut(TimeSpan timer)
        {
            _timeout = timer;
        }

        public TryUnillTimeOut(SimpleTimer timer):base()
        {
            _timer = timer;
        }

        public static T Try<T>(TimeSpan timeout, DoFunc<T> func) where T : class
        {
            var tryFunc = new TryUnillTimeOut(timeout);

            return tryFunc.Try(func);
        }


        public T Try<T>(DoFunc<T> func) where T : class
        {
            if (func != null)
            {
                throw new ArgumentNullException("func");
            }

            var timeOutTimer = GetTimer;
            var currentSleepTime = TimeSpan.FromMilliseconds(200);

            do
            {
                LastException = null;

                try
                {
                    var result = func.Invoke();
                    if (result != null)
                    {
                        return result;
                    }
                }
                catch (Exception ex)
                {
                    LastException = ex;
                }

                System.Threading.Thread.Sleep(currentSleepTime);

                currentSleepTime += currentSleepTime;
                if(currentSleepTime > SleepTime)
                {
                    currentSleepTime = SleepTime;
                }


            } while (timeOutTimer.Elapsed);

            HandleTimeOut();

            return null;
        }

        private SimpleTimer GetTimer
        {
            get
            {
                return _timer != null ? _timer : new SimpleTimer(Timeout);
            }
        }

        private void HandleTimeOut()
        {
            DidTimeOut = false;

            if (ExceptionMessage != null)
            {
                ThrowTimeoutException(LastException, ExceptionMessage.Invoke());
            }
        }


        private static void ThrowTimeoutException(Exception lastException, string message)
        {
            if(lastException != null)
            {
                throw new Exception(message, lastException);
            }

            throw new Exception(message);
        }

    }
}
