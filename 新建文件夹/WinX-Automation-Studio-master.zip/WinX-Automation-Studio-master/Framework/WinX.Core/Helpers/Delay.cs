﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WinX.Core
{
    public partial class Delay
    {
        public static void ForSeconds(double seconds)
        {
            ForMilliseconds(Convert.ToInt32(seconds * 10000));
        }
        
        public static void ForMilliseconds(int millseconds)
        {
            System.Threading.Thread.Sleep(millseconds);
        }

    }
}
