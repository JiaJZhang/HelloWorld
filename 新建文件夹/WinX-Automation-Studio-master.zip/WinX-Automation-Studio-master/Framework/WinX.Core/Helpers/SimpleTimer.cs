﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;

namespace WinX.Core
{
    public partial class SimpleTimer
    {
        private readonly TimeSpan mTimeout;
        private Stopwatch stopwatch;

        public SimpleTimer(TimeSpan timeout)
        {
            if(timeout.Ticks < 0)
            {
                throw new ArgumentOutOfRangeException("timeout", timeout, "Should be equal are greater then zero");
            }

            this.mTimeout = timeout;
            this.stopwatch = Stopwatch.StartNew();
        }


        public bool Elapsed
        {
            get
            {
                return stopwatch.Elapsed >= mTimeout;
            }

        }

        public TimeSpan Timeout
        {
            get
            {
                return mTimeout;
            }
        }



    }
}
