﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WinX.Core
{
    public partial class Validator
    {
        public static bool IsAlphaNumber(string strToCheck)
        {
            if(strToCheck.Length == 0)
            {
                return false;
            }

            if(Microsoft.VisualBasic.Information.IsNumeric(strToCheck.Substring(0,1)))
            {
                return false;
            }

            var parttern = new System.Text.RegularExpressions.Regex("[^a-zA-Z0-9]");
            return !parttern.IsMatch(strToCheck);

        }

    }
}
