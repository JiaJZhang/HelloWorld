﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WinX.Core
{
    public partial class JsonSerializer
    {
        public string Serialize(object objData)
        {
            var oSerializer = new System.Web.Script.Serialization.JavaScriptSerializer();
            return oSerializer.Serialize(objData);
        }

        //public object Deserialize(string objStr, Type objType)
        //{
        //    var oSerializer = new System.Web.Script.Serialization.JavaScriptSerializer();
        //    return oSerializer.Deserialize(objStr, objType);
        //}

        public T Deserialize<T>(string objStr)
        {
            var oSerializer = new System.Web.Script.Serialization.JavaScriptSerializer();
            var result = oSerializer.Deserialize<T>(objStr);
            return result;
        }        
    }
}