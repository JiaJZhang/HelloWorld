﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WinX.Core
{
    public partial class Clock
    {
        public static void Run(Action action,Action timeoutAction, int timeout = 30000)
        {
            var result = action.BeginInvoke(null, null);

            if(result.AsyncWaitHandle.WaitOne(timeout))
            {
                action.EndInvoke(result);
            }
            else if(timeoutAction != null)
            {
                timeoutAction.Invoke();
            }
        }
    }
}
