﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WinX.Core
{
    public partial class TextParser
    {
        public static Table ParseData(string strText, int[] fieldsWidths, bool firstRowIsHeader = false, int stratRow = 0, int startCol = 0)
        {
            if (string.IsNullOrEmpty(strText))
            {
                return null;
            }

            var regExFormat = "";

            foreach (var fw in fieldsWidths)
            {
                regExFormat += "(.{" + fw + "})";
            }

            var table = new Table();

            var matches = System.Text.RegularExpressions.Regex.Matches(strText, regExFormat);
            var rowIndex = 0;

            foreach (System.Text.RegularExpressions.Match match in matches)
            {
                var row = new Row();

                if (rowIndex == 0 && firstRowIsHeader)
                {
                    row.IsHeader = true;
                }

                var length = 0;

                for (var i = 1; i < matches.Count; i++)
                {
                    var group = match.Groups[i];

                    if (group != null)
                    {
                        row.Cells.Add(new Cell()
                        {
                            Value = group.Value,
                            Length = group.Length,
                            Row = stratRow + rowIndex,
                            Col = startCol + length

                        });

                        length += 1;
                    }
                }

                table.Rows.Add(row);
                rowIndex += 1;
            }

            return table;
        }
    }
}
