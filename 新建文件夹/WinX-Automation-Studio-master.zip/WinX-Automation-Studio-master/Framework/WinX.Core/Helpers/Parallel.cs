﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace WinX.Core
{
    public partial class Parallel
    {
        public Parallel(int threadCount,bool waitForallComplete = false )
        {
            this.ThreadsCount = threadCount;
            this.WaitForallComplete = waitForallComplete;
        }

        public delegate bool ForLoopBody(int index);
        public delegate bool ForLoopBodyByPassParameters(int index, object parameters);

        private int m_ThreadsCount = System.Environment.ProcessorCount;
        private object sync = new object();

        private Parallel m_Instance = null;
        private Thread[] threads;


        private AutoResetEvent[] jobAvailable;
        private ManualResetEvent[] threadIdle;

        private int currentIndex;
        private int stopIndex;
        private ForLoopBody loopBody;
        private ForLoopBodyByPassParameters loopBodyByPassParameters;

        public int ThreadsCount
        {
            get
            {
                return m_ThreadsCount;
            }
            set
            {
                lock(sync)
                {
                    m_ThreadsCount = System.Math.Max(1, value);
                }
            }
        }

        public bool mWaitForallComplete;

        public bool WaitForallComplete
        {
            get
            {
                return mWaitForallComplete;
            }
            set
            {
                mWaitForallComplete = value;
            }
        }

        public void For(int start, int stop, ForLoopBody loopBody)
        {
            lock (sync)
            {
                var instance = Instance;
                instance.currentIndex = start - 1;

                instance.stopIndex = stop;
                instance.loopBody = loopBody;


                for (int i = 0; i < m_ThreadsCount; i++)
                {
                    instance.threadIdle[i].Reset();
                    instance.jobAvailable[i].Set();
                }

                for (int i = 0; i < m_ThreadsCount; i++)
                {
                    instance.threadIdle[i].WaitOne();
                }
            }
        }

        public void For(int start, int stop, ForLoopBodyByPassParameters loopBody)
        {
            lock (sync)
            {
                var instance = Instance;
                instance.currentIndex = start - 1;

                instance.stopIndex = stop;
                //instance.loopBody = loopBody;
                instance.loopBodyByPassParameters = loopBody;
                
                for (int i = 0; i < m_ThreadsCount; i++)
                {
                    instance.threadIdle[i].Reset();
                    instance.jobAvailable[i].Set();
                }

                for (int i = 0; i < m_ThreadsCount; i++)
                {
                    instance.threadIdle[i].WaitOne();
                }
            }
        }

        public Parallel Instance
        {
            get
            {
                if (m_Instance == null)
                {
                    m_Instance = new Parallel(this.ThreadsCount);
                    m_Instance.Initialize();
                }
                else if (m_Instance.threads.Length != m_ThreadsCount)
                {
                    m_Instance.Terminate();

                    m_Instance.Initialize();
                }
                return m_Instance;
            }
        }

        public void Terminate()
        {
            loopBody = null;
            var i = 0;
            var threadsCount = threads.Length;

            while(i < threadsCount)
            {
                jobAvailable[i].Set();
                threads[i].Join();

                jobAvailable[i].Close();
                threadIdle[i].Close();

                i += 1;
            }

            jobAvailable = null;
            threadIdle = null;
            threads = null;
        }

        private void Initialize()
        {
            jobAvailable = new AutoResetEvent[m_ThreadsCount - 1];
            threadIdle = new ManualResetEvent[m_ThreadsCount - 1];

            threads = new Thread[m_ThreadsCount - 1];

            for (int i = 0; i < m_ThreadsCount; i++)
            {
                jobAvailable[i] = new AutoResetEvent(false);
                threadIdle[i] = new ManualResetEvent(true);

                threads[i] = new Thread(new ParameterizedThreadStart(WorkerThread));
                threads[i].Name = "OCR.Parallel";
                threads[i].IsBackground = true;
                threads[i].Start(i);
            }
        }

        public void WorkerThread(object index)
        {
            var threadIndex = Convert.ToInt32(index);
            var localIndex = 0;
            var isOneComplete = false;

            while(true)
            {
                jobAvailable[threadIndex].WaitOne();

                if(loopBody == null)
                {
                    return;
                }

                while (true)
                {
                    localIndex = Interlocked.Increment(ref currentIndex);

                    if(localIndex >= stopIndex)
                    {
                        return;
                    }

                    isOneComplete = loopBody(localIndex);
                    if (isOneComplete && !WaitForallComplete)
                    {
                        return;
                    }
                }

            }
            threadIdle[threadIndex].Set();
        }        
    }
}