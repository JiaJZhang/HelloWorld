﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WinX.Core
{
    public enum CodeType : int
    {
        EXE = 0,
        DLL = 1,
        VB = 2,
        CSharp = 3,
        Javascript = 4,

    }
}
