﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;

namespace WinX.Core
{
    public partial class NativeMethods
    {
        public NativeMethods()
        {

        }

        [StructLayout(LayoutKind.Sequential)]
        public struct POINT
        {
            public int X
            {
                get;
                set;
            }

            public int Y
            {
                get;
                set;
            }


            public POINT(int x, int y)
            {
                this.X = x;
                this.Y = y;

            }

            public static bool operator ==(POINT p1, POINT p2)
            {
                return p1.X == p2.X && p1.Y == p2.Y;

            }

            public static bool operator !=(POINT p1, POINT p2)
            {
                return p1.X != p2.X || p1.Y != p2.Y;
            }

            public override bool Equals(object obj)
            {
                if (ReferenceEquals(obj, null))
                    return false;

                if (!obj.GetType().Equals(typeof(object)))
                {
                    return false;
                }

                POINT other = (POINT)obj;
                var result = false;
                if (other != null)
                {
                    result = other.X == X && other.Y == Y;
                }
                return result;
            }


            public override int GetHashCode()
            {
                return X * 397 ^ Y;
            }
        }

        [DllImport("user32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool GetCursorPos(out POINT lpPoint);


        [DllImport("user32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool InvalidateRect(IntPtr hWnd, IntPtr lpRect, bool bErase);


        [DllImport("user32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool UpdateWindow(IntPtr hWnd);


        [DllImport("user32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool ScreenToClient(IntPtr hWnd, POINT lpPonint);

    }
}
