﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;

namespace WinX.Core
{
    public partial class Desktop
    {
        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        public static extern IntPtr GetDC(IntPtr hWnd);


        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        /// <summary>
        /// 函数释放设备上下文环境（DC）供其他应用程序使用。
        /// </summary>
        public static extern int ReleaseDC(IntPtr hWnd, IntPtr hDC);


        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        /// <summary>
        /// 该函数返回桌面窗口的句柄。桌面窗口覆盖整个屏幕。
        /// </summary>
        static public extern IntPtr GetDesktopWindow();


        public static void DrawRect(IntPtr windowHandle,Rectangle rect)
        {
            var hwnd = GetDesktopWindow();

            using (var graphics = Graphics.FromHwnd(hwnd))
            {
                var p = new NativeMethods.POINT(rect.X, rect.Y);

                NativeMethods.ScreenToClient(windowHandle, p);

                var r = new Rectangle(rect.X, rect.Y, rect.Width, rect.Height);

                NativeMethods.InvalidateRect(windowHandle, IntPtr.Zero, true);

                NativeMethods.UpdateWindow(windowHandle);

                var highlightPan = new Pen(Color.Red, 3);

                graphics.DrawRectangle(highlightPan, r);

            }


        }

    }
}
