﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WinX.Core
{
    public partial class Contants
    {
        public const string WINX_FILTER = "WinX Project(*.winpx)|*.winpx";

        public const string WIN_INFO = "Information";
        public const string WIN_INVALID = "Invalid";
        public const string WIN_ERROR = "Error";
        public const string WIN_CONFIRM = "Confirmation";

        public const string MSG_APP_EMPTY = "Application has not been created.";
        public const string MSG_INVLD_FLD_Name = "Invalid name entered,This must be alphanumeric and started with alpha";
        public const string MSG_DEL_ELE = "Are you sure of removing the element?";
        public const string MSG_SEL_ELE = "Please select and element first.";
        public const string MSG_DEL_RULE = "Are you sure of removing the match rule?";
        public const string MSG_DEL_FLD = "Are you sure of removing the field?";
        public const string MSG_DEL_SCRN = "Are you sure of deleting the screen?";
        public const string MSG_DEL_PAGE = "Are you sure of deleting the page?";
        public const string MSG_SEL_Page = "Please select a page";
        public const string MSG_BIND_WEB = "Please bind the website";
        public const string MSG_SEL_FLD = "Please select a field.";
        public const string MSG_ELE_NOT_FND = "No Target Element";

        public const string MSG_WINX_FILE_EXISTS = "WinX file({0}) is already exists. would you like to replace with a new one?";


    }
}
