﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;

namespace WinX.Core
{
    public partial class ReflectionHelper
    {
        public static List<Type> FindDerivedTypes(Assembly assembly,params Type[] baseType)
        {
            var lstTypes = new List<Type>();

            foreach (var tbp in baseType)
            {
                var tmpBtype = tbp;

                var types = assembly.GetTypes().Where(m => m.BaseType != null && m.BaseType.Equals(tmpBtype));

                if (types != null && types.Count() > 0)
                {
                    foreach (var t in types)
                    {
                        if (!lstTypes.Contains(t))
                        {
                            lstTypes.Add(t);
                        }
                    }
                }
            }

            return lstTypes;
        }

        public static string GetWinXRootPath()
        {
            var dirPath = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);

            var winXFolder = dirPath + @"\WinX\";

            return winXFolder;


        }

    }
}
