﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;

namespace WinX.Core
{
    public partial class Serializers
    {
        public static Byte[] ObjectToBytes(object objData, Type dataType)
        {
            return System.Text.Encoding.UTF8.GetBytes(ObjectToXML(objData, dataType));
        }


        public static object StreamToObject(Stream objStream, Type dataType)
        {
            try
            {
                var formatter = new System.Xml.Serialization.XmlSerializer(dataType);

                return formatter.Deserialize(objStream);
            }
            catch (Exception ex)
            {
                throw new System.Exception("There was an Exception while trying to convert stream to object. Exception:" + ex.Message + " | Stacktrace:" + ex.StackTrace);
            }
        }

        public static object StreamToObject(Stream objStream, Type dataType, params Type[] eXtraType)
        {
            try
            {
                var formatter = new System.Xml.Serialization.XmlSerializer(dataType, eXtraType);

                return formatter.Deserialize(objStream);
            }
            catch (Exception ex)
            {
                throw new System.Exception("There was an Exception while trying to convert stream to object. Exception:" + ex.Message + " | Stacktrace:" + ex.StackTrace);
            }
        }

        public static MemoryStream ObjectToStream(object objData, Type dataType, params Type[] eXtraType)
        {
            try
            {
                var formatter = new System.Xml.Serialization.XmlSerializer(dataType, eXtraType);

                var stream = new MemoryStream();

                formatter.Serialize(stream, objData);

                stream.Position = 0;

                return stream;
            }
            catch (Exception ex)
            {
                throw new System.Exception("There was an Exception while trying to convert stream to object. Exception:" + ex.Message + " | Stacktrace:" + ex.StackTrace);
            }
        }

        public static byte[] ObjectToBytes(object data, Type dataType, params Type[] eXtraType)
        {
            try
            {
                return ObjectToStream(data, dataType, eXtraType).ToArray();
            }
            catch (Exception ex)
            {
                throw new System.Exception("There was an Exception while trying to convert stream to object. Exception:" + ex.Message + " | Stacktrace:" + ex.StackTrace);
            }
        }

        public static byte[] ObjectToBinary(object dataObj)
        {
            try
            {
                var stream = new MemoryStream();

                var formatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();

                formatter.Serialize(stream, dataObj);

                return stream.ToArray();
            }
            catch (Exception ex)
            {
                throw new System.Exception("There was an Exception while trying to convert stream to object. Exception:" + ex.Message + " | Stacktrace:" + ex.StackTrace);
            }
        }


        public static bool ObjectBinaryFile(object dataObj, string fileName)
        {
            var file = new FileInfo(fileName);

            if (!file.Directory.Exists)
            {
                file.Directory.Create();
            }
            else if (file.Exists)
            {
                file.Delete();
            }

            FileStream fs = null;

            try
            {
                fs = new FileStream(fileName, FileMode.OpenOrCreate);
                var stream = new MemoryStream();

                var bf = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
                bf.AssemblyFormat = System.Runtime.Serialization.Formatters.FormatterAssemblyStyle.Full;
                bf.TypeFormat = System.Runtime.Serialization.Formatters.FormatterTypeStyle.TypesWhenNeeded;
                bf.Serialize(fs, dataObj);

                return true;
            }
            catch (Exception ex)
            {
                throw new System.Exception("There was an Exception while trying to convert stream to object. Exception:" + ex.Message + " | Stacktrace:" + ex.StackTrace);
            }
            finally
            {
                if (fs != null)
                {
                    fs.Close();
                }
            }
            return false;
        }


        public static object BinaryFileToObject(string fileName)
        {
            try
            {
                if (File.Exists(fileName))
                {

                    FileStream fs = null;

                    var bf = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
                    bf.AssemblyFormat = System.Runtime.Serialization.Formatters.FormatterAssemblyStyle.Full;
                    bf.TypeFormat = System.Runtime.Serialization.Formatters.FormatterTypeStyle.TypesWhenNeeded;

                    var obj = bf.Deserialize(fs);

                    return obj;
                }
                else
                {
                    throw new FileNotFoundException("There is no file found with the name '" + fileName + "' to convert to object.");
                }
            }
            catch (Exception ex)
            {
                throw new System.Exception("There was an Exception while trying to convert stream to object. Exception:" + ex.Message + " | Stacktrace:" + ex.StackTrace);
            }

            return null;
        }

        public static T XMLFileToObject<T>(string xmlFilePath, params Type[] eXtraType) where T : class
        {
            T result = null;

            if (System.IO.File.Exists(xmlFilePath))
            {
                var doc = new System.Xml.XmlDocument();
                doc.Load(xmlFilePath);

                var reader = new System.IO.StringReader(doc.InnerXml);

                var xmlSerializer = new System.Xml.Serialization.XmlSerializer(typeof(T), eXtraType);

                result = xmlSerializer.Deserialize(reader) as T;

                reader.Close();
            }
            return result;
        }


        public static string ObjectToXML(object data, Type dataType)
        {
            var xmlDoc = new XmlDocument();

            var xmlSerializer = new System.Xml.Serialization.XmlSerializer(dataType);

            using (var xmlStream = new MemoryStream())
            {
                xmlSerializer.Serialize(xmlStream, data);
                xmlStream.Position = 0;
                xmlDoc.Load(xmlStream);
            }
            return xmlDoc.InnerXml;
        }


        public static bool ObjectToXMLFile(object data,Type dataType,string xmlFilepath, params Type[] eXtraType)
        {
            var xmlDoc = new XmlDocument();
            var xmlSerializer = new System.Xml.Serialization.XmlSerializer(dataType, eXtraType);
            using (var xmlStream = new MemoryStream())
            {
                xmlSerializer.Serialize(xmlStream, data);
                xmlStream.Position = 0;
                xmlDoc.Load(xmlStream);

                xmlDoc.Save(xmlFilepath);
            }
            return true;
        }

        public static object XMLToObject(string xml, Type dataType)
        {
            object result = null;

            var reader = new System.IO.StringReader(xml);

            var xmlSerializer = new System.Xml.Serialization.XmlSerializer(dataType);

            result = xmlSerializer.Deserialize(reader);

            return result;
        }

        public static void ProcessResponse(string strResponse)
        {
            try
            {
                strResponse = strResponse.Replace("<string xmlns=\"http://schemas.microsoft.com/2003/10/Serialization\">", "");
                strResponse = strResponse.Replace("<string xmlns=\"http://schemas.microsoft.com/2003/10/Serialization\"/>", "");
                
                strResponse = strResponse.Replace("</string>", "");
                strResponse = strResponse.Replace("&gt;", ">");
                strResponse = strResponse.Replace("&lt", "<");
            }
            catch (Exception ex)
            {
                throw new System.Exception("There was an Exception while trying to convert stream to object. Exception:" + ex.Message + " | Stacktrace:" + ex.StackTrace);
            }
        }

    }
}
