﻿using System;
using System.Runtime.InteropServices;
using System.Drawing;
using System.Drawing.Imaging;

namespace WinX.Core
{
    public partial class DisplayItem
    {
        public DisplayItem(IntPtr windowHandle)
        {
            this.windowHandle = windowHandle;
        }

        private readonly IntPtr windowHandle;

        public const int SRCCOPY = 0x00CC0020; // BitBlt dwRop parameter

        [DllImport("gdi32.dll")]
        public static extern bool BitBlt(IntPtr hObject, int nXDest, int nYDest,
            int nWidth, int nHeight, IntPtr hObjectSource,
            int nXSrc, int nYSrc, int dwRop);

        [DllImport("gdi32.dll")]
        public static extern IntPtr CreateCompatibleBitmap(IntPtr hDC, int nWidth,
            int nHeight);
        [DllImport("gdi32.dll")]
        public static extern IntPtr CreateCompatibleDC(IntPtr hDC);
        [DllImport("gdi32.dll")]
        public static extern bool DeleteDC(IntPtr hDC);

        [DllImport("gdi32.dll")]
        public static extern bool DeleteObject(IntPtr hObject);

        [DllImport("gdi32.dll")]
        public static extern IntPtr SelectObject(IntPtr hDC, IntPtr hObject);
        

        [DllImport("user32.dll")]
        public static extern IntPtr GetDesktopWindow();
        [DllImport("user32.dll")]
        public static extern IntPtr GetWindowDC(IntPtr hWnd);
        [DllImport("user32.dll")]
        public static extern IntPtr ReleaseDC(IntPtr hWnd, IntPtr hDC);
        [DllImport("user32.dll")]
        public static extern IntPtr GetWindowRect(IntPtr hWnd, ref Rectangle rect);


        public virtual Bitmap GetVisibleImage()
        {
            var compatibleDeviceContext = IntPtr.Zero;
            var deviceContext = IntPtr.Zero;
            var bitmap = IntPtr.Zero;

            Image img;

            try
            {
                deviceContext = GetWindowDC(windowHandle);
                var rect = new Rectangle();
                GetWindowRect(windowHandle,ref rect);
                var width = rect.Right - rect.Left;
                var height = rect.Bottom - rect.Top;
                compatibleDeviceContext = CreateCompatibleDC(deviceContext);

                bitmap = CreateCompatibleBitmap(deviceContext, width, height);

                var obj = SelectObject(compatibleDeviceContext, bitmap);

                BitBlt(compatibleDeviceContext, 0, 0, width, height, deviceContext, 0, 0, SRCCOPY);

                SelectObject(compatibleDeviceContext, obj);

            }
            catch(Exception ex)
            {

            }
            finally
            {
                DeleteDC(compatibleDeviceContext);
                ReleaseDC(windowHandle, deviceContext);
                img = Image.FromHbitmap(bitmap);
                DeleteObject(bitmap);
            }

            return new Bitmap(img);
        }

        public Bitmap GetImagepart(Bitmap srcBitmap, Rectangle section)
        {
            try
            {
                lock(srcBitmap)
                {
                    var bmp = new Bitmap(section.Width, section.Height);
                    var g = Graphics.FromImage(bmp);
                    g.DrawImage(srcBitmap, 0, 0, section, GraphicsUnit.Pixel);
                    g.Dispose();

                    return bmp;
                }
            }
            catch(Exception ex)
            {

            }
            return null;
        }

    }
}
