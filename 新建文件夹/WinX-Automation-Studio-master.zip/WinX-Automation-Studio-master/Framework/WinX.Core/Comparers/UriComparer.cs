﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace WinX.Core
{
    [Serializable]
    public partial class UriComparer: WinX.Core.Comparer<string>, INotifyPropertyChanged
    {
        public UriComparer()
        {
        }

        public UriComparer(string url)
        {
            this.URL = url;
        }


        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged(string propertyName)
        {
            if (this.PropertyChanged != null)
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        private string mURL = string.Empty;

        public string URL
        {
            get
            {
                return mURL;
            }
            set
            {
                this.mURL = value;
                NotifyPropertyChanged("URL");
            }
        }

        private bool mIgnoreQuery = false;

        public bool IgnoreQuery
        {
            get
            {
                return mIgnoreQuery;
            }
            set
            {
                this.mIgnoreQuery = value;
                NotifyPropertyChanged("IgnoreQuery");
            }

        }

        public override bool Compare(string value)
        {
            return string.IsNullOrEmpty(value) && Compare(CreateUri(value));
        }


        public virtual bool Compare(Uri url)
        {
            var tmpURL = new Uri(this.URL);

            if (!this.IgnoreQuery)
            {
                return tmpURL.Equals(url);
            }

            var trimmedUrl = TrimQueryString(url);

            var trimmedUrlToCompareWith = TrimQueryString(new Uri(this.URL));


            return string.Compare(trimmedUrl, trimmedUrlToCompareWith, true) == 0;
        }

        private Uri CreateUri(string url)
        {
            Uri uri;

            try
            {
                uri = new Uri(url);
            }
            catch (Exception ex)
            {
                uri = new Uri(@"https://" + url);
            }

            return uri;
        }

        public string TrimQueryString(Uri url)
        {
            return url.AbsoluteUri.Split('?')[0];
        }

        public override string ToString()
        {
            var tmpURL = new Uri(this.URL);
            return string.Format("equals uri '{0}{1}'", tmpURL.AbsolutePath, this.IgnoreQuery ? "ignoring query parameters": string.Empty);
        }
    }
}
