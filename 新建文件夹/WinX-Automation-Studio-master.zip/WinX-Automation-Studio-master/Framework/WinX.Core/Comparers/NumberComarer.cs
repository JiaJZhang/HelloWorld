﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace WinX.Core
{
    [DisplayName("Number Comparer")]
    [Serializable]
    public partial class NumberComarer : Comparer<Int32>, INotifyPropertyChanged
    {
        public NumberComarer()
        {

        }

        public NumberComarer(int expectedValue, NumberCompareType compareType = NumberCompareType.Equals)
        {
            this.ComparisonValue = expectedValue;
            this.Type = compareType;
        }


        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged(string propertyName)
        {
            if (this.PropertyChanged != null)
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }


        public enum NumberCompareType : int
        {
            Equals = 1,
            GreaterThan = 2,
            LessThan = 3
        }

        public int comparisonValue = 0;

        [DisplayName("Comparison Value")]
        public int ComparisonValue
        {
            get
            {
                return comparisonValue;
            }
            set
            {
                this.comparisonValue = value;
                NotifyPropertyChanged("ComparisonValue");
            }
        }

        NumberCompareType type = new NumberCompareType();

        public NumberCompareType Type
        {
            get
            {
                return type;
            }
            set
            {
                this.type = value;
                NotifyPropertyChanged("Type");
            }
        }

        public override bool Compare(int value)
        {
            if(value == 0)
            {
                return false;
            }

            switch (this.type)
            {
                case NumberCompareType.Equals:
                    return value == comparisonValue;
                case NumberCompareType.GreaterThan:
                    return comparisonValue > value;
                case NumberCompareType.LessThan:
                    return comparisonValue < value;
            }
            return false;
        }

        public override string ToString()
        {
            return string.Format(this.Type.ToString() + "'{0}'", comparisonValue);
        }
    }
}
