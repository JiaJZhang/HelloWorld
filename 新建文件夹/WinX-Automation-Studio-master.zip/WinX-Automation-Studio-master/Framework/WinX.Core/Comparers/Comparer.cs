﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace WinX.Core
{
    [TypeConverter(typeof(OptionsConverter))]
    [Serializable]
    [System.Xml.Serialization.XmlInclude(typeof(StringComparer))]
    [System.Xml.Serialization.XmlInclude(typeof(RegexComparer))]
    [System.Xml.Serialization.XmlInclude(typeof(UriComparer))]    
    public abstract partial class Comparer<T>
    {
        public virtual bool Compare(T value)
        {
            return false;
        }

    }
}
