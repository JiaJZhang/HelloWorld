﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace WinX.Core
{
    [TypeConverter(typeof(ExpandableObjectConverter))]
    [Serializable]
    public partial class RegexComparer : Comparer<string>
    {
        public Regex mRegex;

        public RegexComparer()
        {

        }

        public RegexComparer(Regex regex)
        {
            if(regex == null)
            {
                throw new ArgumentException("regex");
            }

            this.mRegex = regex;
        }

        public override bool Compare(string value)
        {
            if(string.IsNullOrEmpty(value))
            {
                return false;
            }

            return mRegex.IsMatch(value);
        }

        public override string ToString()
        {
            return string.Format("matches '{0}'", mRegex);
        }
    }
}
