﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace WinX.Core
{
    [DisplayName("String Comparer")]
    [Serializable]
    public partial class StringComparer : WinX.Core.Comparer<string>, INotifyPropertyChanged
    {
        public StringComparer()
        {

        }

        public StringComparer(string expectedValue, StringCompareType compareType = StringCompareType.Equals)
        {
            this.ComparisonValue = expectedValue;
            this.Type = compareType;

            if (ComparisonValue == null)
            {
                throw new ArgumentException("comparisonValue");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged(string propertyName)
        {
            if (this.PropertyChanged != null)
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        public enum StringCompareType : int
        {
            Equals = 1,
            Contains = 2,
            StartWith = 3,
            EndWith = 4,
            RegEx = 5,

        }

        private string comparisionValue = string.Empty;

        public string ComparisonValue
        {
            get
            {
                return comparisionValue;
            }
            set
            {
                this.comparisionValue = value;
                NotifyPropertyChanged("ComparisonValue");
                NotifyPropertyChanged("RuleString");
            }
        }

        public StringCompareType type = StringCompareType.Equals;

        [DisplayName("Comparison Type")]
        public StringCompareType Type
        {
            get
            {
                return this.type;
            }
            set
            {
                this.type = value;
                NotifyPropertyChanged("Type");
                NotifyPropertyChanged("RuleString");
            }
        }

        public override bool Compare(string value)
        {
            if (string.IsNullOrEmpty(value))
            {
                return false;
            }

            switch (this.type)
            {
                case StringCompareType.Equals:
                    return value.Equals(comparisionValue);
                case StringCompareType.Contains:
                    return value.Contains(comparisionValue);
                case StringCompareType.StartWith:
                    return value.StartsWith(comparisionValue);
                case StringCompareType.EndWith:
                    return value.EndsWith(comparisionValue);
                case StringCompareType.RegEx:
                    var regEx = new RegexComparer();
                    return regEx.Compare(value);
            }

            return false;
        }

        public override string ToString()
        {
            return this.Type + " : " + this.ComparisonValue;
        }
    }
}
