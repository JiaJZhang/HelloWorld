﻿using mshtml;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using WinX.Core;
using System.IO;

namespace WinX.Web
{
    [DisplayName("Attribute Match Rule")]
    [TypeConverter(typeof(OptionsConverter))]
    [Serializable()]
    public partial class AttributeMatchRule : MatchRule
    {
        [DisplayName("Attribute Name")]
        public string AttributeName
        {
            get; set;
        }

        [DisplayName("Comparer")]
        public WinX.Core.Comparer<string> Comparer
        {
            get; set;
        }

        public AttributeMatchRule()
        {
            Comparer = new WinX.Core.StringComparer("", WinX.Core.StringComparer.StringCompareType.Equals);
        }

        public AttributeMatchRule(string attributeName, WinX.Core.Comparer<string> comparer)
        {
            if (string.IsNullOrEmpty(attributeName))
            {
                throw new ArgumentNullException("attributeName");
            }

            if (comparer == null)
            {
                throw new ArgumentNullException("comparer");
            }

            this.AttributeName = attributeName;
            this.Comparer = comparer;
        }


        public AttributeMatchRule(string attributeName,string comparisonValue) 
            : this(attributeName, new WinX.Core.StringComparer(comparisonValue))
        {
            
            
        }
        public AttributeMatchRule(string attributeName, System.Text.RegularExpressions.Regex regex):
            this(attributeName,new RegexComparer(regex))
        {

        }

        protected override bool MatchEle(object ele)
        {
            Logger.Write("**** Begin Matching element by Attribute *****");
            dynamic eleObj = ele;
            var attributes = eleObj.attributes as IHTMLAttributeCollection2;

            if (attributes != null)
            {
                var attr = attributes.getNamedItem(this.AttributeName);
                if(attr != null)
                {
                    this.Status = this.Comparer.Compare(Convert.ToString(attr.nodeValue));
                }
            }
            Logger.Write("****  End Matching element by Attribute *****");
            return this.Status;
        }

        public override void WriteDescription(TextWriter writer)
        {
            writer.Write("Attribute '{0}' {1}", this.AttributeName, this.Comparer.ToString());
        }
    }
}
