﻿using mshtml;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using WinX.Core;
using System.IO;

namespace WinX.Web
{
    [DisplayName("Index Match Rule")]
    [TypeConverter(typeof(OptionsConverter))]
    [Serializable()]
    public partial class IndexMatchRule : MatchRule
    {
        [DisplayName("Comparer")]
        public WinX.Core.Comparer<int> Comparer
        {
            get; set;
        }

        public IndexMatchRule()
        {
            Comparer = new NumberComarer(0, NumberComarer.NumberCompareType.Equals);
        }

        public IndexMatchRule(WinX.Core.Comparer<int> comparer)
        {
            if (comparer == null)
            {
                throw new ArgumentNullException("comparer");
            }

            this.Comparer = comparer;
        }

        public IndexMatchRule(int index) : this(new NumberComarer(index))
        {
        }

        protected override bool MatchEle(object ele)
        {
            var iele = ele as mshtml.IHTMLElement;

            return this.Comparer.Compare(iele.sourceIndex);
        }
        
        public override void WriteDescription(TextWriter writer)
        {
            writer.Write("Index {0}", Comparer.ToString());
        }
    }
}
