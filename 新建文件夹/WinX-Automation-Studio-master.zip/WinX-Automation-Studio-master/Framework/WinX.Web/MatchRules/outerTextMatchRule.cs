﻿using mshtml;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using WinX.Core;
using System.IO;

namespace WinX.Web
{
    [DisplayName("OuterText Match Rule")]
    [TypeConverter(typeof(OptionsConverter))]
    [Serializable()]
    public partial class OuterTextMatchRule : MatchRule
    {
        [DisplayName("Comparer")]
        public WinX.Core.Comparer<string> Comparer
        {
            get; set;
        }

        public OuterTextMatchRule()
        {
            Comparer = new WinX.Core.StringComparer("", WinX.Core.StringComparer.StringCompareType.Equals);
        }

        public OuterTextMatchRule(WinX.Core.Comparer<string> comparer)
        {
            if (comparer == null)
            {
                throw new ArgumentNullException("comparer");
            }
            this.Comparer = comparer;
        }

        public OuterTextMatchRule(string outerText) : this(new WinX.Core.StringComparer(outerText))
        {

        }

        public OuterTextMatchRule(System.Text.RegularExpressions.Regex regex) : this(new RegexComparer(regex))
        {

        }

        protected override bool MatchEle(object ele)
        {
            var iele = ele as mshtml.IHTMLElement;
            return this.Comparer.Compare(iele.outerText);
        }

        public override void WriteDescription(TextWriter writer)
        {
            writer.Write("OuterText '{0}'", Comparer.ToString());
        }
    }
}
