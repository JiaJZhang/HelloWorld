﻿using mshtml;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using WinX.Core;
using System.IO;
using System.Collections.ObjectModel;

namespace WinX.Web
{
    [DisplayName("Document Match Rule")]
    [TypeConverter(typeof(OptionsConverter))]
    [Serializable()]
    public partial class IDMatchRule : MatchRule
    {
        public string ElementID
        {
            get; set;
        }

        public IDMatchRule()
        {
        }

        public IDMatchRule(string elementID)
        {
            this.ElementID = elementID;
        }

        protected override bool MatchEle(object htmlDoc)
        {
            var doc = htmlDoc as HTMLDocument;
            var Ele = doc.getElementById(ElementID) as IHTMLElement;
            if (Ele != null)
            {
                return true;
            }
            return false;
        }

        public override void WriteDescription(TextWriter writer)
        {
            writer.Write("ElementID = {0}", ElementID);
        }
    }
}
