﻿using mshtml;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using WinX.Core;
using System.IO;

namespace WinX.Web
{
    [DisplayName("InnerHtml Match Rule")]
    [TypeConverter(typeof(OptionsConverter))]
    [Serializable()]
    public partial class InnerHtmlMatchRule : MatchRule
    {
        [DisplayName("Comparer")]
        public WinX.Core.Comparer<string> Comparer
        {
            get; set;
        }

        public InnerHtmlMatchRule()
        {
            Comparer = new WinX.Core.StringComparer("", WinX.Core.StringComparer.StringCompareType.Equals);
        }

        public InnerHtmlMatchRule(WinX.Core.Comparer<string> comparer)
        {
            if(comparer == null)
            {
                throw new ArgumentNullException("comparer");
            }

            this.Comparer = comparer;
        }

        public InnerHtmlMatchRule(string innerHtml) : this(new WinX.Core.StringComparer(innerHtml))
        {

        }

        protected override bool MatchEle(object ele)
        {
            var iele = ele as mshtml.IHTMLElement;
            return this.Comparer.Compare(iele.innerHTML);
        }

        public override void WriteDescription(TextWriter writer)
        {
            writer.Write("InnerHtml '{0}'", this.Comparer.ToString());
        }

    }
}
