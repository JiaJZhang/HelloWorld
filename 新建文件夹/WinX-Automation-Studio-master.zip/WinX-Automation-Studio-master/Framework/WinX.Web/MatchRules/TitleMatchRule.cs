﻿using mshtml;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using WinX.Core;
using System.IO;

namespace WinX.Web
{
    [DisplayName("Title Match Rule")]
    [TypeConverter(typeof(OptionsConverter))]
    [Serializable()]
    public partial class TitleMatchRule : MatchRule
    {
        [DisplayName("Comparer")]
        public WinX.Core.Comparer<string> Comparer
        {
            get; set;
        }

        public TitleMatchRule()
        {
            Comparer = new WinX.Core.StringComparer("", WinX.Core.StringComparer.StringCompareType.Equals);
        }

        public TitleMatchRule(WinX.Core.Comparer<string> comparer)
        {
            if (comparer == null)
            {
                throw new ArgumentNullException("comparer");
            }
            this.Comparer = comparer;
        }

        public TitleMatchRule(string innerText) : this(new WinX.Core.StringComparer(innerText))
        {

        }

        public TitleMatchRule(System.Text.RegularExpressions.Regex regex):this(new RegexComparer(regex))
        {

        }

        protected override bool MatchEle(object ele)
        {
            if(ele is HTMLDocumentClass)
            {
                var docHtml = ele as HTMLDocumentClass;
                return this.Comparer.Compare(docHtml.title);
            }
            var htmlele = ele as IHTMLElement;
            return this.Comparer.Compare(htmlele.title);
        }

        public override void WriteDescription(TextWriter writer)
        {
            writer.Write("Title '{0}'", Comparer.ToString());
        }

    }
}
