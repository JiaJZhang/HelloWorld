﻿using mshtml;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using WinX.Core;
using System.IO;

namespace WinX.Web
{
    [DisplayName("Title Match Rule")]
    [TypeConverter(typeof(OptionsConverter))]
    [Serializable()]
    public partial class UrlMatchRule : MatchRule
    {
        [DisplayName("Comparer")]
        public WinX.Core.Comparer<string> Comparer
        {
            get; set;
        }
        
        public UrlMatchRule()
        {
            Comparer = new WinX.Core.StringComparer("", WinX.Core.StringComparer.StringCompareType.Equals);
        }

        public UrlMatchRule(WinX.Core.Comparer<string> comparer)
        {
            if (comparer == null)
            {
                throw new ArgumentNullException("comparer");
            }
            this.Comparer = comparer;
        }

        public UrlMatchRule(string innerText) : this(new WinX.Core.StringComparer(innerText))
        {

        }

        public UrlMatchRule(System.Text.RegularExpressions.Regex regex):this(new RegexComparer(regex))
        {

        }

        protected override bool MatchEle(object doc)
        {
            if (doc is HTMLDocumentClass)
            {
                var docHtml = doc as HTMLDocumentClass;
                return this.Comparer.Compare(docHtml.url);
            }
            else
            {
                var docFrame = doc as HTMLFrameElement;

                return this.Comparer.Compare(docFrame.src);
            }
        }

        public override void WriteDescription(TextWriter writer)
        {
            writer.Write("Url '{0}'", Comparer.ToString());
        }
    }
}
