﻿using mshtml;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using WinX.Core;
using System.IO;

namespace WinX.Web
{
    [DisplayName("InnerText Match Rule")]
    [TypeConverter(typeof(OptionsConverter))]
    [Serializable()]
    public partial class InnerTextMatchRule : MatchRule
    {
        [DisplayName("Comparer")]
        public WinX.Core.Comparer<string> Comparer
        {
            get;set;
        }

        public InnerTextMatchRule()
        {
            Comparer = new WinX.Core.StringComparer("", WinX.Core.StringComparer.StringCompareType.Equals);
        }

        public InnerTextMatchRule(WinX.Core.Comparer<string> comparer)
        {
            if (comparer == null)
            {
                throw new ArgumentNullException("comparer");
            }
            this.Comparer = comparer;
        }

        public InnerTextMatchRule(string innerText) : this(new WinX.Core.StringComparer(innerText))
        {

        }

        public InnerTextMatchRule(System.Text.RegularExpressions.Regex regex):this(new RegexComparer(regex))
        {
            
        }

        protected override bool MatchEle(object ele)
        {
            var iele = ele as mshtml.IHTMLElement;
            return this.Comparer.Compare(iele.innerText);
        }

        public override void WriteDescription(TextWriter writer)
        {
            writer.Write("InnerText '{0}'", Comparer.ToString());
        }
    }
}
