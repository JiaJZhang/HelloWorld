﻿using mshtml;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using WinX.Core;
using System.IO;

namespace WinX.Web
{
    [DisplayName("OuterHtml Match Rule")]
    [TypeConverter(typeof(OptionsConverter))]
    [Serializable()]
    public partial class OuterHtmlMatchRule : MatchRule
    {
        [DisplayName("Comparer")]
        public WinX.Core.Comparer<string> Comparer
        {
            get; set;
        }

        public OuterHtmlMatchRule()
        {
            Comparer = new WinX.Core.StringComparer("", WinX.Core.StringComparer.StringCompareType.Equals);
        }

        public OuterHtmlMatchRule(WinX.Core.Comparer<string> comparer)
        {
            if (comparer == null)
            {
                throw new ArgumentNullException("comparer");
            }

            this.Comparer = comparer;
        }

        public OuterHtmlMatchRule(string outerHtml) : this(new WinX.Core.StringComparer(outerHtml))
        {

        }

        protected override bool MatchEle(object ele)
        {
            var iele = ele as mshtml.IHTMLElement;
            return this.Comparer.Compare(iele.outerHTML);
        }

        public override void WriteDescription(TextWriter writer)
        {
            writer.Write("OuterHtml '{0}'", this.Comparer.ToString());
        }

    }
}
