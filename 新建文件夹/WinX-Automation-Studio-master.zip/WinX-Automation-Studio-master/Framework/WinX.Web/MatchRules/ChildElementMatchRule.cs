﻿using mshtml;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using WinX.Core;
using System.IO;

namespace WinX.Web
{
    [DisplayName("Child Element Match Rule")]
    [TypeConverter(typeof(OptionsConverter))]
    [Serializable()]
    public partial class ChildElementMatchRule : MatchRule
    {
        [DisplayName("Child Element")]
        public WebElement ChildElement
        {
            get; set;
        }


        protected override bool MatchEle(object ele)
        {
            if(this.ChildElement != null)
            {
                var lstElement = MatchEngine.GetElementsByRules(ele as HTMLDocument, this.ChildElement.MatchRules);
                this.Status = lstElement != null && lstElement.Count() > 0;
            }
            return this.Status;
        }


        public override void WriteDescription(TextWriter writer)
        {
            writer.Write("Contains Child -> '{0}'", ChildElement != null ? this.ChildElement.Name : "");
        }
    }
}
