﻿using mshtml;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using WinX.Core;
using System.IO;

namespace WinX.Web
{
    [DisplayName("Tag Match Rule")]
    [TypeConverter(typeof(OptionsConverter))]
    [Serializable()]
    public partial class TagMatchRule : MatchRule
    {
        [DisplayName("TagName")]
        public string TagName
        {
            get; set;
        }
        public TagMatchRule()
        {

        }

        public TagMatchRule(string tagName)
        {
            if(string.IsNullOrEmpty(tagName))
            {
                throw new ArgumentNullException("TagName");
            }
            else
            {
                this.TagName = tagName;
            }
        }

        protected override bool MatchEle(object htmlObject)
        {
            Logger.Write("**** Matching element by Tag *****");
            var ele = htmlObject as mshtml.IHTMLElement;

            if(this.TagName.Equals(ele.tagName))
            {
                return true;
            }
            return false;
        }

        public override void WriteDescription(TextWriter writer)
        {
            writer.Write("Tag = '{0}'", TagName);
        }
    }
}
