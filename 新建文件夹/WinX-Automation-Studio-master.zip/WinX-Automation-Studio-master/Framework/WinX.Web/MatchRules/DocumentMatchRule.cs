﻿using mshtml;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using WinX.Core;
using System.IO;
using System.Collections.ObjectModel;

namespace WinX.Web
{
    [DisplayName("Document Match Rule")]
    [TypeConverter(typeof(OptionsConverter))]
    [Serializable()]
    public partial class DocumentMatchRule : MatchRule
    {
        [DisplayName("Match Rules")]
        public ObservableCollection<MatchRule> MatchRules
        {
            get; set;
        }


        [DisplayName("Document Document")]
        public DocumentMatchRule Child
        {
            get; set;
        }

        public DocumentMatchRule()
        {
            this.MatchRules = new ObservableCollection<MatchRule>();
        }
        
        public DocumentMatchRule(ObservableCollection<MatchRule> rules)
        {
            this.MatchRules = rules;
        }

        public DocumentMatchRule(params MatchRule[] rules)
        {
            this.MatchRules = new ObservableCollection<MatchRule>();

            foreach(var rule in rules)
            {
                this.MatchRules.Add(rule);
            }
        }

        protected override bool MatchEle(object ele)
        {
            return false;
        }

        public override void WriteDescription(TextWriter writer)
        {
            writer.Write("Web Document Match Rule");
        }
    }
}
