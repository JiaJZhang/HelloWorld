﻿using mshtml;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using WinX.Core;
using System.IO;

namespace WinX.Web
{
    [DisplayName("InnerText Match Rule")]
    [TypeConverter(typeof(OptionsConverter))]
    [Serializable()]
    public partial class NameMatchRule : MatchRule
    {
        public string ElementName
        {
            get; set;
        }


        public NameMatchRule()
        {

        }

        public NameMatchRule(string elementName)
        {
            this.ElementName = elementName;
        }

        protected override bool MatchEle(object htmlDoc)
        {
            var ele = htmlDoc as mshtml.IHTMLElement;

            if(this.ElementName.Equals(ele.getAttribute("name")))
            {
                return true;
            }
            return false;
        }

        public override void WriteDescription(TextWriter writer)
        {
            writer.Write("Name = '{0}'", ElementName);
        }

    }
}
