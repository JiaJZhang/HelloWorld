﻿using mshtml;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using WinX.Core;

namespace WinX.Web
{
    public partial class EventManager
    {
        public delegate void ScreenCreatedHander(WebScreen screen, RawDocument target);
        public delegate void ScreenDestroyedHander(WebScreen screen);

        public static event ScreenCreatedHander ScreenCreated;
        public static event ScreenDestroyedHander ScreenDestroyed;


        public static event ScreenCreatedHander ScreenCreatedSynch;
        public static event ScreenDestroyedHander ScreenDestroyedSynch;

        public static List<WebScreen> Screens = new List<WebScreen>();

        public static int TimeoutInSec = 60;


        public static void OnScreenCreated(WebScreen screen, RawDocument target)
        {
            if (ScreenCreated != null)
            {
                ScreenCreated(screen, target);
            }
        }
        public static void OnScreenDestroyed(WebScreen screen)
        {
            if (ScreenDestroyed != null)
            {
                ScreenDestroyed(screen);
            }
        }

        public static void OnScreenCreatedSynch(WebScreen screen, RawDocument target)
        {
            if (ScreenCreatedSynch != null)
            {
                ScreenCreatedSynch(screen, target);
            }
        }
        public static void OnScreenDestroyedSynch(WebScreen screen)
        {
            if (ScreenDestroyedSynch != null)
            {
                ScreenDestroyedSynch(screen);
            }
        }

        public EventManager()
        {
            ShellWindows.PageCreated += OnPageCreated;
        }

        private static void OnPageDestroyed(RawWebDocument browser)
        {

        }

        private static void OnPageCreated(RawWebDocument browser)
        {
            try
            {
                Logger.Write("Document creation event was fired.Matching is in progress for the'" + browser.Url + "'.");

                if (browser.Document != null)
                {
                    var doneEvent = new ManualResetEvent(false);
                    int taskCount = 0;

                    for (int i = 0; i < Screens.Count; i++)
                    {
                        int index = i;

                        Interlocked.Increment(ref taskCount);
                        ThreadPool.QueueUserWorkItem(obj =>
                        {
                            var evt = obj as ManualResetEvent;
                            try
                            {
                                if (MatchEngine.GetDocumentByRule(Screens[index], browser.Document as HTMLDocumentClass, false, true) != null)
                                {
                                    OnScreenCreated(Screens[index], browser);
                                }
                            }
                            catch (Exception ex)
                            {
                                Logger.Write(ex, "There was an exception while trying to match screen '" + Screens[index].Name + "'.");
                            }
                            finally
                            {
                                if (Interlocked.Decrement(ref taskCount) == 0)
                                {
                                    evt.Set();
                                }
                            }

                        }, doneEvent);
                    }
                    doneEvent.WaitOne(TimeoutInSec * 1000);
                }
                Logger.Write("Document createion event was fired. Matching has been complete for the '" + browser.Url + "'.");
            }
            catch (Exception ex)
            {
                Logger.Write(ex, "There awas an error while trying to match screen from the url '" + browser.Url + "'.");
            }
        }


    }
}
