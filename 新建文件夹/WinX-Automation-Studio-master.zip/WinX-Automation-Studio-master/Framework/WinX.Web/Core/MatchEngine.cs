﻿using mshtml;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading;
using WinX.Core;

namespace WinX.Web
{
    public partial class MatchEngine
    {

        [MTAThread()]
        public static void PeformScreenMatch(WinX.Core.Screen Screen, object SourceDoc, bool MatchAllRules)
        {
            if (Screen == null)
            {
                return;
            }

            if (SourceDoc != null)
            {
                if (Screen is WinX.Web.WebScreen && SourceDoc is mshtml.HTMLDocumentClass)
                {
                    var doc = GetDocumentByRule(Screen as WebScreen, SourceDoc as HTMLDocumentClass, MatchAllRules, true);

                    if (doc != null)
                    {
                        ((WebScreen)Screen).HTMLDocument = doc;
                        MactchElements(doc, Screen.Fields);
                    }
                }
                else if (Screen is WebPdfScreen && !(SourceDoc is HTMLDocumentClass))
                {
                    var doc = GetAxAcroPDFDocumentByRule(Screen as WebPdfScreen, SourceDoc, MatchAllRules);
                    if (doc != null)
                    {
                        ((WebPdfScreen)Screen).docObject = doc;
                    }
                }
            }
        }

        [MTAThread]
        public static HTMLDocumentClass GetDocumentByRule(WebScreen Screen, HTMLDocumentClass sourceDoc = null, bool MatchAllRules = false, bool matchLastChildWhenParentNotMatch = false)
        {
            HTMLDocumentClass webDoc = null;

            try
            {
                if (Screen != null)
                {
                    ResetScreenStatus(Screen);
                    Logger.Write("Screen '" + Screen.Name + "' status has been reset.");
                }

                var nonDocMatchRules = Screen.MatchRules.Where(m => !(m is DocumentMatchRule));
                if (nonDocMatchRules != null && nonDocMatchRules.Count() > 0)
                {
                    Logger.Write("Screen '" + Screen.Name + "',Found '" + nonDocMatchRules.Count() + "' non document match rules found.");

                }

                var docMatchRule = Screen.MatchRules.Where(m => m is DocumentMatchRule).FirstOrDefault() as DocumentMatchRule;
                if (docMatchRule != null)
                {
                    Logger.Write("Screen '" + Screen.Name + "', Found a document match rule found.");
                    docMatchRule.Status = false;

                    if (sourceDoc == null)
                    {
                        Logger.Write("Source docment is nothing,attempting to match from the shell documents....");

                        webDoc = GetMatchedWebDocument(docMatchRule, MatchAllRules);
                    }
                    else
                    {
                        if (MatchDocumentRules(sourceDoc, docMatchRule.MatchRules, MatchAllRules))
                        {
                            webDoc = sourceDoc;
                        }
                        else
                        {
                            webDoc = null;
                        }
                    }

                    if (webDoc == null)
                    {
                        if (!matchLastChildWhenParentNotMatch)
                        {
                            docMatchRule.Status = false;
                            Screen.Status = false;
                            return null;
                        }
                        else
                        {
                            ObservableCollection<MatchRule> matchRules = null;
                            while (docMatchRule.Child != null)
                            {
                                matchRules = docMatchRule.Child.MatchRules;
                                docMatchRule = docMatchRule.Child;
                            }

                            if (nonDocMatchRules != null)
                            {
                                foreach (var r in nonDocMatchRules)
                                {
                                    matchRules.Add(r);
                                }
                            }

                            if (MatchDocumentRules(sourceDoc, matchRules, MatchAllRules))
                            {
                                webDoc = sourceDoc;
                                docMatchRule.Status = true;
                                Screen.Status = true;
                                return webDoc;
                            }
                            else
                            {
                                webDoc = null;
                                return null;
                            }
                        }
                    }
                    else
                    {
                        docMatchRule.Status = true;
                    }

                    while (docMatchRule.Child != null)
                    {
                        var tmpDoc = GetDocumentFromFrames(webDoc, "FRAME", docMatchRule.Child.MatchRules, MatchAllRules);

                        if (tmpDoc == null)
                        {
                            tmpDoc = GetDocumentFromFrames(webDoc, "IFRAME", docMatchRule.Child.MatchRules, MatchAllRules);
                        }

                        webDoc = tmpDoc as HTMLDocumentClass;

                        if (webDoc != null)
                        {
                            docMatchRule.Child.Status = true;
                        }
                        else
                        {
                            break;
                        }
                        docMatchRule = docMatchRule.Child;
                    }
                }

                if (webDoc != null)
                {
                    if (nonDocMatchRules != null && nonDocMatchRules.Count() > 0)
                    {
                        if (MatchDocumentRules(webDoc, nonDocMatchRules, MatchAllRules))
                        {
                            Screen.Status = true;
                        }
                        else
                        {
                            webDoc = null;
                        }
                    }
                    else
                    {
                        Screen.Status = true;
                    }
                }
            }
            catch(Exception ex)
            {
                Logger.Write(ex, "There was an error while trying to locate document.");
            }
            return webDoc;
        }


        [MTAThread]
        public static HTMLDocument GetDocumentFromFrames(HTMLDocument webDoc, string FrameType, ObservableCollection<MatchRule> MatchRules, bool MatchAllRules = false)
        {
            var frames = webDoc.getElementsByTagName(FrameType);
            if (frames != null && frames.length > 0)
            {
                foreach (var frame in frames)
                {
                    try
                    {
                        if (frame is SHDocVw.IWebBrowser2)
                        {
                            var bw = frame as SHDocVw.IWebBrowser2;
                            var frameDoc = bw.Document;
                            if (frameDoc != null)
                            {
                                if (MatchDocumentRules(frameDoc, MatchRules, MatchAllRules))
                                {
                                    return frameDoc as HTMLDocument;
                                }
                            }
                        }
                        else
                        {
                            Logger.Write("The frame is not 'SHDOCVw.IWebBrowser2' object. can not be matched.");
                        }
                    }
                    catch (Exception ex)
                    {
                        Logger.Write(ex, "There was an error while trying to match document from  frame.");
                    }
                }
            }
            return null;
        }
        
        [MTAThread]
        public static bool MatchDocumentRules(object doc, IEnumerable<MatchRule> Rules, bool MatchAllRules)
        {
            if(Rules != null  && Rules.Count() > 0 )
            {
                foreach(var rule in Rules)
                {
                    rule.Status = false;
                }

                foreach(var rule in Rules)
                {
                    rule.Status = rule.Match(doc);
                    if(!MatchAllRules && !rule.Status)
                    {
                        return false;
                    }
                }
                return Rules.Where(m => m.Status == false).Count() == 0;
            }

            return false;
        }


        [MTAThread]
        public static ObservableCollection<IHTMLElement> GetElementsByRules(HTMLDocument doc, ObservableCollection<MatchRule> Rules)
        {
            IHTMLElementCollection eleColl = null;
            var eleList = new List<IHTMLElement>();
            var filteredEleList = new List<IHTMLElement>();
            var matchedElements = new ObservableCollection<IHTMLElement>();

            var IDRule = Rules.Where(m => m is IDMatchRule).FirstOrDefault() as IDMatchRule;
            var NameRule = Rules.Where(m => m is NameMatchRule).FirstOrDefault() as NameMatchRule;
            var TagMR = Rules.Where(m => m is TagMatchRule).FirstOrDefault() as TagMatchRule;

            if (IDRule != null)
            {
                var ele = doc.getElementById(IDRule.ElementID);
                if (ele != null)
                {
                    IDRule.Status = true;
                    eleList.Add(ele);
                }
            }

            if (NameRule != null)
            {
                if (eleList.Count() > 0)
                {
                    var tmpList = new List<IHTMLElement>();
                    foreach (var eleN in eleList)
                    {
                        if (eleN.getAttribute("name") != null && eleN.getAttribute("name").ToString().Equals(NameRule.ElementName, StringComparison.InvariantCultureIgnoreCase))
                        {
                            tmpList.Add(eleN);
                        }
                    }
                    eleList = tmpList;
                }
                else
                {
                    eleColl = doc.getElementsByName(NameRule.ElementName);
                    if (eleColl != null && eleColl.length > 0)
                    {
                        NameRule.Status = true;
                        foreach (IHTMLElement e1 in eleColl)
                        {
                            eleList.Add(e1);
                        }
                    }
                }
            }

            if (TagMR != null)
            {
                if (eleList.Count > 0)
                {
                    var tmpList = new List<IHTMLElement>();
                    foreach (var eleN in eleList)
                    {
                        if (eleN.tagName != null && eleN.tagName.Equals(TagMR.TagName, StringComparison.InvariantCultureIgnoreCase))
                        {
                            tmpList.Add(eleN);
                        }
                    }
                    eleList = tmpList;
                }
                else
                {
                    eleColl = doc.getElementsByName(TagMR.TagName);
                    if (eleColl != null && eleColl.length > 0)
                    {
                        NameRule.Status = true;
                        foreach (IHTMLElement e1 in eleColl)
                        {
                            eleList.Add(e1);
                        }
                    }
                }
            }

            foreach (IHTMLElement e in eleList)
            {
                var index = e.sourceIndex;
                if (filteredEleList.Where(m => m.sourceIndex == index).Count() == 0)
                {
                    filteredEleList.Add(e);
                }
            }

            var tmpRules = Rules.Where(m => !(m is IDMatchRule) && !(m is NameMatchRule) && !(m is TagMatchRule));

            if (tmpRules != null && tmpRules.Count() > 0)
            {
                if(TagMR!= null)
                {
                    foreach (IHTMLElement ele in doc.getElementsByTagName(TagMR.TagName))
                    {
                        filteredEleList.Add(ele);
                    }
                }

                if (filteredEleList.Count == 0)
                {
                    foreach (IHTMLElement ele in doc.all)
                    {
                        filteredEleList.Add(ele);
                    }
                }


                //var tmpElements = new List<IHTMLElement>();
                //var matchTmpRules = new IEnumerable<MatchRule>[filteredEleList.Count];


                var tmpElements = filteredEleList.Where(m =>
                                                        {
                                                            foreach (var rule in tmpRules)
                                                            {
                                                                rule.Status = false;
                                                                if (!rule.Match(m))
                                                                {
                                                                    break;
                                                                }
                                                            }
                                                            return tmpRules.Where(r => r.Status == false).Count() == 0;
                                                        }).AsParallel().ToList();

                //var doneEvent = new ManualResetEvent(false);
                //int taskCount = 0;

                //for (int i = 0; i < filteredEleList.Count; i++)
                //{
                //    int index = i;
                //    Interlocked.Increment(ref taskCount);
                //    matchTmpRules[index] = tmpRules;

                //    ThreadPool.QueueUserWorkItem((object evt) =>
                //    {
                //        try
                //        {
                //            var field = filteredEleList[index];
                            
                //            foreach (var rule in matchTmpRules[index])
                //            {
                //                rule.Status = false;
                //                if (!rule.Match(field))
                //                {
                //                    break;
                //                }
                //            }

                //            if(tmpRules.Where(r => r.Status == false).Count() == 0)
                //            {
                //                tmpElements.Add(field);
                //            }

                //        }
                //        catch (Exception ex)
                //        {
                //            //Logger.Write(ex, "There was an error while trying to match field '" + fields[index].Name + "'.");
                //        }
                //        finally
                //        {
                //            if (Interlocked.Decrement(ref taskCount) == 0)
                //            {
                //                doneEvent.Set();
                //            }
                //        }
                //    }, null);

                //}
                //doneEvent.WaitOne();




                //System.Threading.Tasks.Parallel.For(0, filteredEleList.Count, i =>
                //{
                //    matchTmpRules[i] = tmpRules;

                //    System.Threading.Tasks.Parallel.ForEach(matchTmpRules[i], rule =>
                //    {
                //        rule.Status = false;
                //        rule.Match(filteredEleList[i]);
                //    });

                //    if (matchTmpRules[i].Where(r => r.Status == false).Count() == 0)
                //    {
                //        tmpElements.Add(filteredEleList[i]);
                //    }

                //});



                //System.Threading.Tasks.Parallel.ForEach(filteredEleList, f =>
                //{
                //    var mTmpRules = tmpRules;

                //    foreach (var rule in mTmpRules)
                //    {
                //        rule.Status = false;                   
                //        rule.Match(f);                      
                //    }

                //    if (mTmpRules.Where(r => r.Status == false).Count() == 0)
                //    {
                //        tmpElements.Add(f);
                //    }
                //});


                if (tmpElements != null && tmpElements.Count() > 0)
                {
                    foreach (var ele in tmpElements)
                    {
                        matchedElements.Add(ele);
                    }
                }
            }
            else
            {
                foreach (var ele in filteredEleList)
                {
                    matchedElements.Add(ele);
                }
            }


            if (matchedElements.Count > 0)
            {
                foreach (var rule in Rules)
                {
                    rule.Status = true;
                }
            }

            return matchedElements;
        }


        [MTAThread]
        public static bool MactchElements(HTMLDocument doc, IEnumerable<Field> fields, int timeOutInSec = 30)
        {
            if (doc != null && fields != null && fields.Count() > 0)
            {
                var autoEvent = new AutoResetEvent(false);
                var taskCount = 0;
                var fieldsList = fields.ToList();


                for (int i = 0; i < fieldsList.Count; i++)
                {
                    var index = i;
                    Interlocked.Increment(ref taskCount);

                    ThreadPool.UnsafeQueueUserWorkItem((obj) =>
                    {
                        var evt = obj as AutoResetEvent;
                        try
                        {
                            var field = fieldsList[index] as WebElement;
                            var lstElements = GetElementsByRules(doc, field.MatchRules);
                            if (lstElements != null && lstElements.Count() > 0)
                            {
                                field.Status = true;
                                field.TargetsCount = lstElements.Count;
                                field.Targets = lstElements;
                            }
                            else
                            {
                                field.Status = false;
                                field.TargetsCount = 0;
                                field.Targets = null;
                            }
                        }
                        catch (Exception ex)
                        {
                            Logger.Write(ex, "There was an error while trying to match filed '" + fieldsList[index].Name + "'.");
                        }
                        finally
                        {
                            if (Interlocked.Decrement(ref taskCount) == 0)
                            {
                                evt.Set();
                            }
                        }

                    }, autoEvent);
                }

                autoEvent.WaitOne(TimeSpan.FromSeconds(timeOutInSec));

                return fields.Where(m => m.Status == false).Count() == 0;
            }
            return false;
        }



        [MTAThread]
        public static object GetAxAcroPDFDocumentByRule(WebPdfScreen webPdfScreen, object SourceDoc = null, bool MatchAllRules = false)
        {
            object objDocument = null;

            //try
            //{
            //    if(webPdfScreen != null)
            //    {
            //        ResetScreenStatus(webPdfScreen);
            //    }

            //    if(SourceDoc != null)
            //    {
            //        if(MatchDocumentRules(SourceDoc,webPdfScreen.MatchRules,MatchAllRules))
            //        {
            //            objDocument = SourceDoc;
            //            webPdfScreen.Status = true;
            //        }
            //        else
            //        {
            //            objDocument = null;
            //        }
            //    }
            //    else
            //    {
            //        SHDocVw.ShellWindowsClass oShellWindowsClass = null;

            //        try
            //        {
            //            var lst = new List<RawDocument>();
            //            Logger.Write("[GetAxAcroPDFDocumentByRule] : Attempting to create ShellWindowsClass object.");

            //            oShellWindowsClass = new SHDocVw.ShellWindowsClass();

            //            if(oShellWindowsClass != null)
            //            {
            //                Logger.Write("[GetAxAcroPDFDocumentByRule] : ShellWindowsClass object has been created.");

            //                Logger.Write("[GetAxAcroPDFDocumentByRule] : Found'" + oShellWindowsClass.Count + "' Shell windows.");
                            
            //                foreach(var browser in oShellWindowsClass)
            //                {
            //                    try
            //                    {

            //                    }
            //                }

            //            }
            //        }
            //    }

            //}



            return false;
        }


        [MTAThread]
        public static HTMLDocumentClass GetMatchedWebDocument(DocumentMatchRule docMatchRule, bool MatchAllRules = false)
        {
            HTMLDocumentClass WebDoc = null;

            try
            {
                var browserWindows = ShellWindows.GetRunningBrowserWindows();
                if(browserWindows.Count() > 0)
                {
                    foreach(var browser in browserWindows)
                    {
                        try
                        {
                            if(browser.Document != null)
                            {
                                if(MatchDocumentRules(browser.Document,docMatchRule.MatchRules,MatchAllRules))
                                {
                                    Logger.Write("Web document matched -[Title='" + browser.Title + "' | URL='" + browser.Url + "'].");
                                    WebDoc = browser.Document as HTMLDocumentClass;
                                    break;
                                }
                                else
                                {
                                    Logger.Write("Web document did not match - [Title='" + browser.Title + "' | URL='" + browser.Url + "'].");
                                }
                            }
                        }
                        catch(Exception ex)
                        {
                            Logger.Write(ex,"There was an exception while trying to match with title='" + browser.Title + "' | URL='" + browser.Url + "'.");
                        }
                    }
                }
            }
            catch(Exception ex)
            {
                Logger.Write(ex, "[GetMatchedWebDocument] : There was an exception while trying to match documents,.");
            }
            return WebDoc;
        }



        [MTAThread]
        public static void ResetScreenStatus(Screen Screen)
        {
            if (Screen != null)
            {
                Screen.Status = false;
                var docMatchRules = Screen.MatchRules.Where(m => m is DocumentMatchRule);

                if (docMatchRules != null)
                {
                    foreach (DocumentMatchRule docMatchRule in docMatchRules)
                    {
                        var tmpDocMatchRule = docMatchRule;

                        while (tmpDocMatchRule != null)
                        {
                            tmpDocMatchRule.Status = false;

                            foreach (var rule in tmpDocMatchRule.MatchRules)
                            {
                                rule.Status = false;
                            }
                            tmpDocMatchRule = tmpDocMatchRule.Child;
                        }
                    }
                }

                var childEleMatchRules = Screen.MatchRules.Where(d => d is ChildElementMatchRule);
                if(childEleMatchRules!= null && childEleMatchRules.Count() > 0)
                {
                    foreach(ChildElementMatchRule childEleMatchRule in childEleMatchRules)
                    {
                        childEleMatchRule.Status = false;
                        if(childEleMatchRule.ChildElement!= null)
                        {
                            childEleMatchRule.Status = false;
                            if(childEleMatchRule.ChildElement.MatchRules!= null)
                            {
                                foreach(var rule in childEleMatchRule.ChildElement.MatchRules)
                                {
                                    rule.Status = false;
                                }
                            }
                        }
                    }
                }

                if(Screen.Fields != null && Screen.Fields.Count() > 0)
                {
                    foreach(WebElement field in Screen.Fields)
                    {
                        field.Status = false;
                        field.TargetsCount = 0;
                        field.Targets = null;
                        foreach(var rule in field.MatchRules)
                        {
                            rule.Status = false;
                        }
                    }
                }

            }
        }

        [MTAThread]
        public static IEnumerable<RawDocument> GetAllDocuments()
        {
            return ShellWindows.GetRunningBrowserWindows();
        }

        [MTAThread]
        public static bool WaitForAll(HTMLDocument doc, int TimeOutInSec, params Field[] fields)
        {
            if (doc != null && fields != null && fields.Count() > 0)
            {
                var autoEvent = new AutoResetEvent(false);
                var taskCount = 0;
                var fieldsList = fields.ToList();
                
                var startTime = DateTime.Now;
                int timeLeft = TimeOutInSec - Convert.ToInt32(DateTime.Now.Subtract(startTime).TotalSeconds);

                for (int i = 0; i < fields.Count(); i++)
                {
                    var index = i;
                    Interlocked.Increment(ref taskCount);

                    ThreadPool.QueueUserWorkItem(obj =>
                    {
                        AutoResetEvent evt = obj as AutoResetEvent;

                        try
                        {
                            var field = fields[index] as WebElement;
                            field.Status = false;
                            field.TargetsCount = 0;
                            field.Targets = null;

                            var lstElements = GetElementsByRules(doc, field.MatchRules);

                            do
                            {
                                VisualLog.RaiseOnWaitEvent(field, timeLeft, evt);
                                Logger.Write("Retrying for the web field...'" + field.Name + "' | [Time left : " + timeLeft + " ].");
                                System.Threading.Thread.Sleep(250);
                                lstElements = GetElementsByRules(doc, field.MatchRules);
                                timeLeft = TimeOutInSec - Convert.ToInt32(DateTime.Now.Subtract(startTime).TotalSeconds);

                            } while ((lstElements != null && lstElements.Count() > 0) || (timeLeft <= 0));

                            if (lstElements != null && lstElements.Count() > 0)
                            {
                                field.Status = true;
                                field.TargetsCount = lstElements.Count();
                                field.Targets = lstElements;
                            }
                        }
                        catch (Exception ex)
                        {
                            Logger.Write(ex, "There was an error while trying to match field '" + fields[index].Name + "'.");
                        }
                        finally
                        {
                            if (Interlocked.Decrement(ref taskCount) == 0)
                            {
                                evt.Set();
                            }
                        }

                    }, autoEvent);
                }
                autoEvent.WaitOne(TimeSpan.FromSeconds(TimeOutInSec));
                return fields.Where(m => m.Status == false).Count() == 0;
            }
            return false;
        }
        
        [MTAThread]
        public static WebElement WaitForAny(HTMLDocument doc, int TimeOutInSec, params Field[] fields)
        {
            if (doc != null && fields != null && fields.Count() > 0)
            {
                var waitHandles = new AutoResetEvent[fields.Count() - 1];
                List<IHTMLElement> lstElement = null;
                var startTime = DateTime.Now;
                int timeLeft = TimeOutInSec - Convert.ToInt32(DateTime.Now.Subtract(startTime).TotalSeconds);

                for (int i = 0; i < fields.Count(); i++)
                {
                    var index = i;
                    waitHandles[index] = new AutoResetEvent(false);

                    ThreadPool.QueueUserWorkItem(obj =>
                    {
                        AutoResetEvent evt = obj as AutoResetEvent;

                        try
                        {
                            var field = fields[index] as WebElement;
                            field.Status = false;
                            field.TargetsCount = 0;
                            field.Targets = null;

                            var lstElements = GetElementsByRules(doc, field.MatchRules);

                            do
                            {
                                VisualLog.RaiseOnWaitEvent(field, timeLeft, evt);
                                Logger.Write("Retrying for the web field...'" + field.Name + "' | [Time left : " + timeLeft + " ].");
                                System.Threading.Thread.Sleep(250);
                                lstElements = GetElementsByRules(doc, field.MatchRules);
                                timeLeft = TimeOutInSec - Convert.ToInt32(DateTime.Now.Subtract(startTime).TotalSeconds);

                            } while ((lstElements != null && lstElements.Count() > 0) || (timeLeft <= 0));

                            if (lstElements != null && lstElements.Count() > 0)
                            {
                                field.Status = true;
                                field.TargetsCount = lstElements.Count();
                                field.Targets = lstElements;
                            }
                        }
                        catch (Exception ex)
                        {
                            Logger.Write(ex, "There was an error while trying to match field '" + fields[index].Name + "'.");
                        }
                        finally
                        {
                            evt.Set();
                        }

                    }, waitHandles[index]);
                }

                var ind = WaitHandle.WaitAny(waitHandles, TimeSpan.FromSeconds(TimeOutInSec));

                return fields.Where(m => m.Status == true).FirstOrDefault() as WebElement;

            }
            return null;
        }
        
        [MTAThread]
        public static WebElement WaitForOne(HTMLDocument doc, int TimeOutInSec, params Field[] fields)
        {
            if (doc != null && fields != null && fields.Count() > 0)
            {
                var autoEvent = new AutoResetEvent(false);
                var taskCount = 0;
                var fieldsList = fields.ToList();

                var startTime = DateTime.Now;
                int timeLeft = TimeOutInSec - Convert.ToInt32(DateTime.Now.Subtract(startTime).TotalSeconds);

                for (int i = 0; i < fields.Count(); i++)
                {
                    var index = i;

                    ThreadPool.QueueUserWorkItem(obj =>
                    {
                        AutoResetEvent evt = obj as AutoResetEvent;

                        try
                        {
                            var field = fields[index] as WebElement;
                            field.Status = false;
                            field.TargetsCount = 0;
                            field.Targets = null;

                            var lstElements = GetElementsByRules(doc, field.MatchRules);

                            do
                            {
                                VisualLog.RaiseOnWaitEvent(field, timeLeft, evt);
                                Logger.Write("Retrying for the web field...'" + field.Name + "' | [Time left : " + timeLeft + " ].");
                                System.Threading.Thread.Sleep(250);
                                lstElements = GetElementsByRules(doc, field.MatchRules);
                                timeLeft = TimeOutInSec - Convert.ToInt32(DateTime.Now.Subtract(startTime).TotalSeconds);

                            } while ((lstElements != null && lstElements.Count() > 0) || (timeLeft <= 0));

                            if (lstElements != null && lstElements.Count() > 0)
                            {
                                field.Status = true;
                                field.TargetsCount = lstElements.Count();
                                field.Targets = lstElements;
                            }
                        }
                        catch (Exception ex)
                        {
                            Logger.Write(ex, "There was an error while trying to match field '" + fields[index].Name + "'.");
                        }
                        finally
                        {
                            if (Interlocked.Decrement(ref taskCount) == 0)
                            {
                                evt.Set();
                            }
                        }

                    }, autoEvent);
                }

                if(autoEvent.WaitOne(TimeSpan.FromSeconds(TimeOutInSec)))
                {
                    return fields.Where(m => m.Status == true).FirstOrDefault() as WebElement;
                }
            }
            return null;
        }
    }
}
