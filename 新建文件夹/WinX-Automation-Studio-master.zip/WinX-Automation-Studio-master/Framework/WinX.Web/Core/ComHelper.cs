﻿using mshtml;
using SHDocVw;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

namespace WinX.Web
{
    public partial class ComHelper
    {
        public static Guid IID_IWebBrowserApp = new Guid("0002DF05-0000-0000-C000-000000000046");
        public static Guid IID_IWebBrowser2 = new Guid("D30C1661-CDAF-11D0-8A3E-00C04FC9E26E");
        public const int E_ACCESSDENIED = unchecked((int)0x80070005);
        
        public static IWebBrowser2 GetWindow(HTMLDocumentClass doc)
        {
            if (doc == null)
                return null;

            IWebBrowser2 window = null;
            IServiceProvider sp = null;

            try
            {
                object brws = null;

                sp = doc.parentWindow as IServiceProvider;

                sp.QueryService(WinX.Core.Win16Helper.IID_IWebBrowserApp, WinX.Core.Win16Helper.IID_IWebBrowser2,out brws);
                window = brws as IWebBrowser2;
            }
            catch (Exception ex)
            {
                WinX.Core.Logger.Write(ex, "An error while trying to get window of a web document.");
            }
            finally
            {
                if (sp != null)
                {
                    Marshal.ReleaseComObject(sp);
                    sp = null;
                }
            }
            return window;
        }


        public static void ExecuteCommand(HTMLDocumentClass doc, OLECMDID cmd, OLECMDEXECOPT obj)
        {
            if (doc == null)
                return;

            try
            {
                var aEvt = new System.Threading.AutoResetEvent(false);

                var thread = new Thread(new ParameterizedThreadStart((object data) =>
                                                                    {
                                                                        IServiceProvider sp = null;
                                                                        object brws = null;

                                                                        try
                                                                        {

                                                                            object[] dataArray = (object[])data;
                                                                            HTMLDocumentClass doc1 = (HTMLDocumentClass)dataArray[1];

                                                                            OLECMDID cmd1 = (OLECMDID)dataArray[2];

                                                                            OLECMDEXECOPT obj1 = (OLECMDEXECOPT)dataArray[3];

                                                                            sp = (IServiceProvider)doc1.parentWindow;
                                                                            sp.QueryService(WinX.Core.Win16Helper.IID_IWebBrowserApp, WinX.Core.Win16Helper.IID_IWebBrowser2, out brws);

                                                                            var objBrowser = brws as IWebBrowser2;

                                                                            if (objBrowser != null)
                                                                            {
                                                                                objBrowser.ExecWB(cmd1, obj1, null, null);
                                                                            }

                                                                        }
                                                                        catch (Exception ex)
                                                                        {
                                                                            WinX.Core.Logger.Write(ex, "[STA Thread]There was an error while trying to get window of a web document.");
                                                                        }
                                                                        finally
                                                                        {
                                                                            object[] dataArray = (object[])data;
                                                                            AutoResetEvent avet1 = (AutoResetEvent)dataArray[0];
                                                                            avet1.Set();
                                                                            if (sp != null)
                                                                            {
                                                                                Marshal.ReleaseComObject(sp);
                                                                                sp = null;
                                                                            }
                                                                        }

                                                                    }));

                thread.SetApartmentState(ApartmentState.STA);
                thread.Start(new object[] { aEvt, doc, cmd, obj });
                if (aEvt.WaitOne(TimeSpan.FromSeconds(5)))
                {
                    WinX.Core.Logger.Write("A window object has been foound for the provided web document.");
                }
                else
                {
                    WinX.Core.Logger.Write("A time out occured while trying to get a window of web document.", WinX.Core.Logger.MsgType.Error);
                }
            }
            catch (Exception ex)
            {
                WinX.Core.Logger.Write(ex, "aAn error while trying to get window of web document");
            }
        }

    }
}
