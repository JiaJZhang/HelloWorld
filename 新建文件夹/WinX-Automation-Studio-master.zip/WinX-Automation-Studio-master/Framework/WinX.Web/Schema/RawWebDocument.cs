﻿using mshtml;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace WinX.Web
{
    public partial class RawWebDocument : RawDocument
    {

        private ObservableCollection<RawWebDocument> pFrames = new ObservableCollection<RawWebDocument>();

        [ReadOnly(true), Browsable(false)]
        public ObservableCollection<RawWebDocument> Frames
        {
            get
            {
                return this.pFrames;
            }
            set
            {
                this.pFrames = value;
            }

        }


        public RawWebDocument(IHTMLDocument2 doc,int handle,int windowHandle)
        {
            try
            {
                this.Title = doc.title;
                this.Url = doc.url;
                this.Document = doc;
                this.Handle = handle;
                this.WindowHandle = windowHandle;
                var doc1 = doc as IHTMLDocument3;

                var frames = doc1.getElementsByTagName("FRAME");

                try
                {
                    if(frames != null && !frames.Equals(DBNull.Value) && frames.length > 0)
                    {
                        foreach(IHTMLFrameBase2 frame in frames)
                        {
                            try
                            {
                                var w2 = frame as SHDocVw.IWebBrowser2;

                                var framedoc = new RawWebDocument(w2.Document as IHTMLDocument2, this.Handle, this.WindowHandle);
                                framedoc.Parent = this;
                                framedoc.IsFrame = true;
                                this.Frames.Add(framedoc);
                            }
                            catch(Exception ex)
                            {

                            }
                        }
                    }                    
                }
                catch(Exception ex)
                {
                    WinX.Core.Logger.Write(ex, "There was an error while trying to create an instance of RawWebDocument from 'FRAMES'.");
                }

                frames = doc1.getElementsByTagName("IFRAME");

                try
                {
                    if (frames != null && !frames.Equals(DBNull.Value) && frames.length > 0)
                    {
                        foreach (IHTMLFrameBase2 frame in frames)
                        {
                            try
                            {
                                var w2 = frame as SHDocVw.IWebBrowser2;

                                var framedoc = new RawWebDocument(w2.Document as IHTMLDocument2, this.Handle, this.WindowHandle);
                                framedoc.Parent = this;
                                framedoc.IsFrame = true;
                                this.Frames.Add(framedoc);
                            }
                            catch (Exception ex)
                            {

                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    WinX.Core.Logger.Write(ex, "There was an error while trying to create an instance of RawWebDocument from 'iFRAMES'.");
                }

            }
            catch(Exception ex)
            {
                WinX.Core.Logger.Write(ex, "There was an error while trying to create an instance of RawWebDocument.");
            }
        }

        public void ExecuteCommand(OLECMDID cmd, OLECMDEXECOPT obj, object pvaIn = null, object pvaOut = null)
        {
            try
            {
                ComHelper.ExecuteCommand(this.Document as HTMLDocumentClass, cmd, obj);
            }
            catch (Exception ex)
            {
                WinX.Core.Logger.Write(ex, "There was an error while trying to execute command '" + cmd.ToString() + "' on browser window object.");
            }
        }

        public void Close(bool promptUser)
        {
            if(promptUser)
            {
                this.ExecuteCommand(OLECMDID.OLECMDID_CLOSE, OLECMDEXECOPT.OLECMDEXECOPT_PROMPTUSER);
            }
            else
            {
                this.ExecuteCommand(OLECMDID.OLECMDID_CLOSE, OLECMDEXECOPT.OLECMDEXECOPT_DONTPROMPTUSER);
            }
        }
    }
}
