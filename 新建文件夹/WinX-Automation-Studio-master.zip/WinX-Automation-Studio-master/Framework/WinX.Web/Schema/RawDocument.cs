﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace WinX.Web
{
    public partial class RawDocument : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged(string propertyName)
        {
            if (this.PropertyChanged != null)
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        private string title;

        public string Title
        {
            get
            {
                return title;
            }
            set
            {
                title = value;
                NotifyPropertyChanged("Title");
            }
        }

        private string url;

        public string Url
        {
            get
            {
                return this.url;
            }
            set
            {
                url = value;
                NotifyPropertyChanged("Url");
            }
        }

        [ReadOnly(true), Browsable(false)]
        public object Document
        {
            get; set;
        }

        [Browsable(false)]
        public RawDocument Parent
        {
            get; set;
        }


        [Browsable(true)]
        public bool IsFrame
        {
            get; set;
        }

        [Browsable(true),DisplayName("Handle")]
        public int Handle
        {
            get; set;
        }
        
        [ReadOnly(true), DisplayName("TabHandle")]
        public int TabHandle
        {
            get; set;
        }


        [ReadOnly(true), DisplayName("WindowHandle")]
        public int WindowHandle
        {
            get; set;
        }

        public void BringWindowTop()
        {
            WinX.Core.Win16Helper.BringWindowTop(this.WindowHandle);
        }
    }
}
