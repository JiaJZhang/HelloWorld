﻿using mshtml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Xml.Serialization;
using WinX.Core;

namespace WinX.Web
{
    [ComVisible(true), Serializable()]
    public partial class WebScreen : Screen
    {
        [XmlIgnore]
        public HTMLDocumentClass HTMLDocument
        {
            get; set;
        }

        public WebScreen() : base()
        {

        }

        public override bool Refresh(bool MatchAllChildern = false)
        {
            return this.IsCreated(MatchAllChildern);
        }

        public bool IsCreated()
        {
            WinX.Core.Logger.Write("Attempting to locate document for the screen '" + this.Name + "'.");

            if (this.MatchRules != null && this.MatchRules.Count > 0)
            {
                this.HTMLDocument = MatchEngine.GetDocumentByRule(this);
                this.Status = HTMLDocument != null;

                if (this.Status)
                {
                    WinX.Core.Logger.Write("Document found for the screen '" + this.Name + "'.");
                }
                else
                {
                    WinX.Core.Logger.Write("No document found for the screen '" + this.Name + "'.");
                }
                return this.Status;
            }
            return false;
        }

        public bool IsCreated(bool matchAllChildern)
        {
            if (IsCreated())
            {
                if (matchAllChildern)
                {
                    return MatchAllElements();
                }
                return true;
            }

            return false;
        }

        public bool IsCreated(WebElement[] fields)
        {
            if (IsCreated())
            {
                if (fields != null && fields.Count() > 0)
                {
                    return this.MatchElements(TimeoutInSec, fields);
                }
                return this.Status;
            }
            return false;
        }



        public bool MatchAllElements(int timeoutInSec = 30)
        {
            if (MatchEngine.MactchElements(this.HTMLDocument, this.Fields, timeoutInSec))
            {
                WinX.Core.Logger.Write("All the specified elements for the screen '" + this.Name + "' are matched.");
                return true;
            }

            WinX.Core.Logger.Write("The specified elements for the screen '" + this.Name + "' did not match..", Logger.MsgType.Error);
            return true;
        }

        public bool MatchElements(int timeOutInSec, params WebElement[] fields)
        {
            if (MatchEngine.MactchElements(this.HTMLDocument, fields.ToArray(), timeOutInSec))
            {
                WinX.Core.Logger.Write("All the specified elements for the screen '" + this.Name + "' are matched.");
                return true;
            }

            WinX.Core.Logger.Write("The specified elements for the screen '" + this.Name + "' did not matched.", WinX.Core.Logger.MsgType.Error);
            return false;
        }
        public bool WaitForAllElements(int timeOutInSec)
        {
            return MatchEngine.WaitForAll(this.HTMLDocument, TimeoutInSec, this.Fields.ToArray());
        }

        public bool WaitForElements(int timeOutInSec, params WebElement[] fields)
        {
            return MatchEngine.WaitForAll(this.HTMLDocument, TimeoutInSec, fields.ToArray());
        }

        public WebElement WaitForAnyElements(int timeOutInSec, params WebElement[] fields)
        {
            return MatchEngine.WaitForAny(this.HTMLDocument, TimeoutInSec, fields.ToArray());
        }

        public object WaitForAnyObject(int timeOutInSec, params object[] objects)
        {
            try
            {
                if (objects == null || objects.Count() < 1)
                {
                    return null;
                }

                if (timeOutInSec < 6)
                {
                    timeOutInSec = 5;
                }

                AutoResetEvent[] waithandles = new AutoResetEvent[objects.Count() - 1];

                var hasComplete = false;

                for (int i = 0; i < objects.Count(); i++)
                {
                    var index = i;
                    waithandles[index] = new AutoResetEvent(false);

                    ThreadPool.QueueUserWorkItem(obj =>
                            {
                                AutoResetEvent handle = obj as AutoResetEvent;

                                try
                                {
                                    var field = objects[index];

                                    while (field != null || hasComplete)
                                    {
                                        System.Threading.Thread.Sleep(250);
                                    }
                                }
                                catch (Exception ex)
                                {
                                    dynamic mObj = objects[index];

                                    WinX.Core.Logger.Write(ex, "[WaitForAnyScreen] : There was an error while trying to wait for screen '" + mObj.Name + "'.");
                                }
                                finally
                                {
                                    handle.Set();
                                }
                            }, waithandles[index]);
                }
                var ind = WaitHandle.WaitAny(waithandles, TimeSpan.FromSeconds(timeOutInSec));
                hasComplete = true;
                return objects.Where(m => m != null).FirstOrDefault();

            }
            catch (Exception ex)
            {
                WinX.Core.Logger.Write(ex, "[Wait.ForAnyScreen] - An exception occured while trying to execute actions provided.");
            }
            return null;
        }

        public bool WaitForLoadComplete(int TimeoutInSec = 30, bool MatchAllChildern = false)
        {
            if (WaitForCreate(base.TimeoutInSec, MatchAllChildern))
            {
                var mEvent = new AutoResetEvent(false);

                try
                {
                    var startTime = DateTime.Now;
                    int timeLeft = TimeoutInSec - Convert.ToInt32(DateTime.Now.Subtract(startTime).TotalSeconds);

                    ThreadPool.QueueUserWorkItem(obj =>
                    {
                        AutoResetEvent evt = obj as AutoResetEvent;

                        try
                        {
                            while (!IsCreated(MatchAllChildern) && !this.HTMLDocument.readyState.Equals("complete") && timeLeft > 0)
                            {
                                WinX.Core.VisualLog.RaiseOnWaitEvent(this, timeLeft, evt);
                                Logger.Write("Retrying for the screen '" + this.Name + "' to load complete| [Time left : " + timeLeft + " ].");
                                System.Threading.Thread.Sleep(600);
                                timeLeft = TimeoutInSec - Convert.ToInt32(DateTime.Now.Subtract(startTime).TotalSeconds);

                            }
                        }
                        catch (Exception ex)
                        {
                            WinX.Core.Logger.Write(ex, "[WaitForAnyScreen] : There was an error while trying to wait for Web document to be created.");
                        }
                        finally
                        {
                            evt.Set();
                        }
                    }, mEvent);

                    VisualLog.RaiseOnWaitEvent(this, timeLeft, mEvent);

                    if (mEvent.WaitOne(TimeSpan.FromSeconds(base.TimeoutInSec)))
                    {
                        Logger.Write("WaitForLoadComplete was success for the screen '" + this.Name + "'");
                        VisualLog.RaiseWaitCompleteEvent(this, mEvent);
                        return true;
                    }
                }
                catch (Exception ex)
                {
                    Logger.Write(ex, "There was an error while trying wait for the screen '" + this.Name + "'.");
                }
                VisualLog.RaiseWaitCompleteEvent(this, mEvent);
            }
            return false;
        }


        public override bool WaitForCreate(int TimeoutInSec = 30, bool MatchAllChildern = false)
        {
            Logger.Write("Waiting for the screen... '" + this.Name + "'.");

            this.HTMLDocument = null;

            if (this.MatchRules != null && this.MatchRules.Count() > 0)
            {
                var mEvent = new AutoResetEvent(false);

                try
                {
                    var startTime = DateTime.Now;
                    int timeLeft = TimeoutInSec - Convert.ToInt32(DateTime.Now.Subtract(startTime).TotalSeconds);

                    ThreadPool.QueueUserWorkItem(obj =>
                    {
                        AutoResetEvent evt = obj as AutoResetEvent;

                        try
                        {
                            while (!IsCreated(MatchAllChildern) && timeLeft > 0)
                            {
                                WinX.Core.VisualLog.RaiseOnWaitEvent(this, timeLeft, evt);
                                Logger.Write("Retrying for the screen '" + this.Name + "' to load complete| [Time left : " + timeLeft + " ].");
                                System.Threading.Thread.Sleep(600);
                                timeLeft = TimeoutInSec - Convert.ToInt32(DateTime.Now.Subtract(startTime).TotalSeconds);
                            }
                        }
                        catch (Exception ex)
                        {
                            WinX.Core.Logger.Write(ex, "[WaitForAnyScreen] : There was an error while trying to wait for Web document to be created.");
                        }
                        finally
                        {
                            evt.Set();
                        }
                    }, mEvent);

                    VisualLog.RaiseOnWaitEvent(this, timeLeft, mEvent);

                    if (mEvent.WaitOne(TimeSpan.FromSeconds(base.TimeoutInSec)))
                    {
                        Logger.Write("WaitForLoadComplete was success for the screen '" + this.Name + "'");
                        //VisualLog.RaiseWaitCompleteEvent(this, mEvent);
                        //return true;
                    }
                }
                catch (Exception ex)
                {
                    Logger.Write(ex, "There was an error while trying wait for the screen '" + this.Name + "'.");
                }
                VisualLog.RaiseWaitCompleteEvent(this, mEvent);

                if (this.HTMLDocument != null)
                {
                    Logger.Write("Document found for the screen '" + this.Name + "'.");
                    return true;
                }

                Logger.Write("No document found for the screen '" + this.Name + "'.");
            }
            return false;
        }

        public HTMLDocumentClass GetDocument()
        {
            return this.HTMLDocument;
        }

        public void SetURL(string URL)
        {
            if (this.HTMLDocument != null)
            {
                this.HTMLDocument.url = URL;
                System.Threading.Thread.Sleep(200);
            }
            else
            {
                Logger.Write("Webdocument is null,URl ca not be Set.", Logger.MsgType.Error);
            }
        }

        public T GetField<T>(Guid fieldId) where T : class
        {
            var fld = this.Fields.Where(m => m.ID == fieldId).FirstOrDefault();

            if (fld != null)
            {
                T obj = MatchEngine.GetElementsByRules(this.HTMLDocument, fld.MatchRules).FirstOrDefault() as T;

                if (obj != null)
                {
                    Logger.Write("An match found for the element '" + fld.Name + "' on the screen '" + this.Name + "'.");

                }
                else
                {
                    Logger.Write("Not matches found for the element '" + fld.Name + "' on the screen '" + this.Name + "'.", Logger.MsgType.Error);
                }
                return obj;
            }

            Logger.Write("Could not identify any property with the ID --> [" + ID.ToString() + "] from the screen '" + this.Name + "'.", Logger.MsgType.Error);

            return null;
        }


        public IList<T> GetFields<T>(Guid fieldId) where T : class
        {
            var fld = this.Fields.Where(m => m.ID == fieldId).FirstOrDefault();

            if (fld != null)
            {
                var elements = MatchEngine.GetElementsByRules(this.HTMLDocument, fld.MatchRules);

                if (elements != null)
                {
                    var lst = new List<T>();

                    foreach (var ele in elements)
                    {
                        lst.Add(ele as T);
                    }
                    Logger.Write(lst.Count + " matches found for the element '" + fld.Name + "' on the screen '" + this.Name + "'.");
                    return lst;
                }
                else
                {
                    Logger.Write("Not matches found for the element '" + fld.Name + "' on the screen '" + this.Name + "'.", Logger.MsgType.Error);
                }
                return null;
            }

            Logger.Write("Could not identify any property with the ID --> [" + ID.ToString() + "] from the screen '" + this.Name + "'.", Logger.MsgType.Error);

            return null;
        }

        public bool ExecuteJScript(string strScript)
        {
            var aEvt = new AutoResetEvent(false);
            try
            {

                var thread = new Thread((obj) =>
                {
                    dynamic data = obj;
                    var evt = data[0] as AutoResetEvent;
                    var data1 = data[1] as HTMLDocumentClass;
                    string data2 = data[2];

                    try
                    {
                        var window = data1.parentWindow as IHTMLWindow2;
                        window.execScript(data2);
                    }
                    catch (Exception ex)
                    {
                        WinX.Core.Logger.Write(ex, "[STA Thread] An error occured while trying invoke javascript from the screen '" + this.Name + "'.");
                    }
                    finally
                    {
                        evt.Set();
                    }
                });

                thread.SetApartmentState(ApartmentState.STA);
                thread.Start(new object[] { aEvt, this.HTMLDocument, strScript });
                if (aEvt.WaitOne(TimeSpan.FromSeconds(5)))
                {
                    Logger.Write("Javascript was executed successfully on the screen '" + this.Name + "' [" + strScript + "].");
                }
                else
                {
                    Logger.Write("A time out occured while trying to execute javascript on the sereen '" + this.Name + "' [" + strScript + "].", Logger.MsgType.Error);
                }

            }
            catch (Exception ex)
            {
                Logger.Write(ex, "An error occured while trying to invoke javascript from the screen '" + this.Name + "' [" + strScript + "].");
            }
            return false;
        }

        #region SHDocVw.WebBrowser methods

        public IWebBrowser2 GetWindow()
        {
            return ComHelper.GetWindow(this.HTMLDocument);
        }

        public int GetHandle()
        {
            var handle = 0;

            try
            {
                handle = WinX.Core.Wait.RunOnSTA(() =>
                {

                    int hwnd = 0;
                    IWebBrowser2 objBrowser = null;
                    try
                    {
                        objBrowser = GetWindow();
                        if (objBrowser != null)
                        {
                            hwnd = objBrowser.HWND;
                        }
                    }
                    catch (Exception ex)
                    {
                        Logger.Write(ex, "There was an exception while trying to minimize screen '" + this.Name + "'.");
                    }
                    finally
                    {
                        Marshal.ReleaseComObject(objBrowser);
                        objBrowser = null;
                    }
                    return hwnd;
                });
            }
            catch (Exception ex)
            {
                Logger.Write(ex, "There was an exception while trying to minimize screen '" + this.Name + "'.");
            }
            return handle;
        }

        public bool Minimize()
        {
            try
            {
                return WinX.Core.Wait.RunOnSTA(() =>
                {
                    var objBrowser = GetWindow();
                    if (objBrowser != null && objBrowser.HWND != 0)
                    {
                        WinX.Core.Win16Helper.ShowWindow(objBrowser.HWND, Win16Helper.SW_SHOWMINIMIZED);
                        return true;
                    }
                    return false;
                }, 2);
            }
            catch (Exception ex)
            {
                Logger.Write(ex, "There was an error while trying to minimize screen '" + this.Name + "'.");
            }
            return false;
        }

        public bool Restore()
        {
            try
            {
                return WinX.Core.Wait.RunOnSTA(() =>
                {
                    var objBrowser = GetWindow();
                    if (objBrowser != null && objBrowser.HWND != 0)
                    {
                        WinX.Core.Win16Helper.ShowWindow(objBrowser.HWND, Win16Helper.SW_SHOWNORMAL);
                        return true;
                    }
                    return false;
                }, 2);
            }
            catch (Exception ex)
            {
                Logger.Write(ex, "There was an error while trying to restore screen '" + this.Name + "'.");
            }
            return false;
        }

        public bool Maxminze()
        {
            try
            {
                return WinX.Core.Wait.RunOnSTA(() =>
                {
                    var objBrowser = GetWindow();
                    if (objBrowser != null && objBrowser.HWND != 0)
                    {
                        WinX.Core.Win16Helper.ShowWindow(objBrowser.HWND, Win16Helper.SW_SHOWMAXIMIZED);
                        return true;
                    }
                    return false;
                }, 2);
            }
            catch (Exception ex)
            {
                Logger.Write(ex, "There was an error while trying to maximize screen '" + this.Name + "'.");
            }
            return false;
        }

        public bool BringWindowFront()
        {
            try
            {
                return WinX.Core.Wait.RunOnSTA(() =>
                {
                    var objBrowser = GetWindow();
                    if (objBrowser != null && objBrowser.HWND != 0)
                    {
                        WinX.Core.Win16Helper.SetForegroundWindow(objBrowser.HWND);
                        WinX.Core.Win16Helper.SetActiveWindow(objBrowser.HWND);
                        WinX.Core.Win16Helper.SetFocus(objBrowser.HWND);

                        return true;
                    }
                    return false;
                }, 2);
            }
            catch (Exception ex)
            {
                Logger.Write(ex, "There was an error while trying to brings screen '" + this.Name + "' fronts.");
            }
            return false;
        }

        public void ExecuteCommand(OLECMDID cmd, OLECMDEXECOPT obj, object pvaIn = null, object pvaOut = null)
        {
            try
            {
                ComHelper.ExecuteCommand(this.HTMLDocument, cmd, obj);
            }
            catch (Exception ex)
            {
                Logger.Write(ex, "There was an error while trying to execute command '" + cmd.ToString() + "' on the screen '" + this.Name + "'.");
            }
        }

        public void Print(bool PromptUser = true)
        {
            if (PromptUser)
            {
                this.ExecuteCommand(OLECMDID.OLECMDID_PRINT, OLECMDEXECOPT.OLECMDEXECOPT_PROMPTUSER);
            }
            else
            {
                this.ExecuteCommand(OLECMDID.OLECMDID_PRINT, OLECMDEXECOPT.OLECMDEXECOPT_DONTPROMPTUSER);
            }
        }

        public void Close()
        {
            this.ExecuteCommand(OLECMDID.OLECMDID_CLOSE, OLECMDEXECOPT.OLECMDEXECOPT_PROMPTUSER);
        }

        public void SaveAs()
        {
            this.ExecuteCommand(OLECMDID.OLECMDID_SAVEAS, OLECMDEXECOPT.OLECMDEXECOPT_PROMPTUSER);
        }

        public Bitmap GetScreenshot(bool BringWindowFront = false)
        {
            try
            {
                return WinX.Core.Wait.RunOnSTA(() =>
                {
                    var objBrowser = GetWindow();
                    if (objBrowser != null && objBrowser.HWND != 0)
                    {
                        var hwnd = objBrowser.HWND;
                        if (BringWindowFront)
                        {
                            WinX.Core.Win16Helper.SetForegroundWindow(hwnd);
                        }
                        var disImage = new WinX.Core.DisplayItem(new IntPtr(hwnd));
                        return disImage.GetVisibleImage();
                    }
                    return null;
                }, 2);
            }
            catch (Exception ex)
            {
                Logger.Write(ex, "There was an exception while trying to capture bitmap of web screen '" + this.Name + "'.");
            }
            return null;
        }

        #endregion

        #region Events

        public delegate void WebEvent(WebScreen screen);

        private event EventManager.ScreenCreatedHander createdEvent;
        public event WebEvent Created
        {
            add
            {
                var screen = EventManager.Screens.Where(m => m.ID == this.ID).FirstOrDefault();
                if (screen != null)
                {
                    EventManager.Screens.Add(this);
                }

                createdEvent = new EventManager.ScreenCreatedHander((WebScreen s, RawDocument target) =>
                {
                    if (s.ID.Equals(this.ID))
                    {
                        this.HTMLDocument = target.Document as HTMLDocumentClass;
                        value.Invoke(s);
                    }
                });

                EventManager.ScreenCreated += createdEvent;
            }
            remove
            {
                if (createdEvent != null)
                {
                    EventManager.ScreenCreated -= createdEvent;
                }
                var screen = EventManager.Screens.Where(m => m.ID == this.ID).FirstOrDefault();
                if (screen == null)
                {
                    EventManager.Screens.Remove(this);
                }
            }
        }

        //public void OnCreated()
        //{
        //    Created
        //}


        private event EventManager.ScreenDestroyedHander destroyedEvent;
        public event WebEvent DestroyedEvent
        {
            add
            {
                var screen = EventManager.Screens.Where(m => m.ID == this.ID).FirstOrDefault();
                if (screen != null)
                {
                    EventManager.Screens.Add(this);
                }

                destroyedEvent = new EventManager.ScreenDestroyedHander((WebScreen s) =>
                {
                    if (s.ID.Equals(this.ID))
                    {
                        this.HTMLDocument = null;
                        value.Invoke(s);
                    }
                });

                EventManager.ScreenDestroyed += destroyedEvent;
            }
            remove
            {
                if (destroyedEvent != null)
                {
                    this.HTMLDocument = null;
                    EventManager.ScreenDestroyed -= destroyedEvent;
                }
            }
        }

        public event HtmlEvent FocusOut
        {
            add
            {
                var dispDoc = this.HTMLDocument as DispHTMLDocument;
                var existingHandler = dispDoc.onfocusout;

                var handler = existingHandler is HTMLEventHandler ? existingHandler as HTMLEventHandler : new HTMLEventHandler(this.HTMLDocument);
                dispDoc.onfocusin = handler;

                handler.eventHander += value;
            }
            remove
            {
                var dispDoc = this.HTMLDocument as DispHTMLDocument;
                var existingHandler = dispDoc.onfocusout;
                var handler = existingHandler as HTMLEventHandler;

                if (handler != null)
                {
                    handler.eventHander -= value;
                }
            }
        }

        public void OnFocusOut()
        {
            var dispDoc = this.HTMLDocument as DispHTMLDocument;
            var existingHandler = dispDoc.onfocusout;

            var handler = existingHandler as HTMLEventHandler;
            if (handler != null)
            {
                handler.FireEvent();
            }
        }


        public event HtmlEvent FocusIn
        {
            add
            {
                var dispDoc = this.HTMLDocument as DispHTMLDocument;
                var existingHandler = dispDoc.onfocusin;

                var handler = existingHandler is HTMLEventHandler ? existingHandler as HTMLEventHandler : new HTMLEventHandler(this.HTMLDocument);
                dispDoc.onfocusin = handler;

                handler.eventHander += value;
            }
            remove
            {
                var dispDoc = this.HTMLDocument as DispHTMLDocument;
                var existingHandler = dispDoc.onfocusin;
                var handler = existingHandler as HTMLEventHandler;

                if (handler != null)
                {
                    handler.eventHander -= value;
                }
            }
        }

        public void OnFocusIn()
        {
            var dispDoc = this.HTMLDocument as DispHTMLDocument;
            var existingHandler = dispDoc.onfocusin;

            var handler = existingHandler as HTMLEventHandler;
            if (handler != null)
            {
                handler.FireEvent();
            }
        }


        public event HtmlEvent ContextMenu
        {
            add
            {
                var dispDoc = this.HTMLDocument as DispHTMLDocument;
                var existingHandler = dispDoc.oncontextmenu;

                var handler = existingHandler is HTMLEventHandler ? existingHandler as HTMLEventHandler : new HTMLEventHandler(this.HTMLDocument);
                dispDoc.onfocusin = handler;

                handler.eventHander += value;
            }
            remove
            {
                var dispDoc = this.HTMLDocument as DispHTMLDocument;
                var existingHandler = dispDoc.oncontextmenu;
                var handler = existingHandler as HTMLEventHandler;

                if (handler != null)
                {
                    handler.eventHander -= value;
                }
            }
        }

        public void OnContextMenu()
        {
            var dispDoc = this.HTMLDocument as DispHTMLDocument;
            var existingHandler = dispDoc.oncontextmenu;

            var handler = existingHandler as HTMLEventHandler;
            if (handler != null)
            {
                handler.FireEvent();
            }
        }

        public event HtmlEvent Click
        {
            add
            {
                var dispDoc = this.HTMLDocument as DispHTMLDocument;
                var existingHandler = dispDoc.onclick;

                var handler = existingHandler is HTMLEventHandler ? existingHandler as HTMLEventHandler : new HTMLEventHandler(this.HTMLDocument);
                dispDoc.onfocusin = handler;

                handler.eventHander += value;
            }
            remove
            {
                var dispDoc = this.HTMLDocument as DispHTMLDocument;
                var existingHandler = dispDoc.onclick;
                var handler = existingHandler as HTMLEventHandler;

                if (handler != null)
                {
                    handler.eventHander -= value;
                }
            }
        }

        public void OnClick()
        {
            var dispDoc = this.HTMLDocument as DispHTMLDocument;
            var existingHandler = dispDoc.onclick;

            var handler = existingHandler as HTMLEventHandler;
            if (handler != null)
            {
                handler.FireEvent();
            }
        }

        public event HtmlEvent DoubleClick
        {
            add
            {
                var dispDoc = this.HTMLDocument as DispHTMLDocument;
                var existingHandler = dispDoc.ondblclick;

                var handler = existingHandler is HTMLEventHandler ? existingHandler as HTMLEventHandler : new HTMLEventHandler(this.HTMLDocument);
                dispDoc.onfocusin = handler;

                handler.eventHander += value;
            }
            remove
            {
                var dispDoc = this.HTMLDocument as DispHTMLDocument;
                var existingHandler = dispDoc.ondblclick;
                var handler = existingHandler as HTMLEventHandler;

                if (handler != null)
                {
                    handler.eventHander -= value;
                }
            }
        }

        public void OnDoubleClick()
        {
            var dispDoc = this.HTMLDocument as DispHTMLDocument;
            var existingHandler = dispDoc.ondblclick;

            var handler = existingHandler as HTMLEventHandler;
            if (handler != null)
            {
                handler.FireEvent();
            }
        }

        #endregion


        #region Ext function

        public Rectangle GetWindowLocation(IntPtr hWnd)
        {
            if (hWnd != IntPtr.Zero)
            {
                var rect = new Rectangle();
                User32.GetWindowRect(hWnd, ref rect);
                return rect;
            }
            return Rectangle.Empty;
        }

        public Bitmap GetIECaputre(int hwndInt, mshtml.HTMLDocumentClass document)
        {
            int GW_CHILD = 5;
            int GW_HWNDNEXT = 2;
            var myDoc = document;

            string myLocalLink = myDoc.url;
            int URLExtraHeight = 0;
            int URLExtraLeft = 0;

            int trimHeight = 3;
            int trimLeft = 3;
            bool isUsedBodyHeight = false;
            bool isUsedBodyWidth = false;

            URLExtraHeight = URLExtraHeight - trimHeight;
            URLExtraLeft = URLExtraLeft - trimLeft;

            int screenHeight = (int)myDoc.documentElement.getAttribute("clientHeight", 0);

            int heightsize = 0;
            int widthsize = 0;

            var dd = WinX.Core.User32.GetDisplays();

            if (screenHeight == 0)
            {
                myDoc.body.setAttribute("scroll", "yes", 0);
                screenHeight = (int)myDoc.body.getAttribute("clientHeight", 0);
                heightsize = (int)myDoc.body.getAttribute("scrollHeight", 0);
                isUsedBodyHeight = true;
            }
            else
            {
                myDoc.documentElement.setAttribute("scroll", "yes", 0);
                heightsize = (int)myDoc.documentElement.getAttribute("scrollHeight", 0);
            }

            int screenWidth = (int)myDoc.documentElement.getAttribute("clientWidth", 0);

            if (screenWidth == 0)
            {
                screenWidth = (int)myDoc.body.getAttribute("clientWidth", 0);
                widthsize = (int)myDoc.body.getAttribute("scrollWidth", 0);
                isUsedBodyWidth = true;
            }
            else
            {
                widthsize = (int)myDoc.documentElement.getAttribute("scrollWidth", 0);
            }
            var bm = new Bitmap(screenWidth, screenHeight, System.Drawing.Imaging.PixelFormat.Format16bppRgb555);

            var bm2 = new Bitmap(widthsize + URLExtraLeft, heightsize + URLExtraHeight - trimHeight, System.Drawing.Imaging.PixelFormat.Format16bppRgb555);
            var g2 = Graphics.FromImage(bm2);

            Graphics g = null;
            IntPtr hdc;
            Image screenfrag = null;
            int brwTop = 0;
            int brwLeft = 0;
            int myPage = 0;

            var hwnd = new IntPtr(hwndInt);
            hwnd = WinX.Core.User32.GetWindow(hwnd, GW_CHILD);
            var sbc = new StringBuilder(256);

            while (hwndInt != 0)
            {
                hwndInt = hwnd.ToInt32();
                WinX.Core.User32.GetClassName(hwnd, sbc, 256);

                if (sbc.ToString().IndexOf("Shell DocObject View", 0) > -1)
                {
                    hwnd = User32.FindWindowEx(hwnd, IntPtr.Zero, "Internet Explorer_Server", IntPtr.Zero);
                    break;
                }

                if(sbc.ToString().IndexOf("TabWindowClass",0) > -1)//IE7
                {
                    hwnd = WinX.Core.User32.FindWindowEx(hwnd, IntPtr.Zero, "Shell DocObject View", IntPtr.Zero);
                    hwnd = WinX.Core.User32.FindWindowEx(hwnd, IntPtr.Zero, "Internet Explorer_Server", IntPtr.Zero);
                    break;
                }

                if (sbc.ToString().IndexOf("Frame Tab", 0) > -1)//IE8
                {
                    hwnd = WinX.Core.User32.FindWindowEx(hwnd, IntPtr.Zero, "TabWindowClass", IntPtr.Zero);
                    hwnd = WinX.Core.User32.FindWindowEx(hwnd, IntPtr.Zero, "Shell DocObject View", IntPtr.Zero);
                    hwnd = WinX.Core.User32.FindWindowEx(hwnd, IntPtr.Zero, "Internet Explorer_Server", IntPtr.Zero);
                    break;
                }

                hwnd = User32.GetWindow(hwnd, GW_HWNDNEXT);
            }

            while ((myPage * screenHeight) < heightsize)
            {
                if (isUsedBodyHeight)
                {
                    myDoc.body.setAttribute("scrollTop", (screenHeight - 5) * myPage, 0);
                }
                else
                {
                    myDoc.documentElement.setAttribute("scrollTop", (screenHeight - 5) * myPage, 0);
                }

                ++myPage;
            }

            --myPage;

            int myPageWidth = 0;


            while ((myPageWidth * screenWidth) < widthsize)
            {
                if (isUsedBodyWidth)
                {
                    myDoc.body.setAttribute("scrollLeft", (screenWidth - 5) * myPageWidth, 0);
                    brwLeft = (int)myDoc.body.getAttribute("scrollLeft", 0);
                }
                else
                {
                    myDoc.documentElement.setAttribute("scrollLeft", (screenWidth - 5) * myPageWidth, 0);
                    brwLeft = (int)myDoc.documentElement.getAttribute("scrollLeft", 0);
                }

                for (int i = myPage; i >= 0; --i)
                {
                    g = Graphics.FromImage(bm);
                    hdc = g.GetHdc();
                    if (isUsedBodyWidth)
                    {
                        myDoc.body.setAttribute("scrollTop", (screenHeight - 5) * i, 0);
                        brwTop = (int)myDoc.body.getAttribute("scrollTop", 0);
                    }
                    else
                    {
                        myDoc.documentElement.setAttribute("scrollTop", (screenHeight - 5) * i, 0);
                        brwTop = (int)myDoc.documentElement.getAttribute("scrollTop", 0);
                    }

                    WinX.Core.User32.PrintWindow(hwnd, hdc, 0);
                    g.ReleaseHdc(hdc);
                    g.Flush();
                    screenfrag = Image.FromHbitmap(bm.GetHbitmap());
                    g2.DrawImage(screenfrag, brwLeft + URLExtraLeft, brwTop + URLExtraHeight);
                }
                ++myPageWidth;
            }

            double myResolution = 100d * 0.01;
            int finalwidth = (int)((widthsize + URLExtraLeft) * myResolution);
            int finalHeight = (int)((heightsize + URLExtraHeight * myResolution));
            Bitmap finalImage = new Bitmap(finalwidth, finalHeight, System.Drawing.Imaging.PixelFormat.Format16bppRgb555);
            Graphics gFinal = Graphics.FromImage((Image)finalImage);
            gFinal.DrawImage(bm2, 0, 0, finalwidth, finalHeight);

            gFinal.Save();
            myDoc = null;
            g.Dispose();
            g2.Dispose();
            gFinal.Dispose();
            bm.Dispose();
            bm2.Dispose();
            return finalImage;
        }

        //public void ActiveTabByTitle(string title)
        //{
        //    try
        //    {
        //        IEAccessible ie = new IEAccessible();
        //        var 
        //    }
        //}

        public Bitmap GetIEScreenCapture(mshtml.HTMLDocumentClass docutment = null, int? handle = null)
        {
            var handleId = 0;
            mshtml.HTMLDocumentClass mydoc = null;
            var domTitle = string.Empty;
            if (docutment == null)
            {
                handleId = ComHelper.GetWindow(this.GetDocument()).HWND;
                mydoc = this.GetDocument();
                domTitle = mydoc.title;
            }
            else
            {
                domTitle = docutment.title;
                handleId = handle.HasValue ? handle.Value : ComHelper.GetWindow(this.GetDocument()).HWND;

                mydoc = docutment;
            }

            while (!mydoc.readyState.ToString().ToLower().Equals("complete")) ;
            System.Threading.Thread.Sleep(500);
            //this.ActiveTabByTitle
            SetWindowToforgroud(handleId);

            return GetIECaputre(handleId, mydoc);
        }

        private void SetWindowToforgroud(int nativeWindowHandle)
        {
            WinX.Core.User32.ShowWindow(nativeWindowHandle, User32.CmdShow.SW_SHOWDEFAULT);
            WinX.Core.User32.ShowWindow(nativeWindowHandle, User32.CmdShow.SW_SHOWDEFAULT);
            WinX.Core.User32.SetForegroundWindow(new IntPtr(nativeWindowHandle));
            WinX.Core.User32.SetFocus(nativeWindowHandle);
        }

        private mshtml.HTMLDocumentClass GetFrameByName(string frameName, mshtml.HTMLDocumentClass document = null)
        {
            mshtml.HTMLDocumentClass mainFrameDoc = null;
            mshtml.HTMLDocumentClass mydoc = null;

            if (null != mydoc)
            {
                mydoc = this.GetDocument();
            }

            mshtml.FramesCollection frames = mydoc.frames;
            mshtml.IHTMLWindow2 mainFrame = null;

            for (int i = 0; i < frames.length; i++)
            {
                object refIndex = i;
                var frame = frames.item(ref refIndex) as mshtml.IHTMLWindow2;
                if (null != frame && frame.name == frameName)
                {
                    mainFrame = frame;
                    break;
                }
                else if (null != frame && null != frames && frame.frames.length > 0)
                {
                    mainFrame = GetRootFrameByName(frameName, frame);
                }
            }

            if (mainFrame != null)
            {
                mainFrameDoc = mainFrame.document as HTMLDocumentClass;
            }

            return mainFrameDoc;
        }

        private mshtml.IHTMLWindow2 GetRootFrameByName(string frameName, mshtml.IHTMLWindow2 parentFrame)
        {
            var frames = parentFrame as mshtml.FramesCollectionClass;
            mshtml.IHTMLWindow2 mainFrame = null;
            if (null != frames && frames.length > 0)
            {
                for (int i = 0; i < frames.length; i++)
                {
                    object refIndex = i;
                    var frame = frames.item(ref refIndex) as mshtml.IHTMLWindow2;
                    if (null != frame && frame.name == frameName)
                    {
                        mainFrame = frame;
                    }
                    else if (null != frame && null != frame.frames && frame.frames.length > 0)
                    {
                        mainFrame = GetRootFrameByName(frameName, frame);
                    }

                    if (null != mainFrame)
                    {
                        return mainFrame;
                    }

                }
            }
            return mainFrame;
        }


        /// <summary>
        /// getElementScreenCapture
        /// </summary>
        /// <param name="document"></param>
        /// <param name="handle"></param>
        /// <param name="selector">
        /// #id
        /// .class
        /// :input,:checkbox,:radio,:select,:button
        /// tagname
        /// [attr='value1'][attr='value2']
        /// :eq(index)
        /// :gt(index)
        /// :lt(index)
        /// parent > children
        ///  parent + children
        ///  selector selector selector
        /// </param>
        /// <returns></returns>
        public Bitmap getElementScreenCapture(HTMLDocumentClass document = null, int? handle = null, string selector = "body:eq(0)")
        {
            mshtml.IHTMLElement ele = null;
            var handleId = 0;
            mshtml.HTMLDocumentClass mydoc = null;
            var domTitle = string.Empty;
            if (document == null)
            {
                handleId = ComHelper.GetWindow(this.GetDocument()).HWND;
                mydoc = this.GetDocument();
                domTitle = mydoc.title;
            }
            else
            {
                domTitle = document.title;
                handle = handle.HasValue ? handle.Value : ComHelper.GetWindow(this.GetDocument()).HWND;
                mydoc = document;
            }

            while (!mydoc.readyState.ToString().ToLower().Equals("complete")) ;
            System.Threading.Thread.Sleep(500);

            var totalLeft = 0;
            var totalTop = 0;

            #region search target element
            bool isFrame = false;

            if (isFrame)
            {
                var frame = GetFrameByName(selector);
                ele = frame.documentElement;
                totalLeft = ((mshtml.HTMLWindow2Class)frame.parentWindow).screenLeft;
                totalTop = ((mshtml.HTMLWindow2Class)frame.parentWindow).screenTop;
            }
            else
            {
                int index = 0;
                var reg = new System.Text.RegularExpressions.Regex(@"(\S+):eq\((\d+)\)", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                var match = reg.Match(selector);
                if (reg.IsMatch(selector) && match != null)
                {
                    index = Convert.ToInt16(match.Groups[2].Value);
                    selector = reg.Replace(selector, "$1");
                }
                if (selector.StartsWith("#"))
                {
                    ele = mydoc.getElementById(selector.TrimStart('#'));
                }
                else
                {
                    var array = selector.Split('.');
                    var tagName = array[0];
                    var className = array.Length >= 2 ? array[1] : null;
                    var col = mydoc.getElementsByTagName(tagName);

                    var loop = 0;
                    foreach (IHTMLElement item in col)
                    {
                        var temClass = item.className;
                        if (className == null)
                        {
                            className = temClass;
                        }
                        if (temClass != null && temClass.Equals(className))
                        {
                            if (loop == index)
                            {
                                ele = item;
                                break;
                            }
                            else
                            {
                                loop++;
                            }
                        }
                    }
                }

                if (ele != null)
                {
                    totalLeft = ele.offsetLeft;
                    totalTop = ele.offsetTop;
                    var nele = ele.offsetParent;
                    while (nele != null)
                    {
                        totalLeft += nele.offsetLeft;
                        totalTop += nele.offsetTop;
                        nele = ele.offsetParent;
                    }
                }
            }
            #endregion

            if (ele != null)
            {
                var retBp = new Bitmap(500, 200);
                var tetGrap = Graphics.FromImage(retBp);
                var font = new Font("Microsoft Yahei", 12);
                var brush = new SolidBrush(Color.Red);

                tetGrap.DrawString("could not find the element which you want!", font, brush, 10, 10);
                tetGrap.Save();
                brush.Dispose();
                tetGrap.Dispose();
                return retBp;
            }
            else
            {
                var sourceEle = ele;
                this.SetWindowToforgroud(handleId);

                var scrollWindth = (int)ele.getAttribute("scrollWidth");
                var scrollHeight = (int)ele.getAttribute("scrollHeight");
                var clientWith = (int)ele.getAttribute("clientWidth");
                clientWith = clientWith == 0 ? ele.offsetWidth : clientWith;
                var clientHeight = (int)ele.getAttribute("clientHeight");
                clientHeight = clientHeight == 0 ? ele.offsetHeight : clientHeight;

                Bitmap map = null;
                var newMap = new Bitmap(scrollWindth, scrollHeight);
                var graphic = Graphics.FromImage(newMap);

                ele.setAttribute("scrollTop", 0);
                ele.setAttribute("scrollLeft", 0);

                var horizontalScrollCount = scrollWindth / (clientWith * 1.0);
                var horizontalIndex = (int)Math.Ceiling(horizontalScrollCount);

                var veriticalScrollCount = scrollHeight / (clientHeight * 1.0);
                var veriticalIndex = (int)Math.Ceiling(veriticalScrollCount);

                var mapX = 0;
                var mapY = 0;

                var pageTotalLeft = 0;
                var pageTotalTop = 0;

                for (int i = 0; i < horizontalIndex; i++)
                {
                    if (i == horizontalIndex - 1 && i > 0)
                    {
                        pageTotalLeft = totalLeft + (int)((i + 1 + horizontalScrollCount) * clientHeight);
                    }
                    else
                    {
                        pageTotalLeft = totalLeft;
                    }
                    mapX = (int)(i * clientWith);
                    ele.setAttribute("scrollLeft", i * clientWith);
                    for (int j = 0; j < veriticalIndex; j++)
                    {
                        mapY = (int)(j * clientHeight);
                        System.Threading.Thread.Sleep(200);
                        map = GetIECaputre(handleId, mydoc);

                        if (j == veriticalIndex - 1 && j > 0)
                        {
                            pageTotalTop = totalTop + ((int)(j + 1 - veriticalScrollCount) * clientHeight);
                        }
                        else
                        {
                            pageTotalTop = totalTop;
                        }

                        graphic.DrawImage(map, mapX, mapY, new Rectangle(pageTotalLeft, pageTotalTop, clientWith, clientHeight), GraphicsUnit.Pixel);
                    }
                }

                ele.setAttribute("scrollTop", 0);
                ele.setAttribute("scrollLeft", 0);
                map.Dispose();
                graphic.Save();
                return newMap;

            }
        }
        #endregion

    }
}
