﻿using mshtml;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
using WinX.Core;

namespace WinX.Web
{
    public partial class WebElement : Field
    {

        [XmlIgnore(), ReadOnly(true), Browsable(false)]
        public ObservableCollection<IHTMLElement> Targets
        {
            get; set;
        }
        
        public bool IsCreateed()
        {
            return Targets != null && Targets.Count > 0;
        }

        public override string ToString()
        {
            return string.Format("{0} ({1})", Name, ElementType);
        }
    }
}
