﻿using mshtml;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Xml.Serialization;
using WinX.Core;

namespace WinX.Web
{
    [ComVisible(true), Serializable()]
    public partial class WebPdfScreen : Screen
    {
        [XmlIgnore(),Browsable(false)]
        public object docObject
        {
            get; set;
        }

        public void Print()
        {
            
        }

        public void PrintAll()
        {

        }
        public void PrintWithDialog()
        {

        }

        public override bool Refresh(bool MatchAllChildern = false)
        {
            throw new NotImplementedException();
        }
    }
}
