﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WinX.Web
{
    public partial class RawPdfDocument : RawDocument
    {
    }
}
