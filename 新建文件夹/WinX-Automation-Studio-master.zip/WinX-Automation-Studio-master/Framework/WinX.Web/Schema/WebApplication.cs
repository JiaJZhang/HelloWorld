﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Xml.Serialization;
using WinX.Core;

namespace WinX.Web
{
    public partial class WebApplication : WinX.Core.Application
    {
        public WebApplication() : base()
        {

        }

        public static WebScreen WaitForAnyScreen(int timeOutInSec, bool MatchAllChildern, params WebScreen[] Screens)
        {
            try
            {
                if (Screens != null && Screens.Count() > 0)
                {
                    if (timeOutInSec <= 5)
                    {
                        timeOutInSec = 5;
                    }

                    var waithandles = new AutoResetEvent[Screens.Count() - 1];
                    var hasCoplete = false;

                    for (int i = 0; i < Screens.Count(); i++)
                    {
                        var index = i;
                        waithandles[index] = new AutoResetEvent(false);

                        ThreadPool.UnsafeQueueUserWorkItem((obj) =>
                        {
                            var evt = obj as AutoResetEvent;
                            try
                            {
                                var screen = Screens[index];
                                screen.Status = false;
                                screen.HTMLDocument = null;

                                while (!screen.IsCreated(MatchAllChildern) && !hasCoplete)
                                {
                                    System.Threading.Thread.Sleep(250);

                                } 

                            }
                            catch (Exception ex)
                            {
                                Logger.Write(ex, "[WaitForAnyScreen] : There was an error while trying to wait for screen '" + Screens[index] + "'.");
                            }
                            finally
                            {
                                evt.Set();
                            }

                        }, waithandles[index]);
                    }

                    var ind = WaitHandle.WaitAny(waithandles, TimeSpan.FromSeconds(timeOutInSec));
                    hasCoplete = true;
                    return Screens.Where(m => m.Status == true).FirstOrDefault();
                }
            }
            catch (Exception ex)
            {
                Logger.Write(ex, "[WaitForAnyScreen] : There was an error while trying to wait for screens.");
            }
            return null;
        }

        private IWebBrowser2 objBrowser = null;

        [XmlIgnore()]
        public string StartupURL
        {
            get; set;
        }

        [XmlIgnore()]
        public string Title
        {
            get
            {
                if (objBrowser != null)
                {
                    return objBrowser.LocationName;
                }
                return null;
            }
        }

        [XmlIgnore()]
        public string URL
        {
            get
            {
                if (objBrowser != null)
                {
                    return objBrowser.LocationURL;
                }
                return null;
            }
        }


        [XmlIgnore()]
        public bool Started
        {
            get
            {
                return this.objBrowser != null;
            }
        }

        public void Start(int timeOutInSec = 30, bool OpenInSameTab = false)
        {
            ShellWindows.Start(StartupURL, timeOutInSec, OpenInSameTab);
        }

        public void Refresh()
        {
            if (objBrowser != null)
            {
                objBrowser.Refresh();
            }
        }

        public void Stop()
        {
            if (objBrowser != null)
            {
                objBrowser.Stop();
            }
        }

        public string DocumentType()
        {
            if (objBrowser != null)
            {
                return objBrowser.Type;
            }
            return string.Empty;
        }

        public void Quit()
        {
            if (objBrowser != null)
            {
                objBrowser.Quit();
            }
        }


        public bool IsBusy()
        {
            if (objBrowser != null)
            {
                return objBrowser.Busy;
            }
            return false;
        }

        public void Show()
        {
            if (objBrowser != null)
            {
                objBrowser.Visible = true;
            }
        }

        public void Hide()
        {
            if (objBrowser != null)
            {
                objBrowser.Visible = false;
            }
        }

        public void Minimize()
        {
            if (objBrowser != null)
            {
                WinX.Core.Win16Helper.ShowWindow(objBrowser.HWND, WinX.Core.Win16Helper.SW_SHOWMINIMIZED);
            }
        }

        public void Restore()
        {
            if (objBrowser != null)
            {
                WinX.Core.Win16Helper.ShowWindow(objBrowser.HWND, WinX.Core.Win16Helper.SW_SHOWNORMAL);
            }
        }

        public void Maximize()
        {
            if (objBrowser != null)
            {
                WinX.Core.Win16Helper.ShowWindow(objBrowser.HWND, WinX.Core.Win16Helper.SW_SHOWMAXIMIZED);
            }
        }

        public void ExecuteCommand(WinX.Web.OLECMDID cmd, OLECMDEXECOPT obj)
        {
            if (objBrowser != null)
            {
                objBrowser.ExecWB(cmd, obj, null, null);
            }
        }
    }
}
