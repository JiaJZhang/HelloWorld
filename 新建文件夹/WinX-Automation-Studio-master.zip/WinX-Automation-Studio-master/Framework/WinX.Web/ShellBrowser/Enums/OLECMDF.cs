﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WinX.Web
{
    public enum OLECMDF
    {
        OLECMDF_DEFHIDEONCTXTMENU = 0x20,
        OLECMDF_ENABLED = 2,
        OLECMDF_INVISIBLE = 0x10,
        OLECMDF_LATCHED = 4,
        OLECMDF_NINCHED = 8,
        OLECMDF_SUPPORTED = 1
    }
}
