﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WinX.Web
{
    public enum tagREADYSTATE
    {
        READYSTATE_UNINITIALIZED = 0,
        READYSTATE_LOADING = 1,
        READYSTATE_LOADED = 2,
        READYSTATE_INTERACTIVE = 3,
        READYSTATE_COMPLETE = 4
    }
}
