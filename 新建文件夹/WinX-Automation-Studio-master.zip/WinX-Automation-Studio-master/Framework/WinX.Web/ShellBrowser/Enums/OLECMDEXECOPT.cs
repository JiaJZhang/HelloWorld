﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WinX.Web
{
    public enum OLECMDEXECOPT
    {
        OLECMDEXECOPT_DODEFAULT,
        OLECMDEXECOPT_PROMPTUSER,
        OLECMDEXECOPT_DONTPROMPTUSER,
        OLECMDEXECOPT_SHOWHELP
    }
}
