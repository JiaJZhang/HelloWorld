﻿using mshtml;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

namespace WinX.Web
{
    public partial class ShellWindows : IDisposable
    {
        public delegate void RawWebDocumentHandle(RawWebDocument raw);

        public static event RawWebDocumentHandle PageCreated;
        public static event RawWebDocumentHandle PageDestroyed;
        private static List<RawWebDocument> browserWindlows = new List<RawWebDocument>();


        private static void OnPageCreated(RawWebDocument raw)
        {
            if (PageCreated != null)
            {
                PageCreated(raw);
            }
        }

        private static void OnPageDestroyed(RawWebDocument raw)
        {
            if (PageDestroyed != null)
            {
                PageDestroyed(raw);
            }
        }

        public ShellWindows()
        {
            ShellWindows.Refresh();
        }

        private static Thread refreshThread;
        private static bool stopEvents = false;

        public static void TurnOnEvents()
        {
            try
            {
                WinX.Core.Logger.Write("Web event listener has been turned on.");
                stopEvents = false;
                if (refreshThread == null || !refreshThread.IsAlive)
                {
                    refreshThread = new Thread((obj) =>
                       {
                           try
                           {
                               while (!stopEvents)
                               {
                                   ShellWindows.Refresh();
                                   System.Threading.Thread.Sleep(500);
                               }
                               browserWindlows.Clear();
                               WinX.Core.Logger.Write("Web event listener has been turned off.");

                           }
                           catch (Exception ex)
                           {
                               WinX.Core.Logger.Write(ex, "An exception occured while trying to enumerate running browser instances.");
                           }
                       });
                    refreshThread.IsBackground = true;
                    refreshThread.Start();
                }
            }
            catch(Exception ex)
            {
                WinX.Core.Logger.Write(ex, "There was an exception while trying to turn on WebEvents.");
            }
        }

        public static void TurnOffEvents()
        {
            WinX.Core.Logger.Write("Attempting to turn off Web event listener");
            stopEvents = true;
        } 

        private static void Refresh()
        {
            var tmpBrowsers = GetRunningBrowserWindows();

            try
            {
                lock (browserWindlows)
                {
                    try
                    {
                        foreach (var browser in tmpBrowsers)
                        {
                            try
                            {
                                dynamic _browser = browser;
                                var existingBrowserWindow = browserWindlows.Where(m => m.Handle == _browser.Handle).FirstOrDefault();

                                var matchedBrowsers = browserWindlows.Where(m => m.Document.Equals(_browser.Document));

                                if (matchedBrowsers == null && matchedBrowsers.Count() < 1)
                                {
                                    if (existingBrowserWindow != null)
                                    {
                                        if (_browser.Document.readyState.Equals("complete"))
                                        {
                                            try
                                            {
                                                Marshal.ReleaseComObject(existingBrowserWindow.Document);
                                                existingBrowserWindow.Document = null;
                                            }
                                            catch (Exception ex)
                                            {

                                            }

                                            existingBrowserWindow.Document = _browser.Document;
                                            existingBrowserWindow.Url = _browser.Document.url;
                                            existingBrowserWindow.Title = _browser.Document.title;
                                            OnPageCreated(existingBrowserWindow);
                                        }
                                        else if (_browser.Document.readyState.Equals("complete"))
                                        {
                                            browserWindlows.Add(_browser);
                                            OnPageCreated(_browser);
                                        }
                                    }
                                }

                                if (existingBrowserWindow != null)
                                {
                                    if (browser.Frames != null && browser.Frames.Count > 0)
                                    {
                                        if (browser.Frames.Count == existingBrowserWindow.Frames.Count)
                                        {
                                            for (int i = 0; i < browser.Frames.Count; i++)
                                            {
                                                if (browser.Frames[i].Document.Equals(existingBrowserWindow.Frames[i].Document))
                                                {
                                                    try
                                                    {
                                                        Marshal.ReleaseComObject(existingBrowserWindow.Frames[i].Document);
                                                        existingBrowserWindow.Frames[i].Document = null;
                                                    }
                                                    catch (Exception ex)
                                                    {

                                                    }

                                                    existingBrowserWindow.Frames[i].Document = browser.Frames[i].Document;
                                                    OnPageCreated(browser.Frames[i]);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                WinX.Core.Logger.Write(ex, "There was an error while trying to add new browser object to the brower list.");
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        WinX.Core.Logger.Write(ex, "There was an error while trying to add new browser objects to the brower objects to the brower list.");
                    }


                    try
                    {
                        var tmpWindows = new List<RawWebDocument>(browserWindlows);
                        foreach (var browser in tmpWindows)
                        {
                            try
                            {
                                dynamic _browser = browser;
                                if (tmpBrowsers.Where(m => m.Handle == browser.Handle).FirstOrDefault() == null)
                                {
                                    try
                                    {
                                        browserWindlows.Remove(browser);
                                        Marshal.ReleaseComObject(browser.Document);
                                        browser.Document = null;
                                    }
                                    catch (Exception ex)
                                    {

                                    }
                                    OnPageDestroyed(browser);
                                }
                            }
                            catch (Exception ex)
                            {
                                WinX.Core.Logger.Write(ex, "An exception while trying to remove disposed browser objects from the brower from the brower list.");
                            }
                        }
                        tmpWindows.Clear();
                        tmpWindows = null;
                    }
                    catch (Exception ex)
                    {
                        WinX.Core.Logger.Write(ex, "An error while trying toremove disposed browser objects from the brower from the brower list.");
                    }
                }
            }
            catch (Exception ex)
            {
                WinX.Core.Logger.Write(ex, "An error occured while trying to refresh current browser instances.");
            }
            finally
            {
                WinX.Core.Profiler.CheckIn("Clearing temp browsers list");
                tmpBrowsers.Clear();
                tmpBrowsers = null;
            }
        }

        public static List<RawWebDocument> GetRunningBrowserWindows()
        {
            var tmpBrowsers = new List<RawWebDocument>();

            try
            {
                var dialog = IntPtr.Zero;
                while (InlineAssignHelper(ref dialog, FindWindowEx(IntPtr.Zero, dialog, "Internet Explorer_TridentDlgFrame", IntPtr.Zero)) != IntPtr.Zero)
                {
                    try
                    {
                        var internetExplorerServer = IntPtr.Zero;

                        while (InlineAssignHelper(ref internetExplorerServer, FindWindowEx(IntPtr.Zero, dialog, "Internet Explorer_Server", IntPtr.Zero)) != IntPtr.Zero)
                        {
                            try
                            {
                                var htmlDoc = GetIEDocumentFromHwnd(internetExplorerServer.ToInt32());

                                if (htmlDoc != null)
                                {
                                    var state = htmlDoc.readyState;

                                    if (!state.Equals("uninitialized") && !state.Equals("loading"))
                                    {
                                        tmpBrowsers.Add(new RawWebDocument(htmlDoc, internetExplorerServer.ToInt32(), dialog.ToInt32()));
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                WinX.Core.Logger.Write(ex, "An exception has occured at 'internetExplorerServer' control,HTML Page Object could not be accessed.");
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        WinX.Core.Logger.Write(ex, "An exception has occured at 'Internet Explorer_TridentDlgFrame' control,HTML Page Object could not be accessed.");
                    }
                }

                var IEFrame = IntPtr.Zero;

                while (InlineAssignHelper(ref IEFrame, FindWindowEx(IntPtr.Zero, IEFrame, "IEFrame", IntPtr.Zero)) != IntPtr.Zero)
                {
                    try
                    {
                        if(!IsIWHScannerApp(IEFrame))
                        {
                            var frameTab = IntPtr.Zero;

                            while (InlineAssignHelper(ref frameTab, FindWindowEx(IEFrame, frameTab, "Frame Tab", IntPtr.Zero)) != IntPtr.Zero)
                            {
                                try
                                {
                                    var tabWindowClass = IntPtr.Zero;
                                    while (InlineAssignHelper(ref tabWindowClass, FindWindowEx(frameTab, tabWindowClass, "TabWindowClass", IntPtr.Zero)) != IntPtr.Zero)
                                    {
                                        try
                                        {
                                            var shellDocObjectView = IntPtr.Zero;
                                            while (InlineAssignHelper(ref shellDocObjectView, FindWindowEx(tabWindowClass, shellDocObjectView, "Shell DocObject View", IntPtr.Zero)) != IntPtr.Zero)
                                            {
                                                try
                                                {
                                                    var internetExplorerServer = IntPtr.Zero;
                                                    while (InlineAssignHelper(ref internetExplorerServer, FindWindowEx(shellDocObjectView, internetExplorerServer, "Internet Explorer_Server", IntPtr.Zero)) != IntPtr.Zero)
                                                    {
                                                        try
                                                        {
                                                            var htmlDoc = GetIEDocumentFromHwnd(internetExplorerServer.ToInt32());
                                                            if (htmlDoc != null)
                                                            {
                                                                var state = htmlDoc.readyState;
                                                                if (!state.Equals("uninitialized") && !state.Equals("loading"))
                                                                {
                                                                    tmpBrowsers.Add(new RawWebDocument(htmlDoc, internetExplorerServer.ToInt32(), IEFrame.ToInt32()));
                                                                }
                                                            }
                                                        }
                                                        catch(Exception ex)
                                                        {
                                                            WinX.Core.Logger.Write(ex, "An exception has occured at 'internetExplorerServer' control,HTML Page Object could not be accessed.");
                                                        }
                                                    }
                                                }
                                                catch (Exception ex)
                                                {
                                                    WinX.Core.Logger.Write(ex, "An exception has occured at 'shellDocObjectView' control,HTML Page Object could not be accessed.");
                                                }
                                            }
                                        }
                                        catch (Exception ex)
                                        {
                                            WinX.Core.Logger.Write(ex, "An exception has occured at 'tableWindowClass' control,HTML Page Object could not be accessed.");
                                        }
                                    }
                                }
                                catch (Exception ex)
                                {
                                    WinX.Core.Logger.Write(ex, "An exception has occured at 'frameTab' control,HTML Page Object could not be accessed.");
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        WinX.Core.Logger.Write(ex, "An exception has occured at 'IEFrame' control,HTML Page Object could not be accessed.");
                    }
                }
            }
            catch (Exception ex)
            {
                WinX.Core.Logger.Write(ex, "An exception has occured while trying to enumerate browser window [GetCurrentBrowerWindows].");
            }
            return tmpBrowsers;
        }
        
        public static HTMLDocumentClass GetIEDocumentFromHwnd(int ieServerHwnd)
        {
            HTMLDocumentClass htmlDocument = null;
            UIntPtr lResult = UIntPtr.Zero;

            try
            {
                var lMsg = RegisterWindowMessage("WM_HTML_GETOBJECT");
                SendMessageTimeout(ieServerHwnd, lMsg, UIntPtr.Zero, UIntPtr.Zero, SendMessageTimeoutFlags.SMTO_ABORTIFHUNG, 500, ref lResult);

                if(lResult!= UIntPtr.Zero)
                {
                    try
                    {
                        htmlDocument = ObjectFromLresult(lResult, typeof(HTMLDocument).GUID, IntPtr.Zero) as HTMLDocumentClass;

                        if(htmlDocument == null)
                        {
                            WinX.Core.Logger.Write("Unable to cast the COM object to HTML document.");
                        }

                    }
                    catch(Exception ex)
                    {
                        WinX.Core.Logger.Write("There was an error while trying to get access to HTML document.");
                    }
                }
            }
            catch(Exception ex)
            {
                WinX.Core.Logger.Write("There was an error while trying to get access to HTML document.");
            }
            return htmlDocument;

        }
        
        [DllImport("oleacc.dll", PreserveSig = false)]
        [return: MarshalAs(UnmanagedType.Interface)]
        private static extern object ObjectFromLresult(UIntPtr lResult, [MarshalAs(UnmanagedType.LPStruct)] Guid refiid, IntPtr wParam);


        [DllImport("user32.dll", SetLastError = true, CharSet = CharSet.Auto)]
        private static extern IntPtr SendMessageTimeout(int hwnd, uint Msg, UIntPtr wParam, UIntPtr lParam, SendMessageTimeoutFlags fuFlags, uint uTimeout, ref UIntPtr lpdwResult);


        [DllImport("user32.dll",SetLastError = true,CharSet =CharSet.Auto)]
        private static extern uint RegisterWindowMessage(string lpString);


        [DllImport("user32.dll")]
        private static extern IntPtr FindWindowEx(IntPtr parentHandle, IntPtr childAfter, string className, IntPtr windowTitle);

        public static bool IsIWHScannerApp(IntPtr ieFrameHwnd)
        {
            var text = WinX.Core.Win32Helper.GetWindowText(ieFrameHwnd);
            if (text.Equals("Image Warehouse"))
            {
                return WinX.Core.Win32Helper.FindChildDialog.ByClass(ieFrameHwnd, "Internet Explorer_TridentDlgFrame") != IntPtr.Zero;
            }
            return false;
        }

        private static T InlineAssignHelper<T>(ref T target, T value)
        {
            target = value;
            return value;
        }

        public static void Start(string url,int timeoutInseconds = 30,bool OpenInSameTab = false)
        {
            try
            {
                var proc = new System.Diagnostics.Process();
                proc.StartInfo.FileName = OpenInSameTab ? "explorer.exe" : "iexplore.exe";
                proc.StartInfo.Arguments = url;
                proc.Start();
            }
            catch(Exception ex)
            {
                WinX.Core.Logger.Write(ex, "There was an error while trying to starty" + url);
            }
        }

        private bool disposedValue;
        

        protected virtual void Dispose(bool disposing)
        {
            if(!disposedValue)
            {
                if(disposing)
                {
                    try
                    {
                        if(refreshThread != null)
                        {
                            refreshThread.Abort();
                        }
                    }
                    catch(Exception ex)
                    {

                    }
                }
            }
            this.disposedValue = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
    [Flags]
    public enum SendMessageTimeoutFlags : uint
    {
        SMTO_NORMAL = 0x0,
        SMTO_BLOCK = 0x1,
        SMTO_ABORTIFHUNG = 0x2,
        SMTO_NOTIMEOUTIFNOTHUNG = 0x8,
        SMTO_ERRORONEXIT = 0x20
    }


}
