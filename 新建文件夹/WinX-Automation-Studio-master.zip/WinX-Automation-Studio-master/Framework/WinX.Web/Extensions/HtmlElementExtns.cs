﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using mshtml;
using System.ComponentModel;

namespace WinX.Web
{
    public static partial class HtmlElementExtns
    {
        public static void Highlight(this IHTMLElement htmlEle)
        {
            var bgWorker = new BackgroundWorker();

            bgWorker.DoWork += (s1, e1) =>
            {
                try
                {
                    var htmlEle2 = e1.Argument as IHTMLElement2;
                    var rect = htmlEle2.getBoundingClientRect();

                    var htmlDiv = "<div id=\"WinXMask\" style=\"top:" + rect.top +
                                "px;left:" + rect.left +
                                "px;width:" + (rect.right - rect.left) +
                                "px;height:" + (rect.bottom - rect.top) +
                                "px;position:fixed;z-index:1022;background-color:red;filter:alpha(opacity=40);font-size:5pt;\"/>";

                    //var htmlEle3 = e1.Argument as IHTMLElement;

                    htmlEle.parentElement.insertAdjacentHTML("beforeBegin", htmlDiv);
                    var doc = htmlEle.parentElement.parentElement.document as HTMLDocumentClass;

                    if (doc != null)
                    {
                        var winxMask = doc.getElementById("WinXMask");
                        if (winxMask != null)
                        {
                            System.Threading.Thread.Sleep(250);
                            winxMask.style.visibility = "collapse";
                            System.Threading.Thread.Sleep(250);
                            winxMask.style.visibility = "visible";
                            System.Threading.Thread.Sleep(250);
                            winxMask.style.visibility = "collapse";
                            System.Threading.Thread.Sleep(250);
                            winxMask.style.visibility = "visible";
                            System.Threading.Thread.Sleep(250);
                            winxMask.style.visibility = "collapse";
                            System.Threading.Thread.Sleep(250);
                            winxMask.style.visibility = "visible";
                            System.Threading.Thread.Sleep(250);

                            var winxMask2 = winxMask as IHTMLDOMNode;
                            winxMask2.parentNode.removeChild(winxMask2);
                        }
                    }
                }
                catch (Exception ex)
                {

                }
            };
            bgWorker.RunWorkerAsync(htmlEle);
        }

        public static HTMLSelectElement WaitForLoad(this HTMLSelectElement htmlSelEle, int Timeout = 30)
        {
            var tryFunc = new WinX.Core.TryUnillTimeOut(TimeSpan.FromSeconds(Timeout));
            var retHTMLDoc = tryFunc.Try(() =>
            {

                if (htmlSelEle.readyState.Equals("complete"))
                {
                    return htmlSelEle;
                }
                return null;

            });
            return retHTMLDoc;
        }

        public static HTMLSelectElement WaitForEnable(this HTMLSelectElement htmlSelEle, int Timeout = 30)
        {
            var tryFunc = new WinX.Core.TryUnillTimeOut(TimeSpan.FromSeconds(Timeout));
            var retHTMLDoc = tryFunc.Try(() =>
            {

                if (htmlSelEle.isDisabled)
                {
                    return htmlSelEle;
                }
                return null;

            });
            return retHTMLDoc;
        }

        //public static IHTMLElement2 WaitForEnable(this IHTMLElement2 htmlSelEle, int Timeout = 30)
        //{
        //    var tryFunc = new WinX.Core.TryUnillTimeOut(TimeSpan.FromSeconds(Timeout));
        //    var retHTMLDoc = tryFunc.Try(() => {

        //        if (htmlSelEle.isDisabled)
        //        {
        //            return htmlSelEle;
        //        }
        //        return null;

        //    });
        //    return retHTMLDoc;
        //}

        public static IList<string> GetOptionsValue(this HTMLSelectElement ele)
        {
            var retStrList = new List<string>();
            var eleColl = ele.all as IHTMLElementCollection;
            foreach (var iele in eleColl)
            {
                var op = iele as IHTMLOptionElement;
                retStrList.Add(op.value);
            }
            return retStrList.ToArray();
        }

        public static void SelectByText(this HTMLSelectElementClass ele, string textToSelect)
        {
            var retStrList = new List<string>();
            var eleColl = ele.all as IHTMLElementCollection;

            foreach (IHTMLElement iele in eleColl)
            {
                var op = iele as IHTMLOptionElement;
                if (op.text != null && op.text.Equals(textToSelect))
                {
                    op.selected = true;
                }
            }
        }

        public static void SelectByText(this HTMLSelectElement ele, string textToSelect)
        {
            var retStrList = new List<string>();
            var eleColl = ele.all as IHTMLElementCollection;

            foreach (IHTMLElement iele in eleColl)
            {
                var op = iele as IHTMLOptionElement;
                if (op.text != null && op.text.Equals(textToSelect))
                {
                    op.selected = true;
                }
            }
        }

        public static string SelectedText(this HTMLSelectElementClass ele)
        {
            var retStrList = new List<string>();
            var eleColl = ele.all as IHTMLAreasCollection;
            foreach (var iele in eleColl)
            {
                var op = iele as IHTMLOptionElement;
                if (op.selected)
                {
                    return op.text;
                }
            }
            return string.Empty;
        }


        public static void SelectByValue(this HTMLSelectElementClass ele, string textToSelect)
        {
            var retStrList = new List<string>();
            var eleColl = ele.all as IHTMLElementCollection;

            foreach (IHTMLElement iele in eleColl)
            {
                var op = iele as IHTMLOptionElement;
                if (op.text != null && op.value.Equals(textToSelect))
                {
                    op.selected = true;
                }
            }
        }

        public static void SelectAll(this HTMLSelectElementClass ele)
        {
            var retStrList = new List<string>();
            var eleColl = ele.all as IHTMLElementCollection;

            foreach (IHTMLElement iele in eleColl)
            {
                var op = iele as IHTMLOptionElement;
                op.selected = true;
            }
        }

        public static string GetSelectedValue(this HTMLSelectElementClass ele)
        {
            var retStrList = new List<string>();
            var eleColl = ele.all as IHTMLElementCollection;

            foreach (IHTMLElement iele in eleColl)
            {
                var op = iele as IHTMLOptionElement;
                if (op.value != null && op.selected)
                {
                    return op.value;
                }
            }
            return string.Empty;
        }


        public static string GetSelectedText(this HTMLSelectElementClass ele)
        {
            var retStrList = new List<string>();
            var eleColl = ele.all as IHTMLElementCollection;

            foreach(IHTMLElement iele in eleColl)
            {
                var op = iele as IHTMLOptionElement;
                if(op.text != null && op.selected)
                {
                    return op.text;
                }
            }
            return string.Empty;
        }

        public static string GetSelectedIndex(this HTMLSelectElementClass ele)
        {
            var retStrList = new List<string>();
            var eleColl = ele.all as IHTMLElementCollection;

            foreach (IHTMLElement iele in eleColl)
            {
                var op = iele as IHTMLOptionElement;
                if (op.text != null && op.selected)
                {
                    return op.index.ToString();
                }
            }
            return string.Empty;
        }
    }
}
