﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using mshtml;
using System.Threading;
using System.Runtime.InteropServices;

namespace WinX.Web
{

    public delegate void HtmlEvent(IHTMLEventObj obj);

    [ComVisible(true)]
    [ClassInterface(ClassInterfaceType.AutoDispatch)]
    public partial class HTMLEventHandler
    {
        private HTMLDocumentClass htmlDocument;
        public event HtmlEvent eventHander;
        ManualResetEvent mEvent;

        public HTMLEventHandler(HTMLDocumentClass doc)
        {
            this.htmlDocument = doc;
        }

        [DispId(0)]
        [STAThread()]
        public void FireEvent()
        {
            mEvent = new ManualResetEvent(false);
            var parentWin = new Thread(new ThreadStart(WindowHandler));
            parentWin.SetApartmentState(ApartmentState.STA);
            parentWin.Start();
            mEvent.WaitOne();
        }

        private void WindowHandler()
        {
            if (eventHander != null)
            {
                eventHander(this.htmlDocument.parentWindow.@event);
            }
            mEvent.Set();
        }
    }
}
