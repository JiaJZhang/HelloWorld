﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using mshtml;
using System.Runtime.InteropServices;

namespace WinX.Web
{
    [ComVisible(true)]
    public partial class HTMLDocumentEventHelper
    {
        private HTMLDocumentClass document;

        public HTMLDocumentEventHelper(HTMLDocumentClass doc)
        {
            document = doc;
        }

        public event HtmlEvent MouseOver
        {
            add
            {
                var dispDoc = this.document as DispHTMLDocument;
                var existingHandler = dispDoc.onmouseover;
                HTMLEventHandler handler = existingHandler is HTMLEventHandler ? existingHandler as HTMLEventHandler : new HTMLEventHandler(this.document);

                dispDoc.onmouseover = handler;
                handler.eventHander += value;
            }
            remove
            {
                var dispDoc = this.document as DispHTMLDocument;
                var existingHandler = dispDoc.onmouseover;

                var handler = existingHandler as HTMLEventHandler;
                if (handler != null)
                {
                    handler.eventHander -= value;
                }
            }
        }

        public void OnMouseOver()
        {
            var dispDoc = this.document as DispHTMLDocument;
            var existingHandler = dispDoc.onmouseover;

            var handler = existingHandler as HTMLEventHandler;
            if (handler != null)
            {
                handler.FireEvent();
            }
        }

        public event HtmlEvent ContexMenu
        {
            add
            {
                var dispDoc = this.document as DispHTMLDocument;
                var existingHandler = dispDoc.oncontextmenu;
                HTMLEventHandler handler = existingHandler is HTMLEventHandler ? existingHandler as HTMLEventHandler : new HTMLEventHandler(this.document);

                dispDoc.oncontextmenu = handler;
                handler.eventHander += value;
            }
            remove
            {
                var dispDoc = this.document as DispHTMLDocument;
                var existingHandler = dispDoc.oncontextmenu;

                var handler = existingHandler as HTMLEventHandler;
                if (handler != null)
                {
                    handler.eventHander -= value;
                }
            }
        }

        public void OnContexMenu()
        {
            var dispDoc = this.document as DispHTMLDocument;
            var existingHandler = dispDoc.oncontextmenu;

            var handler = existingHandler as HTMLEventHandler;
            if (handler != null)
            {
                handler.FireEvent();
            }
        }

        public event HtmlEvent Click
        {
            add
            {
                var dispDoc = this.document as DispHTMLDocument;
                var existingHandler = dispDoc.onclick;
                HTMLEventHandler handler = existingHandler is HTMLEventHandler ? existingHandler as HTMLEventHandler : new HTMLEventHandler(this.document);

                dispDoc.onmouseover = handler;
                handler.eventHander += value;
            }
            remove
            {
                var dispDoc = this.document as DispHTMLDocument;
                var existingHandler = dispDoc.onclick;

                var handler = existingHandler as HTMLEventHandler;
                if (handler != null)
                {
                    handler.eventHander -= value;
                }
            }
        }

        public void OnClick()
        {
            var dispDoc = this.document as DispHTMLDocument;
            var existingHandler = dispDoc.onclick;

            var handler = existingHandler as HTMLEventHandler;
            if (handler != null)
            {
                handler.FireEvent();
            }
        }

        public event HtmlEvent DoubleClick
        {
            add
            {
                var dispDoc = this.document as DispHTMLDocument;
                var existingHandler = dispDoc.ondblclick;
                HTMLEventHandler handler = existingHandler is HTMLEventHandler ? existingHandler as HTMLEventHandler : new HTMLEventHandler(this.document);

                dispDoc.onmouseover = handler;
                handler.eventHander += value;
            }
            remove
            {
                var dispDoc = this.document as DispHTMLDocument;
                var existingHandler = dispDoc.ondblclick;

                var handler = existingHandler as HTMLEventHandler;
                if (handler != null)
                {
                    handler.eventHander -= value;
                }
            }
        }

        public void OnDoubleClick()
        {
            var dispDoc = this.document as DispHTMLDocument;
            var existingHandler = dispDoc.ondblclick;

            var handler = existingHandler as HTMLEventHandler;
            if (handler != null)
            {
                handler.FireEvent();
            }
        }
    }
}
