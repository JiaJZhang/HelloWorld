﻿using mshtml;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

namespace WinX.Web
{
    public delegate void DHTMLEvent(IHTMLEventObj obj);


    [ComVisible(true)]
    [ClassInterface(ClassInterfaceType.AutoDispatch)]
    public partial class DomEvent
    {
        private ManualResetEvent mEvent;
        public DHTMLEvent Handler;
        private IHTMLDocument2 document;

        public DomEvent(IHTMLDocument2 doc)
        {
            document = doc;
        }

        [STAThread]
        [DispId(0)]
        public void Call()
        {
            mEvent = new ManualResetEvent(false);
            var parentWin = new Thread(new ThreadStart(WindowHander));
            parentWin.SetApartmentState(ApartmentState.STA);
            parentWin.Start();
            mEvent.WaitOne();
        }

        public void WindowHander()
        {
            Handler(document.parentWindow.@event);
            mEvent.Set();
        }
    }
}
