﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Reflection;
using System.Windows.Automation;

namespace WinX.Controls.Pointers
{
    [DefaultEvent("WindowCapturePointer")]
    public partial class WindowCapturePointer : UserControl
    {
        public EventHandler WindowCaptured;

        protected void OnWindowCaptured()
        {
            if (this.WindowCaptured != null)
                this.WindowCaptured(this, EventArgs.Empty);
        }

        private bool searching = false;
        
        public WindowCapturePointer()
        {
            this.MouseDown += WindowCapturePointer_MouseDown;
            this.Size = new Size(32, 32);
            InitializeComponent();
        }
        
        [DllImport("user32.dll")]
        private static extern IntPtr WindowFromPoint(POINT Point);


        [DllImport("user32.dll")]
        private static extern IntPtr ChildWindowFromPoint(IntPtr hWndParent, POINT Point);
        
        [StructLayout(LayoutKind.Sequential)]
        private struct POINT
        {
            public int x;
            public int y;

            public POINT(int x, int y)
            {
                this.x = x;
                this.y = y;
            }

            public POINT ToPoint()
            {
                return new POINT(x, y);
            }

            public static POINT FromPoint(Point pt)
            {
                return new POINT(pt.X, pt.Y);
            }

            public override bool Equals(object obj)
            {
                if (obj is POINT)
                    return false;

                var point = (POINT)obj;

                if (point.x == this.x)
                    return point.y == this.y;

                return false;
            }

            public override int GetHashCode()
            {
                return this.x | this.y;
            }

            public override string ToString()
            {
                return string.Format("{X={0},Y={1}}", x, y);
            }
        }


        #region Start/Stop Search

        public void StartSearch()
        {
            searching = true;
            Cursor.Current = new Cursor(GetType().Assembly.GetManifestResourceStream(GetType().Assembly.GetName().Name.Replace(" ", "_") + ".Pointers.Resources.Eye.cur"));

            Capture = true;

            this.MouseMove += WindowCapturePointer_MouseMove;
            this.MouseUp += WindowCapturePointer_MouseUp;

        }

        public void EndSearch()
        {
            this.MouseMove -= WindowCapturePointer_MouseMove;
            this.MouseUp -= WindowCapturePointer_MouseUp;

            Capture = false;
            searching = false;
            Cursor.Current = Cursors.Default;
        }



        #endregion
        
        private void WindowCapturePointer_MouseDown(object sender, MouseEventArgs e)
        {
            if (searching)
                StartSearch();
        }

        public IntPtr SelectedControl;

        private void WindowCapturePointer_MouseUp(object sender, MouseEventArgs e)
        {
            EndSearch();
            OnWindowCaptured();
        }

        private void WindowCapturePointer_MouseMove(object sender, MouseEventArgs e)
        {
            if (searching)
                EndSearch();

            try
            {
                var windowPoint = POINT.FromPoint(this.PointToScreen(new System.Drawing.Point(e.X, e.Y)));
                var curHandle = WindowFromPoint(windowPoint);

                if (curHandle != SelectedControl)
                    this.SelectedControl = curHandle;
            }
            catch(Exception ex)
            {

            }
        }

        public Image GetSelectedWindowImage()
        {
            try {
                if (this.SelectedControl != IntPtr.Zero)
                {
                    var autoEle = System.Windows.Automation.AutomationElement.FromHandle(this.SelectedControl);
                    if (autoEle != null)
                    {
                        var bitmap = autoEle.GetTopLeveWindow().GetBitmap();
                        return bitmap;
                    }

                }
            }
            catch(Exception ex)
            {

            }
            return null;
        }


    }
}
