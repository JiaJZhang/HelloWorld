﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;

namespace WinX.Controls
{
    public partial class SelectionCanvas : Canvas
    {
        public EventHandler Selection;

        protected void OnSelection()
        {
            if (this.Selection != null)
                this.Selection(this, EventArgs.Empty);
        }


        private System.Windows.Shapes.Rectangle rectangle = new System.Windows.Shapes.Rectangle();
        private Storyboard animBord = new Storyboard();

        private System.Windows.Point startDrag;
        private BitmapImage sourceImage;
        
        private ScaleTransform scaleTransform = new ScaleTransform();
        private const double scaleRate = 1.1f;


        public SelectionCanvas()
        {
            this.RenderTransform = scaleTransform;
            this.Background = new SolidColorBrush(Colors.White);

            rectangle.Name = "rectangle";
            rectangle.Fill = new SolidColorBrush(Colors.Lime) { Opacity = 0.2f };
            rectangle.StrokeDashArray.Add(5);
            rectangle.Stroke = new SolidColorBrush(Colors.Yellow);
            rectangle.Visibility = Visibility.Hidden;
            rectangle.StrokeDashOffset = 0;
            rectangle.StrokeThickness = 1;
            rectangle.RadiusX = 0;
            rectangle.RadiusY = 0;
            rectangle.Width = 100;
            rectangle.Height = 100;

            this.Children.Add(rectangle);

            Canvas.SetLeft(rectangle, 0);
            Canvas.SetTop(rectangle, 0);

            var myDoubleAnimationUsingKeyFrames = new DoubleAnimationUsingKeyFrames();
            myDoubleAnimationUsingKeyFrames.RepeatBehavior = RepeatBehavior.Forever;
            myDoubleAnimationUsingKeyFrames.KeyFrames.Add(new SplineDoubleKeyFrame(0, KeyTime.FromTimeSpan(TimeSpan.FromSeconds(0))));
            myDoubleAnimationUsingKeyFrames.KeyFrames.Add(new SplineDoubleKeyFrame(10, KeyTime.FromTimeSpan(TimeSpan.FromSeconds(0.5))));

            animBord.Children.Add(myDoubleAnimationUsingKeyFrames);

            Storyboard.SetTarget(myDoubleAnimationUsingKeyFrames, rectangle);
            Storyboard.SetTargetProperty(myDoubleAnimationUsingKeyFrames, new PropertyPath("(Shape.StrokeDashOffset)"));
            
        }


        //private void SelectionCanvas_MouseWheel(object sender, System.Windows.Forms.MouseEventArgs e)
        //{
        //    if(e.Delta > 0)
        //    {
        //        scaleTransform.ScaleX *= scaleRate;
        //        scaleTransform.ScaleY *= scaleRate;
        //    }
        //    else
        //    {

        //        scaleTransform.ScaleX /= scaleRate;
        //        scaleTransform.ScaleY /= scaleRate;
        //    }
        //}


        public BitmapImage SourceImage
        {
            get
            {
                return sourceImage;
            }
            set
            {
                sourceImage = value;

                var brush = new ImageBrush();
                brush.ImageSource = this.sourceImage;
                brush.Stretch = Stretch.None;
                this.Background = brush;
                this.Height = this.sourceImage.Height;
                this.Width = this.sourceImage.Width;
                Canvas.SetZIndex(rectangle, this.Children.Count + 1);
            }

        }

        public CroppedBitmap SelectedImage
        {
            get
            {
                try
                {
                    if (startDrag.X > 0 && startDrag.Y > 0 && rectangle.Height < this.sourceImage.Height && rectangle.Width < sourceImage.Width)
                    {
                        return new CroppedBitmap(this.sourceImage, new Int32Rect()
                        {
                            X = Convert.ToInt32(startDrag.X),
                            Y = Convert.ToInt32(startDrag.Y),
                            Height = Convert.ToInt32(rectangle.Height),
                            Width = Convert.ToInt32(rectangle.Width)
                        });
                    }
                }
                catch (Exception ex)
                {

                }

                return null;
            }
        }

        public void CreateSelection(Rectangle rect)
        {
            rectangle.RenderTransform = new TranslateTransform(rect.X, rect.Y);
            rectangle.Width = rect.Width;
            rectangle.Height = rect.Height;
            animBord.Stop(rectangle);
        }

        public void ClearSelection()
        {
            rectangle.RenderTransform = new TranslateTransform(0, 0);
            rectangle.Width = 0;
            rectangle.Height = 0;
            animBord.Stop(rectangle);
        }


    }
}
