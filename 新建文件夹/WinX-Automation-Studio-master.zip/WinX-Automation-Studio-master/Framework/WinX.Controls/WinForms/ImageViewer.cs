﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WinX.Controls.WinForms
{
    public partial class ImageViewer : PictureBox
    {
        public delegate void SelectionHandle(Image image, Rectangle rect);
        public event SelectionHandle Selection;

        private void OnSelection(Image image, Rectangle rect)
        {
            if (this.Selection != null)
            {
                this.Selection(image,rect);
            }
        }


        #region ImageCropping

        private int cropX;
        private int cropY;
        private int cropWidth;
        private int cropHeight;

        private int oCropX;
        private int oCropY;
        private Bitmap cropBitmap;

        private SolidBrush redBrush = new SolidBrush(Color.FromArgb(75, 255, 69, 0));
        private Pen redPen = new Pen(Color.FromArgb(75, 255, 0, 0), 1);


        private SolidBrush greenBrush = new SolidBrush(Color.FromArgb(75, 127, 255, 47));
        private Pen greenPen = new Pen(Color.FromArgb(75, 34, 139, 34), 1);

        public void MarkArea(Rectangle rect, bool green)
        {
            this.Refresh();

            using (var g = this.CreateGraphics())
            {
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                if(green)
                {
                    g.FillRectangle(greenBrush, rect);
                    g.DrawRectangle(greenPen, rect);
                }
                else
                {
                    g.FillRectangle(redBrush, rect);
                    g.DrawRectangle(redPen, rect);
                }
            }
            GC.Collect();
        }



        private Image baseImage;

        public Image BaseImage
        {
            get
            {
                return baseImage;
            }
            set
            {
                this.baseImage = value;
                this.Image = value;
            }
        }

        #endregion


        public ImageViewer()
        {
            InitializeComponent();
        }

        public ImageViewer(Image iBaseImage)
        {
            this.baseImage = iBaseImage;
        }

        protected override void OnPaint(PaintEventArgs pe)
        {
            base.OnPaint(pe);
        }

        private int zoomLevel = 1;

        public int ZoomLevel
        {
            get
            {
                return zoomLevel;
            }
            set
            {
                this.zoomLevel = value;

                if(this.zoomLevel > 5 )
                {
                    this.zoomLevel = 5;
                }
                else if (this.zoomLevel < 1)
                {
                    this.zoomLevel = 1;
                }

                this.Image = Imaging.Utilities.PictureBoxZoom(this.baseImage, new Size(value, value));
                GC.Collect();
                this.Refresh();
            }
        }


    }
}
