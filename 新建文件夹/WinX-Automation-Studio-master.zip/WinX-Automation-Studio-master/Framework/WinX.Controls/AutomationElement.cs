﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;


public static partial class AutomationElement
{
    public static System.Drawing.Bitmap GetBitmap(this System.Windows.Automation.AutomationElement ae)
    {
        return new System.Drawing.Bitmap(WinX.Imaging.ScreenCapture.CaptureWindow(new IntPtr(ae.Current.NativeWindowHandle)));
    }

    public static System.Windows.Automation.AutomationElement GetTopLeveWindow(this System.Windows.Automation.AutomationElement element)
    {
        var walker = TreeWalker.ControlViewWalker;
        System.Windows.Automation.AutomationElement elementParent;

        var node = element;

        if (node == System.Windows.Automation.AutomationElement.RootElement)
        {
            return node;
        }

        do
        {
            elementParent = walker.GetParent(node);
            if (elementParent == System.Windows.Automation.AutomationElement.RootElement)
            {
                break;
            }
            node = elementParent;
        } while (true);

        return node;
    }

}
