﻿using System;
using System.CodeDom;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using WinX.Core;
using WinX.Web;

namespace WinX.StudioLib
{
    public partial class CodeGenerator
    {
        public CodeType CodeType
        {
            get; set;
        }

        private List<string> mErrors = new List<string>();

        public List<string> Errors
        {
            get
            {
                return mErrors;
            }
            set
            {
                mErrors = value;
            }
        }

        private bool mEmbedLibraryies = true;

        public bool EmbedLibraryies
        {
            get
            {
                return mEmbedLibraryies;
            }
            set
            {
                mEmbedLibraryies = value;
            }
        }

        private bool mEmbedUIComponents = false;

        public bool EmbedUIComponents
        {
            get
            {
                return mEmbedUIComponents;
            }
            set
            {
                mEmbedUIComponents = value;
            }
        }

        public bool Generate(string filePath, WinX.Core.Project proj)
        {
            Errors.Clear();
            var status = false;

            try
            {
                proj.BuildVersion += 0.1f;
                var compileUnit = GetCodeCompileUnit(proj);

                var winXNamespace = new CodeNamespace("WinX." + proj.Name);
                compileUnit.Namespaces.Add(winXNamespace);
                compileUnit.Namespaces.Add(new CodeNamespace("UIAutomationClient"));

                var winxRuntime = new CodeTypeDeclaration("RunTime");
                winxRuntime.IsClass = true;
                winxRuntime.Attributes = MemberAttributes.Public | MemberAttributes.Static;
                //winxRuntime.BaseTypes.Add(new CodeTypeReference(app.))

                var terminateMethod = new CodeMemberMethod();
                terminateMethod.Attributes = MemberAttributes.Public | MemberAttributes.Static;
                terminateMethod.Name = "Terminate";
                terminateMethod.Statements.Add(new CodeMethodInvokeExpression(new CodeTypeReferenceExpression("WinX.Core.Project"), "Terminate"));
                winxRuntime.Members.Add(terminateMethod);
                winXNamespace.Types.Add(winxRuntime);

                var lstApps = new List<string>();
                var assembles = new List<Assembly>();
                assembles.Add(Assembly.GetAssembly(typeof(WinX.Core.Project)));
                assembles.Add(Assembly.GetAssembly(typeof(System.Windows.Automation.AutomationElement)));
                assembles.Add(Assembly.GetAssembly(typeof(WinX.Windows.GenericWindow)));

                int visualElementCount = 0;

                foreach (var app in proj.Applications)
                {
                    var assembly = app.GetType().Assembly;
                    if (!assembles.Contains(assembly))
                    {
                        assembles.Add(assembly);
                    }

                    var winXAppClass = new CodeTypeDeclaration(app.Name);
                    winXAppClass.IsClass = true;
                    //winXAppClass.IsPartial = true;
                    winXAppClass.Attributes = MemberAttributes.Public;
                    winXAppClass.BaseTypes.Add(new CodeTypeReference(app.GetType()));
                    winXNamespace.Types.Add(winXAppClass);

                    var appCodeConstructor = new CodeConstructor();
                    appCodeConstructor.Attributes = MemberAttributes.Public;
                    winXAppClass.Members.Add(appCodeConstructor);

                    var lst = new List<string>();

                    foreach (var screen in app.Screens)
                    {
                        var winXClass = new CodeTypeDeclaration(screen.Name);
                        winXClass.IsClass = true;
                        //winXClass.IsPartial = true;
                        winXClass.Attributes = MemberAttributes.Public;
                        winXClass.BaseTypes.Add(new CodeTypeReference(screen.GetType()));
                        winXAppClass.Members.Add(winXClass);


                        var screenProp = new CodeMemberProperty();
                        screenProp.Name = "_" + screen.Name;
                        screenProp.Attributes = MemberAttributes.Public | MemberAttributes.Static;
                        screenProp.Type = new CodeTypeReference(screen.Name);

                        //screenProp.GetStatements.Add(new CodeMethodReturnStatement(new CodeMethodInvokeExpression(new CodeMethodReferenceExpression(new CodeBaseReferenceExpression(), "GetScreen"),
                        //                                                           new CodeObjectCreateExpression(typeof(Guid), new CodeSnippetExpression(string.Format("\"{0}\"", screen.ID.ToString()))))));
                        screenProp.GetStatements.Add(new CodeMethodReturnStatement(new CodeObjectCreateExpression(screen.Name)));
                        winXAppClass.Members.Add(screenProp);

                        //CodeConstructor
                        var screenConstructor = new CodeConstructor();
                        screenConstructor.Attributes = MemberAttributes.Public;
                        winXClass.Members.Add(screenConstructor);

                        foreach (var ee in screen.Fields)
                        {
                            if (string.IsNullOrEmpty(ee.ElementType))
                            {
                                ee.ElementType = "System.Object";
                            }

                            var winXprop = new CodeMemberProperty();
                            winXprop.Name = ee.Name;
                            winXprop.Attributes = MemberAttributes.Public;
                            winXprop.Type = new CodeTypeReference(ee.ElementType);

                            CodeMethodReferenceExpression codeTypeReference = null;

                            if (ee is WinX.Web.WebElement)
                            {
                                var idRule = ee.MatchRules.Where(r => r is IDMatchRule).FirstOrDefault();
                                if (idRule == null)
                                {
                                    winXprop.Type = new CodeTypeReference("System.Collections.Generic.IList<" + ee.ElementType + ">");
                                    codeTypeReference = new CodeMethodReferenceExpression(new CodeBaseReferenceExpression(), "GetFields", new CodeTypeReference(ee.ElementType));
                                }
                                else
                                {
                                    codeTypeReference = new CodeMethodReferenceExpression(new CodeBaseReferenceExpression(), "GetField", new CodeTypeReference(ee.ElementType));
                                }
                            }
                            else if (ee is WinX.Windows.GenericElement)
                            {
                                var idRule = ee.MatchRules.Where(r => r is WinX.Windows.ControlIdMatchRule).FirstOrDefault();
                                if (idRule == null)
                                {
                                    winXprop.Type = new CodeTypeReference("System.Collections.Generic.IList<" + ee.ElementType + ">");
                                    codeTypeReference = new CodeMethodReferenceExpression(new CodeBaseReferenceExpression(), "GetFields", new CodeTypeReference(ee.ElementType));
                                }
                                else
                                {
                                    codeTypeReference = new CodeMethodReferenceExpression(new CodeBaseReferenceExpression(), "GetField", new CodeTypeReference(ee.ElementType));
                                }
                            }
                            else if (ee is WinX.Windows.VisualElement)
                            {
                                visualElementCount++;
                                codeTypeReference = new CodeMethodReferenceExpression(new CodeBaseReferenceExpression(), "GetField", new CodeTypeReference(ee.ElementType));
                            }
                            else
                            {
                                codeTypeReference = new CodeMethodReferenceExpression(new CodeBaseReferenceExpression(), "GetField");
                            }

                            winXprop.GetStatements.Add(new CodeMethodReturnStatement(new CodeMethodInvokeExpression(codeTypeReference,
                                                                                         new CodeObjectCreateExpression(typeof(Guid),
                                                                                         new CodeSnippetExpression(string.Format("\"{0}\"", ee.ID.ToString()))))));

                            winXClass.Members.Add(winXprop);
                        }

                        WinX.Core.Serializers.ObjectToXMLFile(screen, screen.GetType(), string.Format(@"{0}\{1}.{2}.{3}.winx", filePath,
                                                                                                            winXNamespace.Name, winXAppClass.Name, winXClass.Name),
                                                                                                            TypeHelper.GetTypes(screen.GetType().Assembly).ToArray());
                        lstApps.Add(string.Format(@"{0}\{1}.{2}.{3}.winx", filePath, winXNamespace.Name, winXAppClass.Name, winXClass.Name));
                    }
                }

                if(visualElementCount > 0)
                {
                    assembles.Add(Assembly.GetAssembly(typeof(WinX.Imaging.Compress)));
                }

                if (assembles.Contains(Assembly.GetAssembly(typeof(WinX.Web.WebApplication))))
                {
                    assembles.Add(Assembly.GetAssembly(typeof(mshtml.HTMLDocument)));

                    compileUnit.Namespaces.Add(new CodeNamespace("Microsoft.mshtml"));
                }

                foreach (var asm in assembles)
                {
                    winXNamespace.Imports.Add(new CodeNamespaceImport(asm.GetName().Name));
                }

                var providerOptions = new Dictionary<string, string>();
                if (!string.IsNullOrEmpty(proj.DotNetRuntimeVersion))
                {
                    providerOptions.Add("CompilerVersion", proj.DotNetRuntimeVersion);
                }


                if (CodeType == CodeType.DLL || CodeType == CodeType.EXE)
                {
                    var parameters = new CompilerParameters(new string[] { "System.dll" });
                    parameters.CompilerOptions = "/optimize";
                    parameters.TreatWarningsAsErrors = false;
                    //parameters.IncludeDebugInformation = true;
                    //parameters.TempFiles = new TempFileCollection(".", true);
                    //parameters.ReferencedAssemblies.Add("System.dll");


                    if (CodeType == CodeType.DLL)
                    {
                        parameters.GenerateExecutable = false;
                        parameters.OutputAssembly = filePath + @"\" + proj.Name + ".dll";
                    }
                    else
                    {
                        parameters.GenerateExecutable = false;
                        parameters.OutputAssembly = filePath + @"\" + proj.Name + ".exe";

                        var className = "WinXEntryPoint";
                        var targetClass = new CodeTypeDeclaration(className);
                        targetClass.IsClass = true;
                        targetClass.TypeAttributes = TypeAttributes.Public | TypeAttributes.Sealed;

                        var start = new CodeEntryPointMethod();
                        start.Statements.Add(new CodeMethodInvokeExpression(new CodeTypeReferenceExpression("System.Console"), "WriteLine", new CodeSnippetExpression("\"WinX Executable - Test \"")));
                        start.Statements.Add(new CodeMethodInvokeExpression(new CodeTypeReferenceExpression("System.Console"), "ReadLine", new CodeSnippetExpression()));

                        targetClass.Members.Add(start);
                        winXNamespace.Types.Add(targetClass);
                    }

                    foreach (var asm in assembles)
                    {
                        parameters.ReferencedAssemblies.Add(asm.Location);
                    }

                    foreach (var screen in lstApps)
                    {
                        parameters.EmbeddedResources.Add(screen);
                    }

                    var provider = new Microsoft.CSharp.CSharpCodeProvider();
                    var r = provider.CompileAssemblyFromDom(parameters, compileUnit);

                    if (r.Errors.Count == 0)
                    {
                        if (EmbedLibraryies)
                        {

                            var myMerge = new ILMerging.ILMerge();

                            var asmfiles = new List<string>();

                            if (CodeType == CodeType.DLL)
                            {
                                myMerge.OutputFile = filePath + @"\" + proj.Name + ".dll";
                                asmfiles.Add(filePath + @"\" + proj.Name + ".dll");
                            }
                            else
                            {
                                myMerge.OutputFile = filePath + @"\" + proj.Name + ".exe";
                                asmfiles.Add(filePath + @"\" + proj.Name + ".exe");
                            }


                            foreach (var asm in assembles.Where(m => m.GetName().Name.StartsWith("WinX")))
                            {
                                asmfiles.Add(asm.Location);
                            }

                            myMerge.SetInputAssemblies(asmfiles.ToArray());
                            myMerge.SetTargetPlatform("v4", @"C:\Windows\Microsoft.NET\Framework\v4.0.30319");
                            myMerge.Merge();

                        }
                        status = true;
                    }
                    else
                    {
                        foreach (CompilerError er in r.Errors)
                        {
                            Errors.Add("[" + er.ErrorNumber + "] [Line : " + er.Line + "] : " + er.ErrorText);
                        }
                    }

                    foreach (var screen in lstApps)
                    {
                        System.IO.File.Delete(screen);
                    }
                }
                else if (CodeType == CodeType.VB)
                {
                    using (var fileStream = new StreamWriter(File.Create(string.Format(@"{1}\{0}.vb", proj.Name, filePath))))
                    {
                        var provider = new Microsoft.VisualBasic.VBCodeProvider(providerOptions);
                        provider.GenerateCodeFromCompileUnit(compileUnit, fileStream, null);
                        status = true;
                    }
                    return status;
                }
                else if (CodeType == CodeType.CSharp)
                {
                    using (var fileStream = new StreamWriter(File.Create(string.Format(@"{1}\{0}.cs", proj.Name, filePath))))
                    {
                        var provider = new Microsoft.CSharp.CSharpCodeProvider(providerOptions);
                        provider.GenerateCodeFromCompileUnit(compileUnit, fileStream, null);
                        status = true;
                    }
                    return status;
                }
                else if (CodeType == CodeType.Javascript)
                {
                    using (var fileStream = new StreamWriter(File.Create(string.Format(@"{1}\{0}.js", proj.Name, filePath))))
                    {
                        var provider = new Microsoft.JScript.JScriptCodeProvider();
                        provider.GenerateCodeFromCompileUnit(compileUnit, fileStream, null);
                        status = true;
                    }
                    return status;
                }
            }
            catch (Exception ex)
            {

            }
            return status;
        }

        private CodeCompileUnit GetCodeCompileUnit(WinX.Core.Project proj)
        {
            var compileUnit = new CodeCompileUnit();

            AddAssemblyAttribute(compileUnit, typeof(AssemblyVersionAttribute), Math.Round(proj.BuildVersion, 4).ToString());
            AddAssemblyAttribute(compileUnit, typeof(AssemblyFileVersionAttribute), Math.Round(proj.BuildVersion, 4).ToString());
            AddAssemblyAttribute(compileUnit, typeof(AssemblyTitleAttribute), proj.Name);
            AddAssemblyAttribute(compileUnit, typeof(AssemblyProductAttribute), "WinX Framework");
            AddAssemblyAttribute(compileUnit, typeof(AssemblyDescriptionAttribute), proj.Description + Environment.NewLine + "Assembly was build at " + DateTime.Now);
            AddAssemblyAttribute(compileUnit, typeof(AssemblyCompanyAttribute), proj.Company);
            AddAssemblyAttribute(compileUnit, typeof(AssemblyCopyrightAttribute), proj.Copyright);
            AddAssemblyAttribute(compileUnit, typeof(AssemblyTrademarkAttribute), proj.Trademark);

            return compileUnit;
        }
        
        private void AddAssemblyAttribute(CodeCompileUnit unit, Type attributeType, object value)
        {
            var assemblyVersion = new CodeAttributeDeclaration(new CodeTypeReference(attributeType), new CodeAttributeArgument(new CodePrimitiveExpression(value)));
            unit.AssemblyCustomAttributes.Add(assemblyVersion);
        }

    }
}
