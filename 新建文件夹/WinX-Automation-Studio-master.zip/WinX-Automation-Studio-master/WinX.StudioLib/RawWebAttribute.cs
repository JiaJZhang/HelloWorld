﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace WinX.StudioLib
{
    [DisplayName("Attribute"), ReadOnly(true)]
    public partial class RawWebAttribute
    {
        public string Name
        {
            get; set;
        }

        public string Value
        {
            get; set;
        }

        public bool IsSpecified
        {
            get; set;
        }
    }
}
