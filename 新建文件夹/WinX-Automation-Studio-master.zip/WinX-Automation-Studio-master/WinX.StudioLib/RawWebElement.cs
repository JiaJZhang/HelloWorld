﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using WinX.Core;

namespace WinX.StudioLib
{
    [TypeConverter(typeof(OptionsConverter))]
    [Serializable]
    public partial class RawWebElement
    {
        public List<RawWebAttribute> Attributes
        {
            get; set;
        }

        public RawWebElement Parent
        {
            get; set;
        }

        public List<RawWebElement> Childern
        {
            get; set;
        }


        public string ID
        {
            get; set;
        }

        public string Name
        {
            get; set;
        }

        public string Tag
        {
            get; set;
        }

        public string InnerHTML
        {
            get; set;
        }

        public string InnerText
        {
            get; set;
        }

        public string OuterHTML
        {
            get; set;
        }

        public string OuterText
        {
            get; set;
        }

        public string Title
        {
            get; set;
        }

        public Type Type
        {
            get; set;
        }

        public int Index
        {
            get; set;
        }
    }
}
