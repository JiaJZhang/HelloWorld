﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using WinX.Core;

namespace WinX.StudioLib
{
    [TypeConverter(typeof(OptionsConverter))]
    [Serializable]
    public partial class RawWebScreen
    {
    }
}
