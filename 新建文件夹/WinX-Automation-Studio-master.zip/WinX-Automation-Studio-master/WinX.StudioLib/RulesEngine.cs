﻿using mshtml;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WinX.Core;
using WinX.Web;

namespace WinX.StudioLib
{
    public partial class RulesEngine
    {
        public static IList<MatchRule> GetPossibleWebElementRules(RawWebElement ele, bool SpecifiedAttributesObly)
        {
            List<MatchRule> rules = null;

            if (ele != null)
            {
                rules = new List<MatchRule>();

                rules.Add(new TagMatchRule(ele.Tag));
                if (!string.IsNullOrEmpty(ele.ID))
                {
                    rules.Add(new IDMatchRule(ele.ID));
                }
                if (!string.IsNullOrEmpty(ele.Name))
                {
                    rules.Add(new NameMatchRule(ele.Name));
                }

                if (ele.Index > -1)
                {
                    rules.Add(new IndexMatchRule(ele.Index));
                }

                if (!string.IsNullOrEmpty(ele.InnerText))
                {
                    rules.Add(new InnerTextMatchRule(ele.InnerText));
                }

                if (!string.IsNullOrEmpty(ele.OuterText))
                {
                    rules.Add(new OuterTextMatchRule(ele.OuterText));
                }

                if (!string.IsNullOrEmpty(ele.InnerHTML))
                {
                    rules.Add(new InnerHtmlMatchRule(ele.InnerHTML));
                }

                if (!string.IsNullOrEmpty(ele.OuterHTML))
                {
                    rules.Add(new OuterHtmlMatchRule(ele.OuterHTML));
                }

                if (ele.Attributes.Count > 0)
                {
                    if (SpecifiedAttributesObly)
                    {
                        foreach (var att in ele.Attributes.Where(r => r.IsSpecified))
                        {
                            rules.Add(new AttributeMatchRule(att.Name, new WinX.Core.StringComparer(att.Value)));
                        }
                    }
                    else
                    {
                        foreach (var att in ele.Attributes)
                        {
                            rules.Add(new AttributeMatchRule(att.Name, new WinX.Core.StringComparer(att.Value)));
                        }
                    }
                }
            }
            return rules;
        }

        public static RawWebElement GetRawWebElement(IHTMLElement ele,bool GetparentAndChildern = false)
        {
            RawWebElement RawEle = null;
            dynamic ele2 = ele;


            try
            {
                if (ele != null)
                {
                    RawEle = new RawWebElement()
                    {
                        Tag = ele.tagName,
                        InnerHTML = ele.innerHTML,
                        InnerText = ele.innerText,
                        OuterHTML = ele.outerHTML,
                        OuterText = ele.outerText,
                        Title = ele.title,
                        Type = ele.GetType(),
                        Index = ele.sourceIndex
                    };

                    try
                    {
                        dynamic attributes = ele2.attributes;
                        if (ele2.attributes != null && attributes.length != null && attributes.length > 0)
                        {
                            RawEle.Attributes = new List<RawWebAttribute>();
                            for (int i = 0; i < attributes.length; i++)
                            {
                                var att = attributes.item(i) as IHTMLDOMAttribute;
                                if (att.nodeValue != null && !(att.nodeValue is System.DBNull))
                                {
                                    RawEle.Attributes.Add(new RawWebAttribute
                                    {
                                        Name = att.nodeName,
                                        IsSpecified = att.specified,
                                        Value = att.nodeValue.ToString(),
                                    });
                                }
                            }
                            RawEle.Attributes = RawEle.Attributes.OrderBy(o => o.Name).ToList();
                        }
                    }
                    catch (Exception ex2)
                    {
                        
                    }

                    try
                    {
                        if (GetparentAndChildern)
                        {
                            RawEle.Parent = GetRawWebElement(ele.parentElement);
                            var childCol = ele.children as IHTMLElementCollection;
                            if (childCol != null && childCol.length > 0)
                            {
                                RawEle.Childern = new List<RawWebElement>();

                                foreach (IHTMLElement cCol in childCol)
                                {
                                    var cEle = GetRawWebElement(cCol);

                                    if (cEle != null)
                                    {
                                        RawEle.Childern.Add(cEle);
                                    }
                                }
                                RawEle.Childern = RawEle.Childern.OrderBy(o => o.Type).ToList();
                            }

                        }
                    }
                    catch (Exception ex3)
                    {

                    }

                    var IdAtt = RawEle.Attributes.Where(m => m.Name == "id").FirstOrDefault();
                    if (IdAtt != null)
                    {
                        RawEle.ID = IdAtt.Value;
                        RawEle.Attributes.Remove(IdAtt);
                    }


                    var nameAtt = RawEle.Attributes.Where(m => m.Name == "name").FirstOrDefault();
                    if (nameAtt != null)
                    {
                        RawEle.Name = nameAtt.Value;
                        RawEle.Attributes.Remove(nameAtt);
                    }
                }
            }
            catch (Exception ex)
            {

            }
            return RawEle;
        }

    }
}
