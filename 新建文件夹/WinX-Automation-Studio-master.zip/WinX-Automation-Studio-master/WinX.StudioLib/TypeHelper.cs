﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;

namespace WinX.StudioLib
{
    public partial class TypeHelper
    {
        public static List<Type> GetTypes(Assembly assembly = null)
        {
            var lstTypes = new List<Type>();
            
            if (assembly != null)
            {
                lstTypes.AddRange(WinX.Core.ReflectionHelper.FindDerivedTypes(assembly,
                                                                            typeof(WinX.Core.Application),
                                                                            typeof(WinX.Core.Screen),
                                                                            typeof(WinX.Core.Field),
                                                                            typeof(WinX.Core.MatchRule)));
            }
            else
            {
                lstTypes.AddRange(WinX.Core.ReflectionHelper.FindDerivedTypes( (typeof(WinX.Web.WebApplication)).Assembly,
                                                                            typeof(WinX.Core.Application),
                                                                            typeof(WinX.Core.Screen),
                                                                            typeof(WinX.Core.Field),
                                                                            typeof(WinX.Core.MatchRule)));




                lstTypes.AddRange(WinX.Core.ReflectionHelper.FindDerivedTypes((typeof(WinX.Windows.GenericApplication)).Assembly,
                                                                            typeof(WinX.Core.Application),
                                                                            typeof(WinX.Core.Screen),
                                                                            typeof(WinX.Core.Field),
                                                                            typeof(WinX.Core.MatchRule)));





            }





            return lstTypes;
        }

    }
}
