﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Runtime.InteropServices;
using System.Drawing;

namespace WinX.Imaging.Test
{
    [TestClass]
    public class ImageUnitTest
    {

        [DllImport("user32.dll", EntryPoint = "FindWindow", SetLastError = true)]
        public static extern IntPtr FindWindowByCaption(IntPtr ZeroOnly, string lpWindowName);

        [TestMethod]
        public void StartSearchMethod()
        {

            var winHandle = FindWindowByCaption(IntPtr.Zero, "计算器");


            var bmp = WinX.Imaging.ScreenCapture.CaptureWindow(winHandle);

            var fileName = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, DateTime.Now.ToString("yyyyMMddhhmmss") + ".jpg");

            bmp.Save(fileName, System.Drawing.Imaging.ImageFormat.Jpeg);

        }

        [TestMethod]
        public void CaptureScreenMedthod()
        {
            var bmp = WinX.Imaging.ScreenCapture.CaptureScreen();

            var fileName = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, DateTime.Now.ToString("yyyyMMddhhmmss") + ".jpg");

            bmp.Save(fileName, System.Drawing.Imaging.ImageFormat.Jpeg);
        }

        [TestMethod]
        public void SearchMedthod()
        {
            using (var source = new Bitmap("Image\\SearchSource.PNG"))
            {
                using (var target = new Bitmap("Image\\SearchTarget.PNG"))
                {
                    var rect = ImageSearch.Search(source, target);

                }
            }

        }
    }
}
