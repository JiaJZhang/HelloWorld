﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace WinX.Controls.Test
{
    [TestClass]
    public class PointerTest
    {
        [TestMethod]
        public void StartSearchMethod()
        {
            var wcp = new Pointers.WindowCapturePointer();

            wcp.StartSearch();
        }
    }
}
