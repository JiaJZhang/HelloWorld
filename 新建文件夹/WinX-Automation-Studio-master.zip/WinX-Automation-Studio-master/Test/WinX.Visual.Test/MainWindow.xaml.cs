﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WinX.Visual.Test
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnOk_Click(object sender, RoutedEventArgs e)
        {
            var visualCal = new WinX.VisualTest.VisualGeneric.VisualCal();

            if (visualCal.WaitForCreate(300))
            {
                //var rect = visualCal.Window.AutomationElement.Current.BoundingRectangle;

                //var rect2 = WinX.Windows.WindowsHelper.GetRawWindowFromHandle(new IntPtr(visualCal.Window.AutomationElement.Current.NativeWindowHandle));

                visualCal.HotArea_789.Click();
            }

        }
    }
}
