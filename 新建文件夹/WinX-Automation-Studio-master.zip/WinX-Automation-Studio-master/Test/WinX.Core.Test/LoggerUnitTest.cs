﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace WinX.Core.Test
{
    [TestClass]
    public class LoggerUnitTest
    {
        [TestMethod]
        public void TestMethod1()
        {

            var s = System.Environment.MachineName;
        }
    }
}
