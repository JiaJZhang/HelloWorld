﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;

namespace WinX.Core.Test
{
    [TestClass]
    public class Win32UnitTest
    {
        [DllImport("user32.dll", EntryPoint = "FindWindow", SetLastError = true)]
        public static extern IntPtr FindWindowByCaption(IntPtr ZeroOnly, string lpWindowName);


        [TestMethod]
        public void GetChildHandleTestMethod()
        {
            var winHandle = FindWindowByCaption(IntPtr.Zero, "计算器");

            var handles = WinX.Core.WindowsHelper.GetChildWindows(winHandle);
        }

        [TestMethod]
        public void WScriptShellTestMethod()
        {
            dynamic ws = Microsoft.VisualBasic.Interaction.CreateObject("WScript.Shell");
            ws.AppActivate("百度一下，你就知道 ");
        }
    }
}