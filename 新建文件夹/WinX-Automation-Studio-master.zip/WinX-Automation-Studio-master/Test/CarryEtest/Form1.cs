﻿using mshtml;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Windows.Forms;

namespace CarryEtest
{
    public partial class Form1 : Form
    {
        private int MaxTryCount = 0;
        private string APP_ID = "16675487";
        private string API_KEY = "PbwNOPKIxuc64uN2y3W6lgjA";
        private string SECRET_KEY = "WcoGDYKprtCN9HPHac19XcrokBT6ocRl";

        public Form1()
        {
            InitializeComponent();
        }

        private void btnRun_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("iexplore.exe", "http://mse.neea.cn/");  //直接打开IE浏览器，打开指定页

            bool result = false;

            try
            {
                var user = LoginUser.FirstTestUser;

                if (LoginPage(user) && ReadingAgreement() && SelectPage(user))
                {
                    var ieProcess = System.Diagnostics.Process.GetProcessesByName("IEXPLORE");

                    foreach (var p in ieProcess)
                    {
                        p.Kill();
                    }
                }

                //SelectPage(user);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public bool ReadingAgreement()
        {
            bool result = false;

            var readingAgreement = new WinX.MSE.Etest.ReadingAgreement();

            if (readingAgreement.WaitForLoadComplete(300) && readingAgreement.aAgree != null && readingAgreement.aAgree.Count > 0)
            {
                readingAgreement.aAgree[0].click();

                result =  true;
            }

            return result;
        }

        public bool SelectPage(LoginUser user)
        {
            bool result = false;

            var selectPage = new WinX.MSE.Etest.SelectPage();

            if (selectPage.WaitForLoadComplete(300) && selectPage.aExit != null && selectPage.aExit.Count > 0)
            {
                var selAddress = selectPage.selAddress[0];

                var selAddressOptionList = selAddress.children as mshtml.IHTMLElementCollection;

                int addressIndex = 0;
                for (int i = 0; i < selAddressOptionList.length; i++)
                {
                    var selAddressOption = selAddressOptionList.item(i) as mshtml.HTMLOptionElementClass;

                    if (null != selAddressOption && selAddressOption.innerHTML == user.Address)
                    {
                        break;
                    }
                    addressIndex++;
                }

                selAddress.selectedIndex = addressIndex;

                selectPage.ExecuteJScript("getAddr2()");

                System.Threading.Thread.Sleep(500);

                var aOrgList = selectPage.ddOrglist.children as mshtml.IHTMLElementCollection;
                bool isSelectOrg = false;
                for (int i = 0; i < aOrgList.length; i++)
                {
                    var aOrg = aOrgList.item(i) as mshtml.HTMLAnchorElementClass;

                    if (null != aOrg && aOrg.innerHTML.Trim() == user.Org.Trim())
                    {
                        aOrg.click();
                        isSelectOrg = true;
                        break;
                    }
                }

                if(!isSelectOrg)
                {
                    throw new IndexOutOfRangeException("找不到相关的考点：" + user.Org.Trim());
                }

                System.Threading.Thread.Sleep(500);

                var aProjectTypeList = selectPage.ddProjectType.children as mshtml.IHTMLElementCollection;
                bool isProjectType = false;
                for (int i = 0; i < aProjectTypeList.length; i++)
                {
                    var aProjectType = aProjectTypeList.item(i) as mshtml.HTMLAnchorElementClass;

                    if (null != aProjectType && aProjectType.innerHTML.Trim() == user.ProjectType.Trim())
                    {
                        aProjectType.click();
                        isProjectType = true;
                        break;
                    }
                }

                if (!isProjectType)
                {
                    throw new IndexOutOfRangeException("找不到相关的科目：" + user.ProjectType.Trim());
                }

                System.Threading.Thread.Sleep(500);

                var trCartGoodList = selectPage.trCartGood;

                if (trCartGoodList != null && trCartGoodList.Count > 0)
                {
                    MessageBox.Show("有数据！");
                }
                else
                {
                    MessageBox.Show("没数据！");
                }

                selectPage.aExit[0].click();
                result = true;
            }
            return result;
        }


        public bool HomePageOpenLogin()
        {
            bool result = false;

            var homePage = new WinX.MSE.Etest.HomePage();
            var loginPage = new WinX.MSE.Etest.LoginPage();

            if (homePage.WaitForLoadComplete(300) && homePage.aJumpLogin != null && homePage.aJumpLogin.Count > 0)
            {
                homePage.aJumpLogin[0].click();

                result = true;
            }

            return result;
        }

        public bool LoginPage(LoginUser user)
        {
            bool result = false;
            
            var loginPage = new WinX.MSE.Etest.LoginPage();
            var readingAgreement = new WinX.MSE.Etest.ReadingAgreement();
            if (loginPage.WaitForLoadComplete(300))
            {
                loginPage.txtLoginName.value = user.UserName;
                loginPage.txtLoginPwd.value = user.Password;

                var key = GetStringKaptcha();

                loginPage.txtVerificationCode.value = key;

                loginPage.btnLogin.click();

                if (!readingAgreement.WaitForLoadComplete(5))
                {
                    if (!LoginPage(user) && MaxTryCount++ < 5)
                    {
                        return false;
                    }
                }

                result = true;
                
            }
            return result;
        }


        private string GetStringKaptcha()
        {
            string result = string.Empty;
            string fileName = string.Empty;

            while (string.IsNullOrEmpty(fileName))
            {
                try
                {
                    fileName = downloadImgKaptcha();
                }
                catch (Exception ex)
                {

                }
            }

            string newFileName = string.Empty;

            if (!string.IsNullOrEmpty(fileName))
            {
                newFileName = MoreCleanImage(fileName);

                System.IO.File.Delete(fileName);

                var client = new Baidu.Aip.Ocr.Ocr(API_KEY, SECRET_KEY);
                client.Timeout = 60000;  // 修改超时时间

                var NewImage = File.ReadAllBytes(newFileName);
                // 调用通用文字识别, 图片参数为本地图片，可能会抛出网络等异常，请使用try/catch捕获

                var resultOCR = client.AccurateBasic(NewImage);
                //var resultOCR = client.GeneralBasic(NewImage);

                if (resultOCR.HasValues && resultOCR.First.ToString().Contains("error_code"))
                {
                    throw new ExecutionEngineException(resultOCR.ToString());
                }

                System.IO.File.Delete(newFileName);

                var wordResult = resultOCR.GetValue("words_result");


                if (null != wordResult&& wordResult.HasValues && wordResult.Count() > 0)
                {
                    result = wordResult[0].Value<String>("words").Trim();

                    //MessageBox.Show(result);
                }

                if(string.IsNullOrEmpty(result) || result.Length != 4)
                {
                    ClickReGenericImage();

                    return GetStringKaptcha();
                }
            }
            return result;
        }


        private void ClickReGenericImage()
        {
            var loginPage = new WinX.MSE.Etest.LoginPage();

            if (loginPage.WaitForLoadComplete(300) && loginPage.aReflashImage != null && loginPage.aReflashImage.Count() > 0)
            {
                loginPage.aReflashImage[0].click();

                System.Threading.Thread.Sleep(500);

            }
        }

        private string downloadImgKaptcha()
        {
            var loginPage = new WinX.MSE.Etest.LoginPage();

            string fileName = DateTime.Now.ToString("yyyyMMddhhmmss") + ".jpg";

            if (loginPage.WaitForLoadComplete(300))
            {
                //loginPage.ExecuteJScript("var a = document.createElement('a');a.href = canvas.toDataURL(\"image/jpeg\").replace(\"image/jpeg\", \"image/octet-stream\");a.download = 'somefilename.jpg';a.click();");

                //loginPage.ExecuteJScript("window.open(document.getElementById('" + loginPage.imgKaptcha.id + "').src);");

                var doc = loginPage.GetDocument();// (IHTMLDocument2)wb1.Document;
                var imgRange = (IHTMLControlRange)((HTMLBody)doc.body).createControlRange();

                imgRange.add((IHTMLControlElement)loginPage.imgKaptcha);

                imgRange.execCommand("Copy", false, null);

                if (Clipboard.GetDataObject() != null)
                {
                    // Get clipboard data
                    var clipboardData = Clipboard.GetDataObject();

                    // If clipboard data is in bitmap format
                    if (clipboardData != null && clipboardData.GetDataPresent(DataFormats.Bitmap))
                    {
                        // Get image data
                        var image = (Image)clipboardData.GetData(DataFormats.Bitmap, true);
                        System.Drawing.Imaging.ImageFormat fileFormat;

                        switch (fileName.Substring(fileName.Length - 3))
                        {
                            case "png":
                                fileFormat = System.Drawing.Imaging.ImageFormat.Png;
                                break;
                            case "jpg":
                                fileFormat = System.Drawing.Imaging.ImageFormat.Jpeg;
                                break;
                            case "gif":
                                fileFormat = System.Drawing.Imaging.ImageFormat.Gif;
                                break;
                            case "bmp":
                                fileFormat = System.Drawing.Imaging.ImageFormat.Bmp;
                                break;
                            default:
                                fileFormat = System.Drawing.Imaging.ImageFormat.Png;
                                break;
                        }

                        image.Save(fileName, fileFormat);

                        image.Dispose();
                    }
                }

            }
            return fileName;
        }

        private string MoreCleanImage(string fileName)
        {
            var newFileName = "New_" + fileName;

            using (Bitmap myImage = (Bitmap)Bitmap.FromFile(fileName))
            {
                for (int x = 0; x < myImage.Width; x++)
                {
                    for (int y = 0; y < myImage.Height; y++)
                    {
                        //int rgb = myImage.GetPixel(x, y).ToArgb();
                        //if (!list.ContainsKey(rgb))
                        //    list.Add(rgb, 1);
                        //else
                        //    list[rgb]++;

                        var pixel = myImage.GetPixel(x, y);


                        if (pixel.R < 100 && pixel.G < 100 && pixel.B < 100)
                        {
                            int tryX = 0;

                            bool isTrySuccess = false;

                            for (int i = 0; i < 10; i++)
                            {
                                tryX++;
                                for (int j = 0; j < 10; j++)
                                {
                                    int tryY = 0;
                                    tryY++;

                                    var prePixel = myImage.GetPixel(x + tryX, y + tryY);
                                    if (prePixel.R > 50 && prePixel.G > 50 && prePixel.B > 50)
                                    {
                                        myImage.SetPixel(x, y, prePixel);
                                        isTrySuccess = true;
                                        break;
                                    }
                                    if (isTrySuccess)
                                    {
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }

                myImage.Save(newFileName);

                return newFileName;
            }
        }
    }
}
