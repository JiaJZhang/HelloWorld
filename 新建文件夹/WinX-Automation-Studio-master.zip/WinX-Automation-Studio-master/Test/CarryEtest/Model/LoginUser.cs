﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CarryEtest
{
    public class LoginUser
    {
        public string UserName
        {
            get; set;
        }

        public string Password
        {
            get; set;
        }

        public string Address
        {
            get;set;
        }

        public string Org
        {
            get; set;
        }

        public string ProjectType
        {
            get; set;
        }

        


        public static LoginUser FirstTestUser
        {
            get
            {
                return new LoginUser()
                {
                    UserName = "101829750@qq.com",
                    Password = "19890829@cxj",
                    Address = "广东省",
                    Org = "广州市华美英语实验学校",
                    ProjectType = "KET校园版"
                };
            }
        }
    }
}
