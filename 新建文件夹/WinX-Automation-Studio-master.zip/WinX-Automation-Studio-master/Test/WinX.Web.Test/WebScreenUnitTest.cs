﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using mshtml;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WinX.Web;

namespace WinX.Web.Test
{
    [TestClass]
    public partial class WebScreenUnitTest
    {
        const string url = @"http://www.baidu.com";

        //[TestMethod]
        //public void MatchUrlTestMethod()
        //{
        //    //ShellWindows.Start(url);

        //    var baiduWebScreen = new WinX.DadaTest.WebTest.Baidu();

        //    if (baiduWebScreen.WaitForCreate())
        //    {
        //        var txtSearch = baiduWebScreen.txtSearch;
        //        txtSearch.value = "dada";
        //        //baiduWebScreen.BringWindowFront();
        //        //baiduWebScreen.txtSearch.value = "dada";
        //        //baiduWebScreen.ExecuteJScript("alert('dada')");
        //    }
        //}

        [TestMethod]
        public void IEScreenCaptureTestMethod()
        {
            var ie = getWebBrowserList().FirstOrDefault() ;

            if (ie != null)
            {
                WebScreen webScreen = new WebScreen();

                var myDoc = ie.Document as mshtml.HTMLDocumentClass;
                var handle = ie.HWND;

                using (var bg = webScreen.GetIEScreenCapture(myDoc, handle))
                {
                    bg.Save(@"123123.jpg");
                }
            }

        }


        private IList<SHDocVw.WebBrowser> getWebBrowserList()
        {
            var result = new List<SHDocVw.WebBrowser>();
            var shellWindows = new SHDocVw.ShellWindowsClass();

            string fileName = string.Empty;

            foreach (SHDocVw.WebBrowser ie in shellWindows)
            {
                fileName = System.IO.Path.GetFileNameWithoutExtension(ie.FullName).ToLower();
                if (fileName.Equals("iexplore"))
                {
                    result.Add(ie);
                }
            }

            return result;
        }

        //[TestMethod]
        //public void BenZCarPriceTestMethod()
        //{
        //    //https://www.mercedes-benz.com.cn/homepage.html
        //    var BenZPricePage = new WinX.DadaTest.WebTest.BenZ();

        //    var startTime = DateTime.Now;

        //    var priceDic = new Dictionary<string, string>();

        //    if (BenZPricePage.WaitForCreate())
        //    {
        //        var aPriceList = BenZPricePage.aPrice.ToList();

        //        foreach (var aPrice in aPriceList)
        //        {
        //            var aChildList = aPrice.children as IHTMLElementCollection;

        //            var firstP = aChildList.item(0) as HTMLParaElementClass;
        //            var secondP = aChildList.item(1) as HTMLParaElementClass;


        //            var firstPStr = firstP.innerHTML.Trim();
        //            var secondPStr = secondP.innerHTML.Trim();

        //            if (!priceDic.Keys.Contains(firstPStr))
        //            {
        //                priceDic.Add(firstPStr, secondPStr);
        //            }
        //            else
        //            {
        //                priceDic[firstPStr] = secondPStr;
        //            }
        //        }

        //    }

        //    var useTime = DateTime.Now - startTime;

        //}
    }
}
