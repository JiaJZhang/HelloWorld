﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace WinX.Web.Test
{
    [TestClass]
    public class ShellWindowsUnitTest
    {
        [TestMethod]
        public void StartTestMethod()
        {
            ShellWindows.Start(@"https://docs.microsoft.com/zh-cn/windows/desktop/api/docobj/ne-docobj-olecmdid");

        }
    }
}
