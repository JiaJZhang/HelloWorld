using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using System;

namespace CarryBanDai.ViewModel
{
    /// <summary>
    /// This class contains properties that the main View can data bind to.
    /// <para>
    /// Use the <strong>mvvminpc</strong> snippet to add bindable properties to this ViewModel.
    /// </para>
    /// <para>
    /// You can also use Blend to data bind with the tool's support.
    /// </para>
    /// <para>
    /// See http://www.galasoft.ch/mvvm
    /// </para>
    /// </summary>
    public class MainViewModel : ViewModelBase
    {
        /// <summary>
        /// Initializes a new instance of the MainViewModel class.
        /// </summary>
        public MainViewModel()
        {
            ////if (IsInDesignMode)
            ////{
            ////    // Code runs in Blend --> create design time data.
            ////}
            ////else
            ////{
            ////    // Code runs "for real"
            ////}
        }


        private bool newProdPageRoot()
        {
            bool result = true;

            while (result)
            {
                try
                {
                    var newProdPage = new WinX.BanDai.TaoBao.NewProd();

                    if (newProdPage.WaitForLoadComplete(300))
                    {
                        if (newProdPage.divHas15min != null && newProdPage.divHas15min.Count > 0)
                        {
                            newProdPage.GetWindow().Refresh();
                        }
                        else if (newProdPage.divSoldOut != null && newProdPage.divSoldOut.Count > 0)
                        {
                            GalaSoft.MvvmLight.Messaging.Messenger.Default.Send<string>(" ������ �� лл��");

                            result = false;
                            break;
                        }
                        else if (newProdPage.aBuyNow != null)
                        {
                            //if(newProdPage.ulColorCatory != null && newProdPage.ulColorCatory.Count > 0)
                            //{
                            //    var liColorCatoryList  = newProdPage.ulColorCatory[0].children as mshtml.IHTMLElementCollection;

                            //    if (liColorCatoryList != null && liColorCatoryList.length > 0)
                            //    {
                            //        var liColorCatoryObj = liColorCatoryList.item(0) as mshtml.HTMLLIElementClass;

                            //        var aColorCatoryList = liColorCatoryObj.children as mshtml.IHTMLElementCollection;

                            //        if (aColorCatoryList != null && aColorCatoryList.length > 0)
                            //        {
                            //            var aColorCatoryObj = aColorCatoryList.item(0) as mshtml.HTMLAnchorElementClass;

                            //            if (aColorCatoryObj != null )
                            //            {
                            //                aColorCatoryObj.click();
                            //            }
                            //        }
                            //    }
                            //}

                            newProdPage.aBuyNow.click();
                            result = false;
                            break;
                        }
                    }
                }
                catch(Exception ex)
                {
                    result = true;
                }
            }
            return result;
        }

        private bool submitOrderRoot()
        {
            var result = true;

            while (result)
            {
                try
                {
                    var submitOrderPage = new WinX.BanDai.TaoBao.SubmitOrder();

                    if (submitOrderPage.WaitForLoadComplete(300))
                    {
                        if (submitOrderPage.aPushOrder != null && submitOrderPage.aPushOrder.Count < 1)
                        {
                            submitOrderPage.GetWindow().Refresh();

                            var retryPopupWin = new WinX.BanDai.IEBrowserPopup.RetryPopup();

                            if (retryPopupWin.WaitForCreate(30))
                            {
                                retryPopupWin.btnRetry.Click();
                            }
                        }
                        else
                        {
                            submitOrderPage.aPushOrder[0].click();
                            result = true;
                            break;
                        }
                    }
                }
                catch (Exception ex)
                {
                    result = true;
                }
            }
            return result;
        }


        public RelayCommand CarryCommand
        {
            get
            {
                return new RelayCommand(() =>
                {
                    var result = false;

                 

                        result = newProdPageRoot();

                        result = submitOrderRoot();
                               
                        GalaSoft.MvvmLight.Messaging.Messenger.Default.Send<string>(" �� �� лл��");
                  

                });
            }
        }
    }
}