﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace WinX.Windows.Test
{
    [TestClass]
    public class CalUnitTest
    {
        [TestMethod]
        public void CloseAboutMethod1()
        {
            var winAboutCal = new DadaTest.WinTest.WinAboutCal();

            if(winAboutCal.WaitForCreate(30))
            {
                winAboutCal.btnOk.Click();
            }


        }


        [TestMethod]
        public void Clickbtn1Method1()
        {
            var winCal = new DadaTest.WinTest.WinCal();
            
            if (winCal.WaitForCreate(30))
            {
                winCal.btn1.Click();
            }
        }
    }
}
