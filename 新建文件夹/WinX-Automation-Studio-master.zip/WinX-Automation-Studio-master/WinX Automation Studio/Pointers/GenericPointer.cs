﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace WinX_Automation_Studio
{
    public partial class GenericPointer : UserControl
    {
        public event EventHandler ActiveWindowChanged;
        public event EventHandler ActiveWindowSelected;
        private bool searching = false;
        public System.Windows.Automation.AutomationElement SelectedElement;
        public System.Drawing.Bitmap SelectedElementBitMap;

        public IntPtr TargetWindowHandle = IntPtr.Zero;

        [DllImport("user32.dll")]
        static extern IntPtr WindowFromPoint(POINT p);

        [DllImport("user32.dll")]
        static extern IntPtr ChildWindowFromPointEx(IntPtr hWndParent, POINT pt, uint uFlags);


        [StructLayout(LayoutKind.Sequential)]
        public struct POINT
        {
            public int X
            {
                get;
                set;
            }

            public int Y
            {
                get;
                set;
            }

            public POINT toPoint()
            {
                return new POINT(X, Y);
            }

            public static POINT FromPoint(System.Drawing.Point pt)
            {
                return new POINT(pt.X, pt.Y);
            }


            public POINT(int x, int y)
            {
                this.X = x;
                this.Y = y;

            }

            public static bool operator ==(POINT p1, POINT p2)
            {
                return p1.X == p2.X && p1.Y == p2.Y;

            }

            public static bool operator !=(POINT p1, POINT p2)
            {
                return p1.X != p2.X || p1.Y != p2.Y;
            }

            public override bool Equals(object obj)
            {
                if (ReferenceEquals(obj, null))
                    return false;

                if (!obj.GetType().Equals(typeof(object)))
                {
                    return false;
                }

                POINT other = (POINT)obj;
                var result = false;
                if (other != null)
                {
                    result = other.X == X && other.Y == Y;
                }
                return result;
            }


            public override int GetHashCode()
            {
                return X | Y;
            }

            public override string ToString()
            {
                return string.Format("{{X={0},Y={1}}}", X, Y);
            }
        }


        public GenericPointer()
        {
            InitializeComponent();
        }

        #region Start/Stop Search
        public void StartSearch()
        {
            searching = true;
            Cursor.Current = new Cursor(GetType().Assembly.GetManifestResourceStream(GetType().Assembly.GetName().Name.Replace(" ", "_") + ".Icons.Eye.cur"));
            Capture = true;

            this.MouseMove += GenericPointer_MouseMove;
            this.MouseUp += GenericPointer_MouseUp;
        }

        public void EndSearch()
        {
            this.MouseMove -= GenericPointer_MouseMove;
            this.MouseUp -= GenericPointer_MouseUp;

            Capture = false;
            searching = false;
            Cursor.Current = Cursors.Default;
            
            if (ActiveWindowSelected != null)
            {
                ActiveWindowSelected(this, EventArgs.Empty);
            }
        }
        #endregion


        private void GenericPointer_MouseDown(object sender, MouseEventArgs e)
        {
            if(!searching)
            {
                StartSearch();
            }
        }

        private void GenericPointer_MouseMove(object sender, MouseEventArgs e)
        {
            if(!searching)
            {
                EndSearch();
            }

            try
            {
                var windowPoint = POINT.FromPoint(this.PointToScreen(new System.Drawing.Point(e.X, e.Y)));
                var foundEle = System.Windows.Automation.AutomationElement.FromPoint(new System.Windows.Point(windowPoint.X, windowPoint.Y));

                if(foundEle != null && foundEle != SelectedElement)
                {
                    UnHighlight(this.SelectedElement);

                    this.SelectedElement = foundEle;

                    if(this.SelectedElement != null)
                    {
                        Highlight(this.SelectedElement);
                    }
                    InvokeActiveWindowChange();
                }
            }
            catch(Exception ex)
            {

            }
        }

        private void Highlight(System.Windows.Automation.AutomationElement ele)
        {
            if(ele != null && ele.Current.NativeWindowHandle != IntPtr.Zero.ToInt32())
            {
                WinX.Core.Win32Helper.Highlight(new IntPtr(ele.Current.NativeWindowHandle), Brushes.Red);
            }
        }


        private void GenericPointer_MouseUp(object sender, MouseEventArgs e)
        {
            EndSearch();
        }


        private void UnHighlight(System.Windows.Automation.AutomationElement ele)
        {
            if (ele != null && ele.Current.NativeWindowHandle != IntPtr.Zero.ToInt32())
            {
                WinX.Core.Win32Helper.UnHighlight(new IntPtr(ele.Current.NativeWindowHandle));
            }
        }

        private void InvokeActiveWindowChange()
        {
            if (ActiveWindowChanged != null)
            {
                ActiveWindowChanged(this, EventArgs.Empty);
            }
        }
    }
}
