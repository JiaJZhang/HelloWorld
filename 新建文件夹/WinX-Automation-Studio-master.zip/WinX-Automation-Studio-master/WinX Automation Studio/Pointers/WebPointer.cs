﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using mshtml;
using System.Runtime.InteropServices;

namespace WinX_Automation_Studio
{
    [DefaultEvent("OnElementSelected")]
    public partial class WebPointer : UserControl
    {
        private int targetDocHashcode = 0;
        private System.Windows.Automation.AutomationElement SelectedElement = null;
        public delegate void ElementSelectedHandle(IHTMLElement raw);
        public delegate void ElementMouseHover(IHTMLEventObj ele);

        public event ElementSelectedHandle ElementSelected;
        private Dictionary<HtmlElement, string> elementStyles = new Dictionary<HtmlElement, string>();

        private void OnElementSelected(IHTMLElement raw)
        {
            if (ElementSelected != null)
            {
                ElementSelected(raw);
            }
        }

        private bool IsCapturing = false;
        private HTMLDocumentClass tmpIeDOM = null;
        private WinX.Web.HTMLDocumentEventHelper handler = null;

        [StructLayout(LayoutKind.Sequential)]
        public struct POINT
        {
            public int X
            {
                get;
                set;
            }

            public int Y
            {
                get;
                set;
            }

            public POINT toPoint()
            {
                return new POINT(X, Y);
            }

            public static POINT FromPoint(System.Drawing.Point pt)
            {
                return new POINT(pt.X, pt.Y);
            }


            public POINT(int x, int y)
            {
                this.X = x;
                this.Y = y;

            }

            public static bool operator ==(POINT p1, POINT p2)
            {
                return p1.X == p2.X && p1.Y == p2.Y;

            }

            public static bool operator !=(POINT p1, POINT p2)
            {
                return p1.X != p2.X || p1.Y != p2.Y;
            }

            public override bool Equals(object obj)
            {
                if (ReferenceEquals(obj, null))
                    return false;

                if (!obj.GetType().Equals(typeof(object)))
                {
                    return false;
                }

                POINT other = (POINT)obj;
                var result = false;
                if (other != null)
                {
                    result = other.X == X && other.Y == Y;
                }
                return result;
            }


            public override int GetHashCode()
            {
                return X | Y;
            }

            public override string ToString()
            {
                return string.Format("{{X={0},Y={1}}}", X, Y);
            }
        }

        public void Start(HTMLDocumentClass ieDOM)
        {
            try
            {
                if(ieDOM != null)
                {
                    try
                    {
                        this.targetDocHashcode = ieDOM.GetHashCode();
                        if(handler != null)
                        {
                            handler = null;
                            Marshal.FinalReleaseComObject(handler);
                        }
                    }
                    catch(Exception e1)
                    {

                    }

                    handler = null;
                    tmpIeDOM = null;
                    tmpIeDOM = ieDOM;

                    handler = new WinX.Web.HTMLDocumentEventHelper(tmpIeDOM);
                    this.handler.MouseOver += Handler_MouseOver;


                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public WebPointer()
        {
            InitializeComponent();
        }

        private void WindowFinder_MouseDown(object sender, MouseEventArgs e)
        {
            IsCapturing = true;
            Cursor.Current = new Cursor(GetType().Assembly.GetManifestResourceStream(GetType().Assembly.GetName().Name.Replace(" ", "_") + ".Icons.Eye.cur"));
            this.MouseUp += WebPointer_MouseUp;

        }

        private void WebPointer_MouseUp(object sender, MouseEventArgs e)
        {
            this.MouseUp -= WebPointer_MouseUp;
            Cursor.Current = Cursors.Default;
        }
        

        private void WindowFinder_MouseMove(object sender, MouseEventArgs e)
        {
            try
            {
                var windlowPoint = POINT.FromPoint(this.PointToScreen(new System.Drawing.Point(e.X, e.Y)));
                var foundEle = System.Windows.Automation.AutomationElement.FromPoint(new System.Windows.Point(e.X, e.Y));

                if (foundEle != null && foundEle != this.SelectedElement)
                {
                    this.SelectedElement = foundEle;
                }
            }
            catch (Exception ex)
            {

            }
        }
        private void Handler_MouseOver(IHTMLEventObj obj)
        {
            try
            {
                var updateInfo = new ElementMouseHover(Element_MouseHover);
                this.Invoke(updateInfo, obj);

                obj.cancelBubble = false;
                obj.returnValue = true;
            }
            catch(Exception ex)
            {
                WinX.Core.Logger.Write(ex, "There was error while trying to read web element on MouseOver event [WebPointer.doc_MouseOver()].");
            }
        }

        private void Element_MouseHover(IHTMLEventObj pEvtObj)
        {
            if(IsCapturing)
            {
                OnElementSelected(pEvtObj.srcElement);
                IsCapturing = false;
            }
        }
    }
}
