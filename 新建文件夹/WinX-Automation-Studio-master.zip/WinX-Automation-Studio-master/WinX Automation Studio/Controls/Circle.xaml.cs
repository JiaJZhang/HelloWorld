﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WinX_Automation_Studio
{
    /// <summary>
    /// Circle.xaml 的交互逻辑
    /// </summary>
    public partial class Circle : UserControl
    {
        protected bool isDragging = false;
        public Point clickPostition;

        public static TranslateTransform ResultTranform
        {
            get;
            set;
        }


        public Circle()
        {
            InitializeComponent();

            this.MouseLeftButtonDown += Circle_MouseLeftButtonDown;
            this.MouseLeftButtonUp += Circle_MouseLeftButtonUp;
            this.MouseMove += Circle_MouseMove; 
        }


        private void Circle_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            isDragging = true;
            var draggableControl = sender as UserControl;
            clickPostition = e.GetPosition(this);
            draggableControl.CaptureMouse();
        }

        private void Circle_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            isDragging = false;
            var draggableControl = sender as UserControl;
            draggableControl.ReleaseMouseCapture();
        }

        private void Circle_MouseMove(object sender, MouseEventArgs e)
        {
            var draggableControl = sender as UserControl;

            if (isDragging && draggableControl != null)
            {
                var currentPosition = e.GetPosition(this.Parent as UIElement);
                var transform = draggableControl.RenderTransform as TranslateTransform;
                if (transform == null)
                {
                    transform = new TranslateTransform();
                    draggableControl.RenderTransform = transform;
                }

                transform.X = currentPosition.X - clickPostition.X;
                transform.Y = currentPosition.Y - clickPostition.Y;

                ResultTranform = transform;
            }
        }
    }
}
