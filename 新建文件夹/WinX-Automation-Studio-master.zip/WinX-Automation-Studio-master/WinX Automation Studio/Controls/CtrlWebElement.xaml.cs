﻿using mshtml;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WinX.Core;
using WinX.StudioLib;
using WinX.Web;

namespace WinX_Automation_Studio
{
    /// <summary>
    /// CtrlWebElement.xaml 的交互逻辑
    /// </summary>
    public partial class CtrlWebElement : UserControl
    {
        public CtrlWebElement()
        {
            InitializeComponent();

            SelectedMatchRuleHost.Child = new System.Windows.Forms.PropertyGrid();
            SelectedTargetHost.Child = new System.Windows.Forms.PropertyGrid();

            WinX.Core.Logger.Write(this.GetType().Name + " has been loaded successfully.");
        }
        private void CtrlWebDocument_Loaded(object sender, RoutedEventArgs e)
        {
            BindMatchRules();
        }

        private void BindMatchRules()
        {
            try
            {
                cmbAvailableMatchRules.ItemsSource = null;
                var element = this.DataContext as WinX.Web.WebElement;
                var existingRules = lstDocMatchRules.ItemsSource as ObservableCollection<MatchRule>;
                var possibleRule = WinX.Core.ReflectionHelper.FindDerivedTypes(typeof(WinX.Web.WebElement).Assembly, typeof(WinX.Core.MatchRule)).Select(t => t.Name).ToList();
                var filteredRules = new List<string>();
                if(existingRules != null && existingRules.Count() > 0)
                {
                    filteredRules = possibleRule.Where(m => !m.Equals(typeof(WinX.Web.TitleMatchRule)) && !m.Equals(typeof(WinX.Web.UrlMatchRule)) && !existingRules.Select(r => r.GetType().Name).Contains(m)).ToList();
                }
                else
                {
                    filteredRules = possibleRule;
                }

                if(filteredRules != null && filteredRules.Count() > 0)
                {
                    cmbAvailableMatchRules.ItemsSource = filteredRules;
                    btnAddMatchRule.IsEnabled = true;
                    cmbAvailableMatchRules.IsEnabled = true;
                }
                else
                {
                    btnAddMatchRule.IsEnabled = false;
                    cmbAvailableMatchRules.IsEnabled = false;
                }
            }
            catch(Exception ex)
            {
                WinX.Core.Logger.Write(ex, "There was an error while trying to bind match rules.");
            }
        }

        private void lstDocMatchRules_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if(lstDocMatchRules.SelectedItem != null)
                {
                    var propGrid = SelectedMatchRuleHost.Child as System.Windows.Forms.PropertyGrid;
                    propGrid.SelectedObject = lstDocMatchRules.SelectedItem;
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void lstTargetMatches_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (lstTargetMatches.SelectedItem != null)
                {
                    var propGrid = SelectedTargetHost.Child as System.Windows.Forms.PropertyGrid;
                    propGrid.SelectedObject = RulesEngine.GetRawWebElement(lstTargetMatches.SelectedItem as IHTMLElement);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CtxDeleteRule_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if(this.DataContext != null)
                {
                    var screen = this.DataContext as WinX.Web.WebElement;
                    screen.MatchRules.Remove(lstDocMatchRules.SelectedItem as MatchRule);
                    BindMatchRules();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnAddMatchRule_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (cmbAvailableMatchRules.SelectedItem != null)
                {
                    var element = this.DataContext as WinX.Web.WebElement;
                    if (element != null)
                    {
                        WinX.Core.MatchRule rule = null;
                        RawWebElement target = null;

                        var propGrid = SelectedTargetHost.Child as System.Windows.Forms.PropertyGrid;
                        if (propGrid.SelectedObject != null)
                        {
                            target = propGrid.SelectedObject as RawWebElement;
                        }

                        switch (cmbAvailableMatchRules.SelectedItem.ToString())
                        {
                            case "IDMatchRule":
                                var id = string.Empty;
                                if (target != null)
                                {
                                    var idAtt = target.Attributes.Where(m => m.Name == "id").FirstOrDefault();
                                    if (idAtt != null)
                                    {
                                        id = idAtt.Value;
                                    }
                                }
                                rule = new WinX.Web.IDMatchRule(id);
                                break;
                            case "NameMatchRule":
                                var name = string.Empty;
                                if (target != null)
                                {
                                    var nameAtt = target.Attributes.Where(m => m.Name == "name").FirstOrDefault();
                                    if (nameAtt != null)
                                    {
                                        name = nameAtt.Value;
                                    }
                                }
                                rule = new WinX.Web.NameMatchRule(name);
                                break;
                            case "TagMatchRule":
                                rule = new WinX.Web.TagMatchRule(target != null ? target.Tag : "<??>");

                                break;
                            case "InnerTextMatchRule":
                                rule = new WinX.Web.InnerTextMatchRule(target != null ? target.InnerText : string.Empty);
                                break;
                            case "InnerHtmlMatchRule":
                                rule = new WinX.Web.InnerHtmlMatchRule(target != null ? target.InnerText : string.Empty);
                                break;
                            case "OuterTextMatchRule":
                                rule = new WinX.Web.OuterTextMatchRule(target != null ? target.InnerText : string.Empty);
                                break;
                            case "OuterHtmlMatchRule":
                                rule = new WinX.Web.OuterHtmlMatchRule(target != null ? target.InnerText : string.Empty);
                                break;
                            case "AttributeMatchRule":
                                rule = new WinX.Web.AttributeMatchRule("<name>", "value");
                                break;
                            case "IndexMatchRule":
                                rule = new WinX.Web.IndexMatchRule(target != null ? target.Index : 0);
                                break;
                        }

                        if (rule != null)
                        {
                            element.MatchRules.Add(rule);
                            BindMatchRules();
                        }
                    }
                }
                cmbAvailableMatchRules.SelectedItem = null;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CtxElementHighLight_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var htmlEle = lstTargetMatches.SelectedItem as IHTMLElement;
                if (htmlEle != null)
                {
                    htmlEle.Highlight();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CtxElementClick_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var htmlEle = lstTargetMatches.SelectedItem as IHTMLElement;
                if (htmlEle != null)
                {
                    htmlEle.click();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CtxElementSetText_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var htmlEle = lstTargetMatches.SelectedItem as IHTMLInputElement;
                if (htmlEle != null)
                {
                    var inputDialog = new InputTextDialog();
                    inputDialog.Owner = WinX_Automation_Studio.App.Current.MainWindow;
                    if(inputDialog.ShowDialog() == true)
                    {
                        htmlEle.value = inputDialog.txtInput.Text;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CtxElementGetText_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                dynamic htmlEle = lstTargetMatches.SelectedItem as IHTMLInputElement;
                if (htmlEle != null && htmlEle.isTextEdit)
                {
                    var inputDialog = new InputTextDialog();
                    inputDialog.Owner = WinX_Automation_Studio.App.Current.MainWindow;
                    inputDialog.txtInput.Text = htmlEle.value;
                    inputDialog.ShowDialog();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CtxSelectByText_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var htmlEle = lstTargetMatches.SelectedItem as HTMLSelectElementClass;
                if (htmlEle != null)
                {
                    var inputDialog = new InputTextDialog();
                    inputDialog.Owner = WinX_Automation_Studio.App.Current.MainWindow;
                    if (inputDialog.ShowDialog() == true)
                    {
                        htmlEle.SelectByText(inputDialog.txtInput.Text);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }

        }
        private void CtxSelectByValue_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var htmlEle = lstTargetMatches.SelectedItem as HTMLSelectElementClass;
                if (htmlEle != null)
                {
                    var inputDialog = new InputTextDialog();
                    inputDialog.Owner = WinX_Automation_Studio.App.Current.MainWindow;
                    if (inputDialog.ShowDialog() == true)
                    {
                        htmlEle.SelectByValue(inputDialog.txtInput.Text);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        

        private void CtxGetSelectByText_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var htmlEle = lstTargetMatches.SelectedItem as HTMLSelectElementClass;
                if (htmlEle != null)
                {
                    var inputDialog = new InputTextDialog();
                    inputDialog.Owner = WinX_Automation_Studio.App.Current.MainWindow;
                    inputDialog.txtInput.Text = htmlEle.GetSelectedText();
                    inputDialog.ShowDialog();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CtxGetSelectByValue_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var htmlEle = lstTargetMatches.SelectedItem as HTMLSelectElementClass;
                if (htmlEle != null)
                {
                    var inputDialog = new InputTextDialog();
                    inputDialog.Owner = WinX_Automation_Studio.App.Current.MainWindow;
                    inputDialog.txtInput.Text = htmlEle.GetSelectedValue();
                    inputDialog.ShowDialog();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CtxGetSelectByIndex_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var htmlEle = lstTargetMatches.SelectedItem as HTMLSelectElementClass;
                if (htmlEle != null)
                {
                    var inputDialog = new InputTextDialog();
                    inputDialog.Owner = WinX_Automation_Studio.App.Current.MainWindow;
                    inputDialog.txtInput.Text = htmlEle.GetSelectedIndex();
                    inputDialog.ShowDialog();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
