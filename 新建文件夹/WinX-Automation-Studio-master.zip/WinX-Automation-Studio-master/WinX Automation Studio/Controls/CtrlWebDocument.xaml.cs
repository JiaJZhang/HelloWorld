﻿using mshtml;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WinX.Core;
using WinX.Web;

namespace WinX_Automation_Studio
{
    /// <summary>
    /// CtrlWebDocument.xaml 的交互逻辑
    /// </summary>
    public partial class CtrlWebDocument : UserControl
    {
        private System.Windows.Controls.TreeViewItem curTreeViewItem = null;
        public WinX.Core.Application App
        {
            get; set;
        }


        public CtrlWebDocument()
        {
            InitializeComponent();
            SelectedMatchRuleHost.Child = new System.Windows.Forms.PropertyGrid();
            SelectedTargetHost.Child = new System.Windows.Forms.PropertyGrid();
            WinX.Core.Logger.Write(this.GetType() + " has been loaded successfully.");
        }


        private void CtrlWebDocument_Loaded(object sender, RoutedEventArgs e)
        {
            this.btnRefresh_Click(null, null);
        }


        private void lstDocMatchRules_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                var lstBox = sender as ListBox;
                if (lstBox.SelectedItem != null)
                {
                    var propGrid = SelectedMatchRuleHost.Child as System.Windows.Forms.PropertyGrid;
                    propGrid.SelectedObject = lstBox.SelectedItem;
                }
            }
            catch (Exception ex)
            {
                WinX.Core.Logger.Write(ex, "There was an error while enumerating match rule properties.");
            }
        }

        private void lstTargetMatches_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            if(lstTargetMatches.SelectedItem != null && lstTargetMatches.SelectedItem.GetType().BaseType.Equals(typeof(RawDocument)))
            {
                try
                {
                    var propGrid = SelectedTargetHost.Child as System.Windows.Forms.PropertyGrid;
                    var ieDoc = lstTargetMatches.SelectedItem as RawDocument;
                    if (ieDoc != null)
                    {
                        propGrid.SelectedObject = ieDoc;
                        var bgworker = new BackgroundWorker();

                        bgworker.DoWork += (s1, e1) =>
                        {
                            dynamic e2 = e1.Argument;
                            MatchEngine.PeformScreenMatch(e2[1] as WinX.Core.Screen, e2[0], true);
                        };
                        bgworker.RunWorkerCompleted += (s1, e1) =>
                        {
                            TargetWinProgress.Visibility = Visibility.Collapsed;
                        };
                        TargetWinProgress.Visibility = Visibility.Visible;

                        bgworker.RunWorkerAsync(new object[] { ieDoc.Document, this.DataContext });
                    }
                }
                catch(Exception ex)
                {
                    TargetWinProgress.Visibility = Visibility.Collapsed;
                    WinX.Core.Logger.Write(ex, "There was an error while refresh elements.");
                }
            }
        }

        private void CtxDeleteRule_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (this.DataContext != null)
                {
                    var propGrid = this.SelectedMatchRuleHost.Child as System.Windows.Forms.PropertyGrid;

                    if (propGrid.SelectedObject != null)
                    {
                        var screen = this.DataContext as WebScreen;

                        var rule = propGrid.SelectedObject as MatchRule;

                        if (screen.MatchRules != null && screen.MatchRules.Count() > 0 && rule != null)
                        {
                            screen.MatchRules.Remove(rule);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                WinX.Core.Logger.Write(ex, "There was an error while trying to delete match rule.");
            }
        }

        private void btnRefresh_Click(object sender, RoutedEventArgs e)
        {
            TargetWinProgress.Visibility = Visibility.Visible;
            lstTargetMatches.ItemsSource = null;
            try
            {
                var bgworker = new BackgroundWorker();

                bgworker.DoWork += (s1, e1) =>
                {
                    e1.Result = WinX.Web.MatchEngine.GetAllDocuments();
                };
                bgworker.RunWorkerCompleted += (s1, e1) =>
                {
                    lstTargetMatches.ItemsSource = e1.Result as IEnumerable<RawDocument>;
                    TargetWinProgress.Visibility = Visibility.Collapsed;
                };

                bgworker.RunWorkerAsync(this.DataContext);
            }
            catch (Exception ex)
            {
                WinX.Core.Logger.Write(ex, "There was an error while trying to enumerate available websites.");
            }
        }

        private void CtxAddMatchRules_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (this.DataContext != null && lstTargetMatches.SelectedItem != null)
                {
                    var screen = this.DataContext as WebScreen;
                    var rulesDialog = new MatchRulesPrompt();
                    var doc = lstTargetMatches.SelectedItem as RawDocument;

                    var docMatchRule = new DocumentMatchRule(new WinX.Web.TitleMatchRule(doc.Title), new WinX.Web.UrlMatchRule(doc.Url));


                    if (doc.IsFrame)
                    {
                        while (doc.Parent != null)
                        {
                            var parent = new DocumentMatchRule(new WinX.Web.TitleMatchRule(doc.Parent.Title), new WinX.Web.UrlMatchRule(doc.Url));
                            parent.Child = docMatchRule;
                            docMatchRule = parent;
                            doc = doc.Parent;
                        }
                    }

                    screen.MatchRules.Clear();
                    screen.MatchRules.Add(docMatchRule);
                }
            }
            catch (Exception ex)
            {
                WinX.Core.Logger.Write(ex, "There was an error while trying to add match rules to web document.");
            }
        }

        private void CtxAddElement_Click(object sender, RoutedEventArgs e)
        {
            try {
                if (lstTargetMatches.SelectedItem != null)
                {
                    var screen = this.DataContext as WinX.Web.WebScreen;
                    if (screen != null)
                    {
                        var doc = ((RawDocument)lstTargetMatches.SelectedItem).Document as mshtml.HTMLDocumentClass;
                        if (doc != null)
                        {
                            var webEleDialog = new WebElementCaptureDialog(doc, screen);
                            webEleDialog.Owner = WinX_Automation_Studio.App.Current.MainWindow;
                            webEleDialog.Topmost = true;
                            WinX_Automation_Studio.App.Current.MainWindow.WindowState = WindowState.Minimized;
                            webEleDialog.ShowDialog();
                            WinX_Automation_Studio.App.Current.MainWindow.WindowState = WindowState.Normal;
                        }

                    }
                }
            }
            catch(Exception ex)
            {
                WinX.Core.Logger.Write(ex, "There was an error while trying to add element.");
            }
        }


        private void CtxHighlight_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if(lstTargetMatches.SelectedItem != null)
                {
                    var rawDoc = lstTargetMatches.SelectedItem as RawWebDocument;
                    if(rawDoc != null)
                    {
                        rawDoc.BringWindowTop();
                    }
                }
            }
            catch(Exception ex)
            {
                WinX.Core.Logger.Write(ex, "There was an error while trying to hightlight element.");
            }

        }

        private void CtxAddAsScreen_Click(object sender, RoutedEventArgs e)
        {

        }

        private void CtxViewHtml_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if(lstTargetMatches.SelectedItem != null)
                {
                    var doc = ((RawWebDocument)lstTargetMatches.SelectedItem).Document as HTMLDocumentClass;
                    if(doc != null)
                    {
                        var msgBox = new MessageBoxDialog(doc.body.innerHTML);
                        msgBox.Owner = WinX_Automation_Studio.App.Current.MainWindow;
                        msgBox.ShowDialog();
                    }
                }
            }
            catch(Exception ex)
            {
                WinX.Core.Logger.Write(ex, "There was an error while trying to highlight element.");
            }
        }

        private void CtxExeJsScript_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (lstTargetMatches.SelectedItem != null)
                {
                    var doc = ((RawWebDocument)lstTargetMatches.SelectedItem).Document as HTMLDocumentClass;
                    if (doc != null)
                    {
                        var jsScriptDialog = new JavaScriptDialog();
                        jsScriptDialog.Owner = WinX_Automation_Studio.App.Current.MainWindow;
                        jsScriptDialog.DataContext = doc;
                        jsScriptDialog.ShowDialog();
                    }
                }
            }
            catch (Exception ex)
            {
                WinX.Core.Logger.Write(ex, "There was an error while trying to highlight element.");
            }
        }

        private void CtxPdfHighlight_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (lstTargetMatches.SelectedItem != null)
                {
                    var rawDoc = lstTargetMatches.SelectedItem as RawPdfDocument;
                    if(rawDoc != null)
                    {
                        rawDoc.BringWindowTop();
                    }
                }
            }
            catch (Exception ex)
            {
                WinX.Core.Logger.Write(ex, "There was an error while trying to highlight element.");
            }
        }

        private void CtxAddAsPdfScreen_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (lstTargetMatches.SelectedItem != null)
                {
                    var rawDoc = lstTargetMatches.SelectedItem as RawPdfDocument;
                    if (rawDoc != null)
                    {
                        var screen = new WebPdfScreen();
                        screen.MatchRules.Add(new WinX.Web.UrlMatchRule(rawDoc.Url));

                        var screenDialog = new NewScreen();
                        screenDialog.Screen = screen;
                        screenDialog.Owner = WinX_Automation_Studio.App.Current.MainWindow;
                        screenDialog.DataContext = this.App;
                        screenDialog.ShowDialog();
                    }
                }
            }
            catch (Exception ex)
            {
                WinX.Core.Logger.Write(ex, "There was an error while trying to highlight element.");
            }
        }

        private void CtxPdfAddPdfMatchRules_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (lstTargetMatches.SelectedItem != null)
                {
                    var rawDoc = lstTargetMatches.SelectedItem as RawPdfDocument;
                    if (rawDoc != null)
                    {
                        var screen = this.DataContext as WinX.Web.WebPdfScreen;
                        var rulesDialog = new MatchRulesPrompt();

                        screen.MatchRules.Clear();
                        screen.MatchRules.Add(new WinX.Web.UrlMatchRule(rawDoc.Url));
                    }
                }
            }
            catch (Exception ex)
            {
                WinX.Core.Logger.Write(ex, "There was an error while trying to highlight element.");
            }
        }

        private void CtxAddPdfPrintWithDialog_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (lstTargetMatches.SelectedItem != null)
                {
                    var rawDoc = lstTargetMatches.SelectedItem as WebPdfScreen;
                    if (rawDoc != null)
                    {
                        rawDoc.PrintWithDialog();
                    }
                }
            }
            catch (Exception ex)
            {
                WinX.Core.Logger.Write(ex, "There was an error while trying to highlight element.");
            }
        }

        private void CtxAddPdfPrint_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (lstTargetMatches.SelectedItem != null)
                {
                    var rawDoc = lstTargetMatches.SelectedItem as WebPdfScreen;
                    if (rawDoc != null)
                    {
                        rawDoc.Print();
                    }
                }
            }
            catch (Exception ex)
            {
                WinX.Core.Logger.Write(ex, "There was an error while trying to highlight element.");
            }
        }

        private void CtxAddPdfPrintAll_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (lstTargetMatches.SelectedItem != null)
                {
                    var rawDoc = lstTargetMatches.SelectedItem as WebPdfScreen;
                    if (rawDoc != null)
                    {
                        rawDoc.PrintAll();
                    }
                }
            }
            catch (Exception ex)
            {
                WinX.Core.Logger.Write(ex, "There was an error while trying to highlight element.");
            }
        }
        

    }
}
