﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WinX_Automation_Studio
{
    /// <summary>
    /// CtrlGenericWindow.xaml 的交互逻辑
    /// </summary>
    public partial class CtrlGenericWindow : UserControl
    {
        //private TreeViewItem curTreeViewItem = null;

        public CtrlGenericWindow()
        {
            InitializeComponent();

            SelectedMatchRuleHost.Child = new System.Windows.Forms.PropertyGrid();
            SelectedTargetHost.Child = new System.Windows.Forms.PropertyGrid();
            WinX.Core.Logger.Write(this.GetType().Name + " has been loaded successfully.");
        }

        private void CtrlGenericWindow_Loaded(object sender, RoutedEventArgs e)
        {
            this.btnRefresh_Click(null, null);
        }

        private void lstDocMatchRules_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (lstDocMatchRules.SelectedItem != null)
                {
                    var propGrid = SelectedMatchRuleHost.Child as System.Windows.Forms.PropertyGrid;
                    propGrid.SelectedObject = lstDocMatchRules.SelectedItem;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void lstTargetMatches_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            if(lstTargetMatches.SelectedItem != null)
            {
                try
                {
                    var propGrid = this.SelectedTargetHost.Child as System.Windows.Forms.PropertyGrid;
                    var window = lstTargetMatches.SelectedItem as WinX.Windows.RawWindow;
                    if(window != null)
                    {
                        propGrid.SelectedObject = window;
                        var bgWorker = new BackgroundWorker();
                        bgWorker.DoWork += (s1, e1) =>
                                                    {
                                                        try
                                                        {
                                                            dynamic e2 = e1.Argument;
                                                            var genericWindow = e2[1] as WinX.Windows.GenericWindow;
                                                            var rawWindow = e2[0] as WinX.Windows.RawWindow;
                                                            WinX.Windows.MatchEngine.PeformWindowMatch(genericWindow, rawWindow);
                                                        }
                                                        catch(Exception ex)
                                                        {

                                                        }
                                                    };
                        bgWorker.RunWorkerCompleted += (s1, e1) =>
                        {
                            TargetWinProgress.Visibility = Visibility.Collapsed;
                        };
                        TargetWinProgress.Visibility = Visibility.Visible;
                        bgWorker.RunWorkerAsync(new object[] { window, this.DataContext });
                    }  
                }
                catch(Exception ex)
                {
                    TargetWinProgress.Visibility = Visibility.Collapsed;
                    MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void CtxDeleteRule_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (this.DataContext != null)
                {
                    var screen = this.DataContext as WinX.Windows.GenericWindow;
                    screen.MatchRules.Remove(lstDocMatchRules.SelectedItem as WinX.Core.MatchRule);
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnRefresh_Click(object sender, RoutedEventArgs e)
        {
            TargetWinProgress.Visibility = Visibility.Visible;
            lstTargetMatches.ItemsSource = null;

            try
            {
                var bgWorker = new BackgroundWorker();
                bgWorker.DoWork += (s1, e1) =>
                {
                    try
                    {
                        var screen = e1.Argument as WinX.Windows.GenericWindow;
                        var lstMatches = WinX.Windows.WindowsHelper.GetAllWindows();
                        e1.Result = lstMatches;
                    }
                    catch (Exception ex)
                    {

                    }
                };
                bgWorker.RunWorkerCompleted += (s1, e1) =>
                {
                    lstTargetMatches.ItemsSource = e1.Result as List<WinX.Windows.RawWindow>;
                    TargetWinProgress.Visibility = Visibility.Collapsed;
                };

                bgWorker.RunWorkerAsync(this.DataContext);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CtxAddMatchRules_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (this.DataContext != null && lstTargetMatches.SelectedItem != null)
                {
                    var screen = this.DataContext as WinX.Windows.GenericWindow;
                    var rulesDialog = new MatchRulesPrompt();
                    var window = lstTargetMatches.SelectedItem as WinX.Windows.RawWindow;

                    var possibleRules = new List<WinX.Core.MatchRule>();

                    if (!string.IsNullOrEmpty(window.Title))
                    {
                        possibleRules.Add(new WinX.Windows.WindowTitleMatchRule(window.Title));
                    }

                    if (window.Parent != null && !string.IsNullOrEmpty(window.Parent.Title))
                    {
                        possibleRules.Add(new WinX.Windows.ParentWindowTitleMatchRule(window.Parent.Title));

                        if (window.Parent.Parent != null && !string.IsNullOrEmpty(window.Parent.Parent.Title))
                        {
                            possibleRules.Add(new WinX.Windows.GrandParentWindowTitleMatchRule(window.Parent.Parent.Title));
                        }
                    }

                    if(!string.IsNullOrEmpty(window.Class))
                    {
                        possibleRules.Add(new WinX.Windows.ControlClassMatchRule(window.Class));
                    }

                    if (!string.IsNullOrEmpty(window.ProcessName))
                    {
                        possibleRules.Add(new WinX.Windows.ProcessNameMatchRule(window.ProcessName));
                    }

                    var existingRules= lstDocMatchRules.ItemsSource as ObservableCollection<WinX.Core.MatchRule>;
                    rulesDialog.lstMatchRules.ItemsSource = possibleRules.Where(r => !existingRules.Select(er => er.GetType()).ToList().Contains(r.GetType()));
                    if(rulesDialog.ShowDialog() == true)
                    {
                        foreach(WinX.Core.MatchRule rule in rulesDialog.lstMatchRules.SelectedItems)
                        {
                            screen.MatchRules.Add(rule);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CtxAddElement_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if(lstTargetMatches.SelectedItem != null)
                {
                    var selectRawWindow = lstTargetMatches.SelectedItem as WinX.Windows.RawWindow;
                    var screen = this.DataContext as WinX.Windows.GenericWindow;
                    var winEleDialog = new GenericElementCaptureDialog(selectRawWindow.Handler, screen)
                    {
                        Owner = App.Current.MainWindow,
                        Topmost = true
                    };
                    App.Current.MainWindow.WindowState = WindowState.Minimized;
                    winEleDialog.ShowDialog();

                    App.Current.MainWindow.WindowState = WindowState.Normal;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CtxVisualElement_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (lstTargetMatches.SelectedItem != null)
                {
                    var selectRawWindow = lstTargetMatches.SelectedItem as WinX.Windows.RawWindow;
                    var screen = this.DataContext as WinX.Windows.GenericWindow;

                    var hotAreaCount = screen.Fields.Where(m => m.Name.StartsWith("HotArea")).Count();

                    var newVisualEle = new WinX.Windows.VisualElement()
                    {
                        ID = Guid.NewGuid(),
                        ElementType = "WinX.Windows.VisualElement",
                        Name = "HotArea_" + (hotAreaCount + 1),
                        Description = string.Empty,
                        ScreenID = screen.ID,
                        Status = true,
                        ApplicationID = screen.ApplicationID,
                    };

                    var visualEleDialog = new CtrlVisualElementDialog(newVisualEle, screen)
                    {
                        Owner = App.Current.MainWindow,
                        Topmost = true,
                    };

                    App.Current.MainWindow.WindowState = WindowState.Minimized;

                    visualEleDialog.ShowDialog();
                    
                    App.Current.MainWindow.WindowState = WindowState.Normal;
                }
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CtxFocus_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (lstTargetMatches.SelectedItem != null)
                {
                    var selectRawWindow = lstTargetMatches.SelectedItem as WinX.Windows.RawWindow;
                    if (selectRawWindow != null)
                    {
                        WinX.Windows.WindowsHelper.SetFocus(selectRawWindow.Handler);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CtxSendKeys_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (lstTargetMatches.SelectedItem != null)
                {
                    var selectRawWindow = lstTargetMatches.SelectedItem as WinX.Windows.RawWindow;
                    if (selectRawWindow != null)
                    {
                        var inputDialog = new InputTextDialog()
                        {
                            Owner = App.Current.MainWindow,
                        };
                        if (inputDialog.ShowDialog() == true)
                        {
                            WinX.Windows.WindowsHelper.SendKeys(selectRawWindow.Handler, inputDialog.txtInput.Text);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CtxSendKeysWait_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (lstTargetMatches.SelectedItem != null)
                {
                    var selectRawWindow = lstTargetMatches.SelectedItem as WinX.Windows.RawWindow;
                    if (selectRawWindow != null)
                    {
                        var inputDialog = new InputTextDialog()
                        {
                            Owner = App.Current.MainWindow,
                        };
                        if (inputDialog.ShowDialog() == true)
                        {
                            WinX.Windows.WindowsHelper.SendKeysWait(selectRawWindow.Handler, inputDialog.txtInput.Text);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CtxMaximize_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (lstTargetMatches.SelectedItem != null)
                {
                    var selectRawWindow = lstTargetMatches.SelectedItem as WinX.Windows.RawWindow;
                    if (selectRawWindow != null)
                    {
                        var window = new WinX.Windows.Controls.Window(System.Windows.Automation.AutomationElement.FromHandle(selectRawWindow.Handler));
                        window.Maximize();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CtxMinimize_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (lstTargetMatches.SelectedItem != null)
                {
                    var selectRawWindow = lstTargetMatches.SelectedItem as WinX.Windows.RawWindow;
                    if (selectRawWindow != null)
                    {
                        var window = new WinX.Windows.Controls.Window(System.Windows.Automation.AutomationElement.FromHandle(selectRawWindow.Handler));
                        window.Minimize();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CtxRecoverNormal_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (lstTargetMatches.SelectedItem != null)
                {
                    var selectRawWindow = lstTargetMatches.SelectedItem as WinX.Windows.RawWindow;
                    if (selectRawWindow != null)
                    {
                        var window = new WinX.Windows.Controls.Window(System.Windows.Automation.AutomationElement.FromHandle(selectRawWindow.Handler));
                        window.RecoverNormal();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CtxClickLeft_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (lstTargetMatches.SelectedItem != null)
                {
                    var selectRawWindow = lstTargetMatches.SelectedItem as WinX.Windows.RawWindow;
                    if (selectRawWindow != null)
                    {
                        var window = new WinX.Windows.Controls.Window(System.Windows.Automation.AutomationElement.FromHandle(selectRawWindow.Handler));
                        window.ClickLeft();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CtxClickRight_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (lstTargetMatches.SelectedItem != null)
                {
                    var selectRawWindow = lstTargetMatches.SelectedItem as WinX.Windows.RawWindow;
                    if (selectRawWindow != null)
                    {
                        var window = new WinX.Windows.Controls.Window(System.Windows.Automation.AutomationElement.FromHandle(selectRawWindow.Handler));
                        window.ClickRight();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CtxDoubleClick_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (lstTargetMatches.SelectedItem != null)
                {
                    var selectRawWindow = lstTargetMatches.SelectedItem as WinX.Windows.RawWindow;
                    if (selectRawWindow != null)
                    {
                        var window = new WinX.Windows.Controls.Window(System.Windows.Automation.AutomationElement.FromHandle(selectRawWindow.Handler));
                        window.DoubleClick();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CtxClose_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (lstTargetMatches.SelectedItem != null)
                {
                    var selectRawWindow = lstTargetMatches.SelectedItem as WinX.Windows.RawWindow;
                    if (selectRawWindow != null)
                    {
                        var window = new WinX.Windows.Controls.Window(System.Windows.Automation.AutomationElement.FromHandle(selectRawWindow.Handler));
                        window.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }


    }
}
