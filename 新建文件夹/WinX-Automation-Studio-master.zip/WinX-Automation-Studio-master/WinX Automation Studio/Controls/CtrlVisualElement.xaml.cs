﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WinX.Windows;

namespace WinX_Automation_Studio
{
    /// <summary>
    /// CtrlVisualElement.xaml 的交互逻辑
    /// </summary>
    public partial class CtrlVisualElement : UserControl
    {

        private bool isDragging = false;
        private Point anchorPoint = new Point();

        double ScrollOrgHorizontalOffset = 0f;
        double ScrollOrgHorizontalChange = 0f;
        double ScrollOrgVerticalOffset = 0f;
        double ScrollOrgVerticalChange = 0f;


        //public WinX.Windows.VisualElement CurrField
        //{
        //    get;
        //    set;
        //}

        public WinX.Windows.VisualElement CurrTarget
        {
            get;
            set;
        }

        public WinX.Windows.GenericWindow CurrWindow
        {
            get;
            set;
        }

        public int VisualAreaCtr = 0;

        private void ThisWindow_Loaded(object sender, RoutedEventArgs e)
        {
            Refresh();

            if (CurrTarget != null && !string.IsNullOrEmpty(CurrTarget.ImageBase64))
            {
                this.cirP.circleUI.RenderTransform = new TranslateTransform(CurrTarget.AdjustX, CurrTarget.AdjustY);


                imgField.Source = WinX.Windows.ImageHelper.Base64ToImage(CurrTarget.ImageBase64);

                selectionRectangle.Visibility = Visibility.Visible;

                if (CurrTarget != null)
                {
                    //this.imgSrc.Source = WinX.Windows.ImageHelper.Base64ToImage(CurrTarget.ImageSrcBase64);

                    selectionRectangle.SetValue(Canvas.LeftProperty, CurrTarget.Left / CurrTarget.srcZoom);
                    selectionRectangle.SetValue(Canvas.TopProperty, CurrTarget.Top / CurrTarget.srcZoom);
                    selectionRectangle.Width = CurrTarget.Width / CurrTarget.srcZoom;
                    selectionRectangle.Height = CurrTarget.Height / CurrTarget.srcZoom;

                    //cirP.circleUI.SetValue(Canvas.LeftProperty, CurrTarget.AdjustX);
                    //cirP.circleUI.SetValue(Canvas.TopProperty, CurrTarget.AdjustY);
                }
            }
        }

        public CtrlVisualElement()
        {
            InitializeComponent();

            this.gridImage1.MouseLeftButtonDown += GridImage1_MouseLeftButtonDown;
            this.gridImage1.MouseLeftButtonUp += GridImage1_MouseLeftButtonUp;
            this.gridImage1.MouseMove += GridImage1_MouseMove;
            this.cirP.MouseMove += CirP_MouseMove;
        }


        private void GridImage1_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (!isDragging)
            {
                anchorPoint.X = e.GetPosition(BackPanel).X;
                anchorPoint.Y = e.GetPosition(BackPanel).Y;
                isDragging = true;
            }
        }
        private void GridImage1_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            try
            {
                if (isDragging && this.CurrTarget!= null)
                {
                    isDragging = false;

                    if (selectionRectangle.Visibility != Visibility.Visible)
                    {
                        selectionRectangle.Visibility = Visibility.Visible;
                    }

                    if (imgSrc.Source != null && selectionRectangle.Height > 0)
                    {
                        if (this.CurrTarget.AutomationElement != null)
                        {
                            var winRect = this.CurrTarget.AutomationElement.Current.BoundingRectangle;

                            var zoomSize = (winRect.Width) / (imgSrc.Source.Width);

                            var rect = new Rect(Canvas.GetLeft(selectionRectangle) * zoomSize, Canvas.GetTop(selectionRectangle) * zoomSize, selectionRectangle.Width * zoomSize, selectionRectangle.Height * zoomSize);
                            var rcFrom = new Int32Rect((int)rect.X, (int)rect.Y, (int)rect.Width, (int)rect.Height);

                            var bs = new CroppedBitmap(imgSrc.Source as BitmapSource, rcFrom);
                            imgField.Source = bs;

                            if (CurrTarget != null)
                            {
                                CurrTarget.Left = rcFrom.X;
                                CurrTarget.Top = rcFrom.Y;
                                CurrTarget.Width = rcFrom.Width;
                                CurrTarget.Height = rcFrom.Height;

                                CurrTarget.srcZoom = zoomSize;

                                //CurrTarget.Left = (double)selectionRectangle.GetValue(Canvas.LeftProperty);
                                //CurrTarget.Top = (double)selectionRectangle.GetValue(Canvas.HeightProperty);
                                //CurrTarget.Width = selectionRectangle.Width;
                                //CurrTarget.Height = selectionRectangle.Height;

                                CurrTarget.ImageBase64 = WinX.Imaging.Utilities.ImageToBase64(bs);

                                //CurrTarget.ImageSrcBase64 = WinX.Imaging.Utilities.ImageToBase64(imgSrc.Source as BitmapSource);

                                PropertyGridEdit.Instance = CurrTarget;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void GridImage1_MouseMove(object sender, MouseEventArgs e)
        {
            if (isDragging)
            {
                var x = e.GetPosition(BackPanel).X;
                var y = e.GetPosition(BackPanel).Y;

                selectionRectangle.SetValue(Canvas.LeftProperty, Math.Min(x, anchorPoint.X));
                selectionRectangle.SetValue(Canvas.TopProperty, Math.Min(y, anchorPoint.Y));
                selectionRectangle.Width = Math.Abs(x - anchorPoint.X);
                selectionRectangle.Height = Math.Abs(y - anchorPoint.Y);

                if (selectionRectangle.Visibility != Visibility.Visible)
                {
                    selectionRectangle.Visibility = Visibility.Visible;
                }
            }
        }

        private void CirP_MouseMove(object sender, MouseEventArgs e)
        {
            var draggableControl = sender as UserControl;
            if (CurrTarget != null)
            {
                CurrTarget.AdjustX = draggableControl.RenderTransform.Value.OffsetX;
                CurrTarget.AdjustY = draggableControl.RenderTransform.Value.OffsetY;

                PropertyGridEdit.Refresh();
            }
        }

        public Action HideAction;
        public Action ShowAction;

        public void HideWindow()
        {
            if (HideAction != null)
            {
                this.HideAction();
            }
            App.Current.MainWindow.WindowState = WindowState.Minimized;
        }
        public void ShowWindow()
        {
            if (ShowAction != null)
            {
                this.ShowAction();
            }
            App.Current.MainWindow.WindowState = WindowState.Normal;
        }

        public void Refresh()
        {
            if (CurrTarget != null && CurrTarget.AutomationElement == null)
            {
                if (this.CurrWindow.WaitForCreate(300))
                {
                    CurrTarget.AutomationElement = this.CurrWindow.Window.AutomationElement;
                }

                if (CurrTarget == null || CurrTarget.AutomationElement == null)
                {
                    MessageBox.Show("Not found any window for this element", "Not found any window for this element", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }
            }

            if (CurrTarget != null && CurrTarget.AutomationElement != null)
            {
                HideWindow();

                System.Threading.Thread.Sleep(1000);

                this.CurrTarget.AutomationElement.Current.NativeWindowHandle.BringWindowFront();

                var imgBase64 = CurrTarget.AutomationElement.TakeScreenshotBase64();

                //CurrTarget.ImageSrcBase64 = imgBase64;

                imgSrc.Source = WinX.Windows.ImageHelper.Base64ToImage(imgBase64);

                ShowWindow();

                this.Parent.SetValue(Window.VisibilityProperty, Visibility.Visible);

                WinX.Core.User32.SetForegroundWindow(System.Diagnostics.Process.GetCurrentProcess().MainWindowHandle);
            }
        }

        private void BtnRefresh_Click(object sender, RoutedEventArgs e)
        {
            Refresh();
        }

        private void ScrollOrg_ScrollChanged(object sender, ScrollChangedEventArgs e)
        {
            ScrollOrgHorizontalOffset = e.HorizontalOffset;
            ScrollOrgHorizontalChange = e.HorizontalChange;
            ScrollOrgVerticalOffset = e.VerticalOffset;
            ScrollOrgVerticalChange = e.VerticalChange;

            //Console.WriteLine("Horizontal Position: " + e.HorizontalOffset); /* Gets the current Horizontal Position of the scrollviewer*/
            //Console.WriteLine("Change in Horizontal Position: " + e.HorizontalChange); /* Gets the change in Horizontal Position */
            //Console.WriteLine("Vertical Position: " + e.VerticalOffset); /* Gets the current Vertical Position of the scrollviewer*/
            //Console.WriteLine("Change in Vertical Position : " + e.VerticalChange); /* Gets the change in Vertical Position */
            //Console.WriteLine("Height of the ScrollViewer : " + e.ViewportHeight); /*Gets the Total Height of the ScrollViewer*/
            //Console.WriteLine("Width of the ScrollViewer: " + e.ViewportWidth); /*Gets the Total Width of the ScrollViewer*/

        }

        private void VisualElementContext_Click(object sender, RoutedEventArgs e)
        {
            if(CurrTarget != null&& CurrTarget.AutomationElement != null)
            {
                HideWindow();

                this.CurrTarget.AdjustX = this.cirP.circleUI.RenderTransform.Value.OffsetX;
                this.CurrTarget.AdjustY = this.cirP.circleUI.RenderTransform.Value.OffsetY;

                this.CurrTarget.Click();

                ShowWindow();
            }
            else
            {
                MessageBox.Show("Not found any Screen! plase reflash screen.");
            }
        }

        private void VisualElementContext_RightClick(object sender, RoutedEventArgs e)
        {
            if (CurrTarget != null && CurrTarget.AutomationElement != null)
            {
                HideWindow();

                this.CurrTarget.AdjustX = this.cirP.circleUI.RenderTransform.Value.OffsetX;
                this.CurrTarget.AdjustY = this.cirP.circleUI.RenderTransform.Value.OffsetY;

                this.CurrTarget.RightClick();

                ShowWindow();
            }
            else
            {
                MessageBox.Show("Not found any Screen! plase reflash screen.");
            }
        }

        private void VisualElementContext_DBClick(object sender, RoutedEventArgs e)
        {
            if (CurrTarget != null && CurrTarget.AutomationElement != null)
            {
                HideWindow();

                this.CurrTarget.AdjustX = this.cirP.circleUI.RenderTransform.Value.OffsetX;
                this.CurrTarget.AdjustY = this.cirP.circleUI.RenderTransform.Value.OffsetY;

                this.CurrTarget.DBClick();

                ShowWindow();
            }
            else
            {
                MessageBox.Show("Not found any Screen! plase reflash screen.");
            }
        }

        private void VisualElementContext_TypeText(object sender, RoutedEventArgs e)
        {
            if (CurrTarget != null && CurrTarget.AutomationElement != null)
            {
                var inputTextDialog = new InputTextDialog();
                inputTextDialog.ShowDialog();

                if (inputTextDialog.DialogResult == true)
                {
                    var testStr = inputTextDialog.txtInput.Text;
                    HideWindow();

                    this.CurrTarget.AdjustX = this.cirP.circleUI.RenderTransform.Value.OffsetX;
                    this.CurrTarget.AdjustY = this.cirP.circleUI.RenderTransform.Value.OffsetY;
                    this.CurrTarget.TypeText(testStr);
                    ShowWindow();
                }
            }
            else
            {
                MessageBox.Show("Not found any Screen! plase reflash screen.");
            }
        }

        private void VisualElementContext_SelectAllText(object sender, RoutedEventArgs e)
        {
            if (CurrTarget != null && CurrTarget.AutomationElement != null)
            {
                HideWindow();

                this.CurrTarget.AdjustX = this.cirP.circleUI.RenderTransform.Value.OffsetX;
                this.CurrTarget.AdjustY = this.cirP.circleUI.RenderTransform.Value.OffsetY;

                this.CurrTarget.Click();

                var inputSimulator = new WinX.Core.WindowsInput.InputSimulator();
                inputSimulator.Keyboard.ModifiedKeyStroke(
                    new List<WinX.Core.WindowsInput.Native.VirtualKeyCode>()
                    {
                        WinX.Core.WindowsInput.Native.VirtualKeyCode.LCONTROL,
                    },
                    new List<WinX.Core.WindowsInput.Native.VirtualKeyCode>()
                    {
                        WinX.Core.WindowsInput.Native.VirtualKeyCode.VK_A,
                    }
                );


                ShowWindow();
            }
            else
            {
                MessageBox.Show("Not found any Screen! plase reflash screen.");
            }
        }

        private void VisualElementContext_SendCopyKey(object sender, RoutedEventArgs e)
        {
            if (CurrTarget != null && CurrTarget.AutomationElement != null)
            {
                HideWindow();

                this.CurrTarget.AdjustX = this.cirP.circleUI.RenderTransform.Value.OffsetX;
                this.CurrTarget.AdjustY = this.cirP.circleUI.RenderTransform.Value.OffsetY;

                this.CurrTarget.Click();

                var inputSimulator = new WinX.Core.WindowsInput.InputSimulator();
                inputSimulator.Keyboard.ModifiedKeyStroke(
                    new List<WinX.Core.WindowsInput.Native.VirtualKeyCode>()
                    {
                        WinX.Core.WindowsInput.Native.VirtualKeyCode.LCONTROL,
                    },
                    new List<WinX.Core.WindowsInput.Native.VirtualKeyCode>()
                    {
                        WinX.Core.WindowsInput.Native.VirtualKeyCode.VK_C,
                    }
                );

                ShowWindow();
            }
            else
            {
                MessageBox.Show("Not found any Screen! plase reflash screen.");
            }
        }

        private void VisualElementContext_SendPauseKey(object sender, RoutedEventArgs e)
        {
            if (CurrTarget != null && CurrTarget.AutomationElement != null)
            {
                HideWindow();

                this.CurrTarget.AdjustX = this.cirP.circleUI.RenderTransform.Value.OffsetX;
                this.CurrTarget.AdjustY = this.cirP.circleUI.RenderTransform.Value.OffsetY;

                this.CurrTarget.Click();

                var inputSimulator = new WinX.Core.WindowsInput.InputSimulator();
                inputSimulator.Keyboard.ModifiedKeyStroke(
                    new List<WinX.Core.WindowsInput.Native.VirtualKeyCode>()
                    {
                        WinX.Core.WindowsInput.Native.VirtualKeyCode.LCONTROL,
                    },
                    new List<WinX.Core.WindowsInput.Native.VirtualKeyCode>()
                    {
                        WinX.Core.WindowsInput.Native.VirtualKeyCode.VK_V,
                    }
                );

                ShowWindow();
            }
            else
            {
                MessageBox.Show("Not found any Screen! plase reflash screen.");
            }
        }
    }
}
