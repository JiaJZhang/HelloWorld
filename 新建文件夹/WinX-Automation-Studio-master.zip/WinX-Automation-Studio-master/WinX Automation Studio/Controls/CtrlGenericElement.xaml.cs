﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WinX.Core;
using WinX.Windows;

namespace WinX_Automation_Studio
{
    /// <summary>
    /// CtrlGenericElement.xaml 的交互逻辑
    /// </summary>
    public partial class CtrlGenericElement : UserControl
    {
        public WinX.Windows.GenericWindow Window
        {
            get;
            set;
        }

        public CtrlGenericElement()
        {
            InitializeComponent();
            
            SelectedMatchRuleHost.Child = new System.Windows.Forms.PropertyGrid();
            SelectedTargetHost.Child = new System.Windows.Forms.PropertyGrid();
            WinX.Core.Logger.Write(this.GetType().Name + " has been loaded successfully.");
        }

        private void CtrlGenericElement_Loaded(object sender, RoutedEventArgs e)
        {
            BindMatchRules();
        }

        private void BindMatchRules()
        {
            try
            {
                cmbAvailableMatchRules.ItemsSource = null;
                var element = this.DataContext as WinX.Windows.GenericElement;
                var existingRules = lstDocMatchRules.ItemsSource as ObservableCollection<MatchRule>;
                var possibleRules = WinX.Core.ReflectionHelper.FindDerivedTypes(typeof(WinX.Windows.GenericElement).Assembly, typeof(WinX.Core.MatchRule)).Select(t => t.Name).ToList();
                var filteredRules = new List<string>();
                if (existingRules != null && existingRules.Count() > 0)
                {
                    filteredRules = possibleRules.Where(r => !r.Equals(typeof(WinX.Windows.WindowTitleMatchRule).Name) && !existingRules.Select(er => er.GetType().Name).Contains(r)).ToList();
                }
                else
                {
                    filteredRules = possibleRules;
                }

                if(filteredRules != null && filteredRules.Count() > 0)
                {
                    cmbAvailableMatchRules.ItemsSource = filteredRules;
                    btnAddMatchRule.IsEnabled = true;
                    cmbAvailableMatchRules.IsEnabled = true;
                }
                else
                {
                    btnAddMatchRule.IsEnabled = false;
                    cmbAvailableMatchRules.IsEnabled = false;
                }
            }
            catch(Exception ex)
            {
                Logger.Write(ex, "There was an error while Trying to bindMatch rules.");
            }
        }

        private void lstDocMatchRules_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (lstDocMatchRules.SelectedItem != null)
                {
                    var propGrid = SelectedMatchRuleHost.Child as System.Windows.Forms.PropertyGrid;
                    propGrid.SelectedObject = lstDocMatchRules.SelectedItem;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }


        private void lstTargetMatches_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (lstTargetMatches.SelectedItem != null)
                {
                    var propGrid = SelectedTargetHost.Child as System.Windows.Forms.PropertyGrid;
                    propGrid.SelectedObject = lstTargetMatches.SelectedItem;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CtxDeleteRule_Click(object sender, RoutedEventArgs e)
        {
            if(this.DataContext != null)
            {
                var propGrid = this.SelectedMatchRuleHost.Child as System.Windows.Forms.PropertyGrid;
                if(propGrid.SelectedObject != null)
                {
                    var rule = propGrid.SelectedObject as MatchRule;
                    
                    var existingRules = lstDocMatchRules.ItemsSource as ObservableCollection<MatchRule>;

                    if (existingRules != null && existingRules.Count() > 0 && rule != null)
                    {
                        existingRules.Remove(rule);
                    }
                    BindMatchRules();
                }
            }
        }
        
        private void btnAddMatchRule_Click(object sender, RoutedEventArgs e)
        {
            try
            {
               if(cmbAvailableMatchRules.SelectedItem != null)
                {
                    var element = this.DataContext as WinX.Windows.GenericElement;
                    if(element != null)
                    {
                        WinX.Core.MatchRule rule = null;
                        System.Windows.Automation.AutomationElement target = null;

                        var propGrid = SelectedTargetHost.Child as System.Windows.Forms.PropertyGrid;
                        if(propGrid.SelectedObject != null)
                        {
                            target = propGrid.SelectedObject as System.Windows.Automation.AutomationElement;
                        }

                        switch (cmbAvailableMatchRules.SelectedItem.ToString())
                        {
                            case "ControlIdMatchRule":
                                rule = new WinX.Windows.ControlIdMatchRule();
                                if (target != null)
                                {
                                    rule = new WinX.Windows.ControlIdMatchRule(target.Current.AutomationId);
                                }
                                break;
                            case "ControlClassMatchRule":
                                rule = new WinX.Windows.ControlClassMatchRule();
                                if (target != null)
                                {
                                    rule = new WinX.Windows.ControlClassMatchRule(target.Current.ClassName);
                                }
                                break;
                            case "ControlIndexMatchRule":
                                rule = new WinX.Windows.ControlIndexMatchRule();
                                if (target != null)
                                {
                                    rule = new WinX.Windows.ControlIndexMatchRule(target.GetIndex());
                                }

                                break;
                            case "ControlNameMatchRule":
                                rule = new WinX.Windows.ControlNameMatchRule();
                                if (target != null)
                                {
                                    rule = new WinX.Windows.ControlNameMatchRule(target.Current.Name);
                                }
                                break;
                            case "LocalizedControlType":
                                rule = new WinX.Windows.ControlNameMatchRule();
                                if (target != null)
                                {
                                    rule = new WinX.Windows.LocalizedControlTypeMatchRule(target.Current.LocalizedControlType);
                                }
                                break;
                        }

                        if(rule != null)
                        {
                            element.MatchRules.Add(rule);
                            BindMatchRules();
                        }
                    }
                }
                cmbAvailableMatchRules.SelectedItem = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        
        private void CtxElementHighLight_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (lstTargetMatches.SelectedItem != null)
                {
                    var propGrid = SelectedTargetHost.Child as System.Windows.Forms.PropertyGrid;

                    var target = (lstTargetMatches.SelectedItem as WinX.Windows.Controls.BaseElement).AutomationElement;

                    if (target != null && target.Current.NativeWindowHandle != IntPtr.Zero.ToInt32())
                    {
                        WinX.Core.Win32Helper.Highlight(new IntPtr(target.Current.NativeWindowHandle), System.Drawing.Brushes.Red);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CtxElementClick_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (lstTargetMatches.SelectedItem != null)
                {
                    var propGrid = SelectedTargetHost.Child as System.Windows.Forms.PropertyGrid;

                    var target = (lstTargetMatches.SelectedItem as WinX.Windows.Controls.BaseElement).AutomationElement;

                    if (target != null && target.Current.NativeWindowHandle != IntPtr.Zero.ToInt32())
                    {
                        target.GetInvokePattern().Invoke();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }


        private void CtxElementSetText_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (lstTargetMatches.SelectedItem != null)
                {
                    var propGrid = SelectedTargetHost.Child as System.Windows.Forms.PropertyGrid;

                    var target = (lstTargetMatches.SelectedItem as WinX.Windows.Controls.BaseElement).AutomationElement;


                    var inputDialog = new InputTextDialog()
                    {
                        Owner = App.Current.MainWindow
                    };

                    if (inputDialog.ShowDialog() == true)
                    {
                        target.SetValue(inputDialog.txtInput.Text);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }


        private void CtxElementGetText_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (lstTargetMatches.SelectedItem != null)
                {
                    var propGrid = SelectedTargetHost.Child as System.Windows.Forms.PropertyGrid;

                    var target = (lstTargetMatches.SelectedItem as WinX.Windows.Controls.BaseElement).AutomationElement;
                    
                    var inputDialog = new InputTextDialog()
                    {
                        Owner = App.Current.MainWindow,
                    };
                    inputDialog.txtInput.Text = target.GetValue();

                    inputDialog.ShowDialog();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }


        private void CtxElementLeftClick_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (lstTargetMatches.SelectedItem != null)
                {
                    var propGrid = SelectedTargetHost.Child as System.Windows.Forms.PropertyGrid;

                    var target = (lstTargetMatches.SelectedItem as WinX.Windows.Controls.BaseElement).AutomationElement;

                    var ele = new WinX.Windows.Controls.BaseElement(target);

                    if(ele != null)
                    {
                        ele.ClickLeft();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CtxElementRightClick_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (lstTargetMatches.SelectedItem != null)
                {
                    var propGrid = SelectedTargetHost.Child as System.Windows.Forms.PropertyGrid;

                    var target = (lstTargetMatches.SelectedItem as WinX.Windows.Controls.BaseElement).AutomationElement;

                    var ele = new WinX.Windows.Controls.BaseElement(target);

                    if (ele != null)
                    {
                        ele.ClickRight();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CtxElementClickSecure_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (lstTargetMatches.SelectedItem != null)
                {
                    var propGrid = SelectedTargetHost.Child as System.Windows.Forms.PropertyGrid;

                    var target = (lstTargetMatches.SelectedItem as WinX.Windows.Controls.BaseElement).AutomationElement;

                    var ele = new WinX.Windows.Controls.BaseElement(target);

                    if (ele != null)
                    {
                        ele.ClickSecureButton();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        

        private void CtxGetAllOptions_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (lstTargetMatches.SelectedItem != null)
                {
                    var propGrid = SelectedTargetHost.Child as System.Windows.Forms.PropertyGrid;

                    var target = lstTargetMatches.SelectedItem as WinX.Windows.Controls.BaseElement;

                    if(target.ElementType.Equals("WinX.Windows.Controls.ComboBox"))
                    {
                        var combo = new WinX.Windows.Controls.ComboBox(target.AutomationElement);

                        var inputDialog = new InputTextDialog()
                        {
                            Owner = App.Current.MainWindow,
                        };
                      
                        foreach(var item in combo.Items)
                        {
                            inputDialog.txtInput.Text += item.TextValue + "\n\r";
                        }

                        inputDialog.ShowDialog();
                    }
                    else if (target.ElementType.Equals("WinX.Windows.Controls.ListBox"))
                    {
                        var listbox = new WinX.Windows.Controls.ListBox(target.AutomationElement);

                        var inputDialog = new InputTextDialog()
                        {
                            Owner = App.Current.MainWindow,
                        };

                        foreach (var item in listbox.Items)
                        {
                            inputDialog.txtInput.Text += item.TextValue + "\n\r";
                        }

                        inputDialog.ShowDialog();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
