﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows.Data;

namespace WinX_Automation_Studio
{
    public partial class ApplicationTypeLocator : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value != null && value is WinX.Core.ApplicationType)
            {
                var appType = (WinX.Core.ApplicationType)value;

                switch (appType)
                {
                    case WinX.Core.ApplicationType.Web:
                        return @"/WinX%20Automation%20Studio;component/Icons/ie.png";
                    case WinX.Core.ApplicationType.Pcom:
                        return @"/WinX%20Automation%20Studio;component/Icons/emulator.png";
                    case WinX.Core.ApplicationType.Generic:
                        return @"/WinX%20Automation%20Studio;component/Icons/windows.png";
                }
            }
            return @"/WinX%20Automation%20Studio;component/Icons/tag.png";
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return null;
        }
    }
}
