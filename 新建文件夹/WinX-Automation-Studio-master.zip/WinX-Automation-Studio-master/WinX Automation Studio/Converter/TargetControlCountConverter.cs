﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows.Data;

namespace WinX_Automation_Studio
{
    public partial class TargetControlCountConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            int source = Int32.TryParse(value.ToString(), out source) ? source : 0;

            if (source > 0)
            {
                return "[" + source + "]";
            }
            else if (source == -1)
            {
                return "[refreshing...]";
            }

            return string.Empty;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw null;
        }
    }
}
