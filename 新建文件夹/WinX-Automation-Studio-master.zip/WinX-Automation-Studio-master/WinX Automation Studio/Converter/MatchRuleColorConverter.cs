﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows.Data;
using System.Windows.Media;

namespace WinX_Automation_Studio
{
    public partial class MatchRuleColorConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value.GetType().ToString().StartsWith("WinX.Web"))
            {
                if (value is WinX.Web.IDMatchRule || value is WinX.Web.NameMatchRule)
                {
                    return new SolidColorBrush(System.Windows.Media.Colors.Lime);
                }
                else if (value is WinX.Web.TagMatchRule || value is WinX.Web.InnerTextMatchRule || value is WinX.Web.InnerHtmlMatchRule)
                {
                    return new SolidColorBrush(System.Windows.Media.Colors.Yellow);
                }
                else if (value is WinX.Web.OuterTextMatchRule || value is WinX.Web.OuterHtmlMatchRule || value is WinX.Web.IndexMatchRule)
                {
                    return new SolidColorBrush(System.Windows.Media.Colors.Yellow);
                }
            }
            else if (value.GetType().ToString().StartsWith("WinX.Emulator"))
            {
                return new SolidColorBrush(System.Windows.Media.Colors.Lime);
            }
            else if (value.GetType().ToString().StartsWith("WinX.Windows"))
            {
                if (value is WinX.Windows.WindowTitleMatchRule || value is WinX.Windows.ControlIdMatchRule || value is WinX.Windows.ControlNameMatchRule)
                {
                    return new SolidColorBrush(System.Windows.Media.Colors.Lime);
                }
                else if (value is WinX.Windows.ControlClassMatchRule || value is WinX.Windows.LocalizedControlTypeMatchRule)
                {
                    return new SolidColorBrush(System.Windows.Media.Colors.Yellow);
                }
            }

            return new SolidColorBrush(System.Windows.Media.Colors.WhiteSmoke);
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return null;
        }
    }
}
