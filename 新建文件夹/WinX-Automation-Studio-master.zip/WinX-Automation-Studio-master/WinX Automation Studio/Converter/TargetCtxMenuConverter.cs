﻿using mshtml;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows.Controls;
using System.Windows.Data;

namespace WinX_Automation_Studio
{

    public partial class TargetCtxMenuConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var ctxMenu = new ContextMenu();
            var mnu = new MenuItem() { Header = "Highlight" };


            if (value is HTMLAnchorElementClass)
            {
                ctxMenu.Items.Add(new MenuItem() { Header = "Click" });
            }
            else if (value is HTMLInputButtonElementClass)
            {
                ctxMenu.Items.Add(new MenuItem() { Header = "Click" });
            }
            else if (value is HTMLInputElementClass)
            {
                ctxMenu.Items.Add(new MenuItem() { Header = "Click" });
                ctxMenu.Items.Add(new MenuItem() { Header = "Set Text" });
                ctxMenu.Items.Add(new MenuItem() { Header = "Get Text" });
            }
            else if (value is HTMLSelectElementClass)
            {
                ctxMenu.Items.Add(new MenuItem() { Header = "Click" });
                ctxMenu.Items.Add(new MenuItem() { Header = "Select Item By Text" });
                ctxMenu.Items.Add(new MenuItem() { Header = "Select Item By Value" });
            }

            return ctxMenu;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw null;
        }
    }
}
