﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows.Data;
using System.Windows.Media;

namespace WinX_Automation_Studio
{
    public partial class TargetControlColorConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            int source = Int32.TryParse(value.ToString(), out source) ? source : 0;

            if (source == 0)
            {
                return new SolidColorBrush(System.Windows.Media.Colors.Black);
            }
            else if (source == 1)
            {
                return new SolidColorBrush(System.Windows.Media.Colors.Green);
            }
            else if (source > 1)
            {
                return new SolidColorBrush(System.Windows.Media.Colors.Red);
            }

            return new SolidColorBrush(System.Windows.Media.Colors.BlueViolet);
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw null;
        }
    }
}
