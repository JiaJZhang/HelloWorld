﻿using mshtml;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows.Data;

namespace WinX_Automation_Studio
{
    public partial class ElementDescriptor : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if(value != null)
            {
                if(value is mshtml.IHTMLElement)
                {
                    var ele = value as IHTMLElement;
                    return "<" + ele.tagName + "... />";
                }
                else if(value is System.Windows.Automation.AutomationElement)
                {
                    var ele = value as System.Windows.Automation.AutomationElement;
                    var strDescription = string.Empty;

                    if(!string.IsNullOrEmpty(ele.Current.LocalizedControlType))
                    {
                        strDescription = "Type='" + ele.Current.LocalizedControlType + "'";
                    }

                    if (!string.IsNullOrEmpty(ele.Current.ClassName))
                    {
                        strDescription += " Class='" + ele.Current.ClassName + "'";
                    }

                    if (!string.IsNullOrEmpty(ele.Current.Name))
                    {
                        strDescription += " Name='" + ele.Current.Name + "'";
                    }

                    if (!string.IsNullOrEmpty(ele.Current.AutomationId))
                    {
                        strDescription += " ID='" + ele.Current.AutomationId + "'";
                    }

                    return "<" + strDescription + " >";
                }
            }
            return "NULL";
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return null;
        }
    }
}
