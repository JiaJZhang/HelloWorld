﻿using MahApps.Metro.Controls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.VisualBasic;
using WinX.Web;
using WinX.StudioLib;
using System.ComponentModel;
using mshtml;
using WinX.Core;

namespace WinX_Automation_Studio
{
    /// <summary>
    /// WebElementCaptureDialog.xaml 的交互逻辑
    /// </summary>
    public partial class WebElementCaptureDialog : MetroWindow
    {
        private WinX.Web.WebScreen curDoc;

        public delegate void ElementCapturedHandle(WebElement raw);

        public event ElementCapturedHandle ElementCaptured;

        private void OnElementCaptured(WebElement raw)
        {
            if (ElementCaptured != null)
            {
                ElementCaptured(raw);
            }
        }


        public WebElementCaptureDialog(mshtml.HTMLDocumentClass doc , WinX.Web.WebScreen screen)
        {
            InitializeComponent();

            this.curDoc = screen;
            var pointer = new WebPointer();
            pointer.ElementSelected += Pointer_ElementSelected;
            SelectorHost.Child = pointer;

            dynamic wShell = Microsoft.VisualBasic.Interaction.CreateObject("WScript.Shell");
            wShell.AppActivate(doc.title);

            doc.focus();
            pointer.Start(doc);
            pointer.Enabled = true;

            WinX.Core.Logger.Write(this.GetType().Name + " has been loaded successfully.");
        }

        private void Pointer_ElementSelected(mshtml.IHTMLElement htmlEle)
        {
            try
            {
                if (htmlEle != null && curDoc != null)
                {
                    RawWebElement ele = null;

                    if(chkSelectElement.IsChecked == false)
                    {
                        ele = RulesEngine.GetRawWebElement(htmlEle, false);
                    }
                    else
                    {
                        var holder = new ElementBrowserDialog();
                        holder.Left = System.Windows.Forms.Control.MousePosition.X - 10;
                        holder.Top = System.Windows.Forms.Control.MousePosition.Y - 10;

                        var bgWorker = new BackgroundWorker();
                        bgWorker.DoWork += (s1, e1) =>
                        {
                            var lstElements = new List<mshtml.IHTMLElement>();
                            if (htmlEle.parentElement != null)
                            {
                                if (htmlEle.parentElement.parentElement != null)
                                {
                                    if (htmlEle.parentElement.parentElement.parentElement != null)
                                    {
                                        lstElements.Add(htmlEle.parentElement.parentElement.parentElement);
                                    }
                                    lstElements.Add(htmlEle.parentElement.parentElement);
                                }
                                lstElements.Add(htmlEle.parentElement);
                            }
                            lstElements.Add(htmlEle);

                            if(htmlEle.children != null)
                            {
                                var childCol = htmlEle.children as IHTMLElementCollection;

                                if(childCol != null && childCol.length > 0)
                                {
                                    var count = childCol.length;
                                    if(count > 5)
                                    {
                                        count = 5;
                                    }
                                    for(int i = 0;i < count ; i++)
                                    {
                                        lstElements.Add(childCol.item(i) as IHTMLElement);
                                    }
                                }
                                e1.Result = lstElements;
                            }

                        };
                        bgWorker.RunWorkerCompleted += (s1, e1) =>
                        {
                            holder.txtblkStatus.Visibility = Visibility.Collapsed;

                            holder.lstElements.ItemsSource = e1.Result as System.Collections.IEnumerable;
                        };

                        bgWorker.RunWorkerAsync();
                        holder.ShowDialog();

                        ele = RulesEngine.GetRawWebElement(holder.lstElements.SelectedItem as IHTMLElement, false);
                    }

                    if(ele == null)
                    {
                        return;
                    }

                    var elementDialog = new NewField();
                    elementDialog.Owner = this;
                    elementDialog.Topmost = true;
                    this.WindowState = WindowState.Minimized;

                    var rules = RulesEngine.GetPossibleWebElementRules(ele, false);
                    elementDialog.lstMatchRules.ItemsSource = rules;

                    if(!string.IsNullOrEmpty(ele.ID))
                    {
                        elementDialog.txtName.Text = ele.ID;
                    }
                    else 
                    {
                        if (!string.IsNullOrEmpty(ele.Name))
                        {
                            elementDialog.txtName.Text = ele.Name;
                        }
                    }

                    elementDialog.txtType.Text = ele.Type.ToString();

                    if (elementDialog.ShowDialog() == true)
                    {
                        var element = new WinX.Web.WebElement()
                        {
                            ID = Guid.NewGuid(),
                            Name = elementDialog.txtName.Text,
                            ElementType = elementDialog.txtType.Text,
                            Description = elementDialog.txtDescription.Text,
                            ScreenID = this.curDoc.ID,
                            ApplicationID = this.curDoc.ApplicationID
                        };

                        foreach (var rule in elementDialog.lstMatchRules.SelectedItems)
                        {
                            element.MatchRules.Add(rule as MatchRule);
                        }
                        this.curDoc.Fields.Add(element);
                    }
                }
            }
            catch (Exception ex)
            {
                WinX.Core.Logger.Write(ex, "There was error while trying to interogate a web element.");
            }

            this.WindowState = WindowState.Normal;
        }
    }
}
