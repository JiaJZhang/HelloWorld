﻿using MahApps.Metro.Controls;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WinX.Windows;

namespace WinX_Automation_Studio
{
    /// <summary>
    /// CtrlVisualElement.xaml 的交互逻辑
    /// </summary>
    public partial class CtrlVisualElementDialog : MetroWindow
    {
        public WinX.Windows.VisualElement CurrTarget
        {
            get;set;
        }

        public WinX.Windows.GenericWindow CurrWindow
        {
            get; set;
        }

        public CtrlVisualElementDialog(WinX.Windows.VisualElement CurrTarget, GenericWindow CurrWindow)
        {
            InitializeComponent();

            this.CurrTarget = CurrTarget;
            this.CurrWindow = CurrWindow;

            this.CtrlVisualElementHost.CurrTarget = this.CurrTarget;
            this.CtrlVisualElementHost.CurrWindow = this.CurrWindow;

            CtrlVisualElementHost.HideAction = () => { this.Visibility = Visibility.Hidden; };
            CtrlVisualElementHost.ShowAction = () => { this.Visibility = Visibility.Visible; };

            CtrlVisualElementHost.Loaded += (o, e) => { CtrlVisualElementHost.Refresh(); };
        }

        private void btnOK_Click(object sender, RoutedEventArgs e)
        {
            CtrlVisualElementHost.HideAction = null;
            CtrlVisualElementHost.ShowAction = null;

            if (this.CurrTarget != null && this.CurrWindow != null)
            {
                this.CurrWindow.Fields.Add(CurrTarget);
            }
            //this.DialogResult = true;
            this.Close();
        }

        private void btnCencal_Click(object sender, RoutedEventArgs e)
        {
            CtrlVisualElementHost.HideAction = null;
            CtrlVisualElementHost.ShowAction = null;

            //this.DialogResult = false;
            this.Close();
        }
    }
}
