﻿using MahApps.Metro.Controls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WinX_Automation_Studio
{
    /// <summary>
    /// AboutScreen.xaml 的交互逻辑
    /// </summary>
    public partial class AboutScreen : MetroWindow
    {
        public AboutScreen()
        {
            InitializeComponent();
            WinX.Core.Logger.Write(this.GetType().Name + " has been loaded successfully.");
        }

        private void btnOK_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = true;
            this.Close();
        }

        private void MetroWindow_Loaded(object sender, RoutedEventArgs e)
        {

            lblVersion.Content = "WinX Runtime version :" + this.GetType().Assembly.GetName().Version.Major + "."
                                                        + this.GetType().Assembly.GetName().Version.Minor + "." +
                                                        this.GetType().Assembly.GetName().Version.Revision + "." +
                                                        this.GetType().Assembly.GetName().Version.Build;
        }
    }
}
