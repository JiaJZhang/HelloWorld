﻿using MahApps.Metro.Controls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WinX_Automation_Studio
{
    /// <summary>
    /// NewField.xaml 的交互逻辑
    /// </summary>
    public partial class NewField : MetroWindow
    {
        public NewField()
        {
            InitializeComponent();
            WinX.Core.Logger.Write(this.GetType().Name + " has been loaded successfully.");
        }

        private void btnCencal_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
            this.Close();
        }

        private void btnOK_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(txtName.Text) || !WinX.Core.Validator.IsAlphaNumber(txtName.Text))
            {
                MessageBox.Show("Name can not have spaces or special chars.", "Invalid Name", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var screen = this.DataContext as WinX.Core.Screen;
            if (screen != null && screen.Fields != null)
            {
                var field = screen.Fields.Where(m => m.Name == txtName.Text).FirstOrDefault();
                if (field != null)
                {
                    MessageBox.Show("There is already an application present with the name '" + txtName.Text + "'. Please choose an other one .", "Duplicate Name", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }
            }

            if(lstMatchRules.SelectedItem == null || lstMatchRules.SelectedItems.Count == 0)
            {
                if(MessageBox.Show("Are you surely want to create field without any match rule?","No match rules ?",MessageBoxButton.YesNo,MessageBoxImage.Question) == MessageBoxResult.No)
                {
                    return;
                }
            }

            this.DialogResult = true;
            this.Close();
        }

        private void MetroWindow_Loaded(object sender, RoutedEventArgs e)
        {

        }
    }
}
