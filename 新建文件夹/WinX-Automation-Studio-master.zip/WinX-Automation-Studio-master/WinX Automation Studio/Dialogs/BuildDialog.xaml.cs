﻿using MahApps.Metro.Controls;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WinX_Automation_Studio
{
    /// <summary>
    /// BuildDialog.xaml 的交互逻辑
    /// </summary>
    public partial class BuildDialog : MetroWindow
    {
        public BuildDialog(WinX.Core.Project project,string projectBuildPath)
        {
            InitializeComponent();

            try
            {
                this.pbBuild.Visibility = Visibility.Visible;
                this.btnOK.IsEnabled = false;
                if(!System.IO.Directory.Exists(projectBuildPath))
                {
                    System.IO.Directory.CreateDirectory(projectBuildPath);

                    var coder = new WinX.StudioLib.CodeGenerator();
                    coder.EmbedLibraryies = true;
                    coder.EmbedUIComponents = false;
                    coder.CodeType = WinX.Core.CodeType.DLL;

                    var bgWorker = new BackgroundWorker();
                    bgWorker.DoWork += (s1, e1) =>
                    {
                        dynamic e2 = e1.Argument;
                        var c1 = e2[0] as WinX.StudioLib.CodeGenerator;
                        string genPath = e2[1];
                        var proObj = e2[2] as WinX.Core.Project;

                        if (c1.Generate(genPath, proObj))
                        {
                            e1.Result = new object[] { true, "DLL has been compiled successfully(" + genPath + @"\" + proObj.Name + ".dll" };
                        }
                        else
                        {
                            var failMsg = "There was an error while trying to compile Dll";
                            failMsg += "\r\n -------------------------------------------";

                            foreach(var msg in coder.Errors)
                            {
                                failMsg += "\r\n " + msg;
                            }
                            e1.Result = new object[] { false, failMsg };
                        }
                    };

                    bgWorker.RunWorkerCompleted += (s1, e1) => 
                    {
                        dynamic e2 = e1.Result;
                        txtBuildLog.Text = e2[1];

                        btnOK.IsEnabled = true;

                        this.pbBuild.Visibility = Visibility.Collapsed;

                        if(e2[0])
                        {
                            this.tbTitle.Text = "Build process was successful.";
                        }
                        else
                        {
                            this.tbTitle.Text = "Build process was failed with errors.";
                        }
                    };

                    bgWorker.RunWorkerAsync(new object[] {coder,projectBuildPath,project });

                }
            }
            catch(Exception ex)
            {
                WinX.Core.Logger.Write(ex, "There was an error while trying to load Code generation dialog.");
            }

        }

        private void btnOK_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = true;
            this.Close();
        }
    }
}
