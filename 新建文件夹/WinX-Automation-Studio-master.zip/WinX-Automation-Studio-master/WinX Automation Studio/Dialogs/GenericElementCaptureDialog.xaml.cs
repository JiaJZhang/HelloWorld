﻿using MahApps.Metro.Controls;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WinX.Core;
using WinX.Windows;

namespace WinX_Automation_Studio
{
    /// <summary>
    /// GenericElementCaptureDialog.xaml 的交互逻辑
    /// </summary>
    public partial class GenericElementCaptureDialog : MetroWindow
    {
        public System.Windows.Automation.AutomationElement CurElement
        {
            get;
            set;
        }

        private GenericWindow curWindow
        {
            get; set;
        }


        public GenericElementCaptureDialog(IntPtr hWnd,WinX.Windows.GenericWindow screen)
        {
            InitializeComponent();

            this.curWindow = screen;
            var pointer = new GenericPointer();
            pointer.TargetWindowHandle = hWnd;

            pointer.ActiveWindowSelected += Pointer_ActiveWindowSelected;
            SelectorHost.Child = pointer;
            WinX.Core.Logger.Write(this.GetType().Name + " has been loaded successfully.");

            try
            {
                var window = new WinX.Windows.Controls.Window(System.Windows.Automation.AutomationElement.FromHandle(hWnd));
                if(window != null)
                {
                    window.RecoverNormal();
                    if(window.AutomationElement.Current.IsKeyboardFocusable)
                    {
                        window.SetFocus();
                    }
                }
                User32.SetForegroundWindow(hWnd);
            }
            catch(Exception ex)
            {
                Logger.Write(ex, "Unable to bring target window to the front");
            }

        }

        private void Pointer_ActiveWindowSelected(object sender, EventArgs e)
        {
            try
            {
                var pointer = sender as GenericPointer;
                if (pointer.SelectedElement != null)
                {
                    this.CurElement = null;
                    if (chkSelectElement.IsChecked == false)
                    {
                        this.CurElement = pointer.SelectedElement;
                    }
                    else
                    {
                        var holder = new ElementBrowserDialog();
                        holder.Left = System.Windows.Forms.Control.MousePosition.X - 10;
                        holder.Top = System.Windows.Forms.Control.MousePosition.Y - 10;

                        var bgWorker = new BackgroundWorker();
                        bgWorker.DoWork += (s1, e1) =>
                        {
                            var lstElements = new List<System.Windows.Automation.AutomationElement>();
                            var parentEle = pointer.SelectedElement.GetParent();
                            if (parentEle != null && !parentEle.Current.ControlType.Equals(System.Windows.Automation.ControlType.Window))
                            {
                                var grandparent = parentEle.GetParent();

                                if (grandparent != null && !grandparent.Current.ControlType.Equals(System.Windows.Automation.ControlType.Window))
                                {
                                    var ggParent = grandparent.GetParent();

                                    if (ggParent != null && !ggParent.Current.ControlType.Equals(System.Windows.Automation.ControlType.Window))
                                    {
                                        lstElements.Add(ggParent);
                                    }
                                    lstElements.Add(grandparent);
                                }

                                lstElements.Add(parentEle);
                            }

                            if (!pointer.SelectedElement.Current.ControlType.Equals(System.Windows.Automation.ControlType.Window))
                            {
                                lstElements.Add(pointer.SelectedElement);
                            }

                            var childern = pointer.SelectedElement.GetChildren();

                            if (childern != null && childern.Count > 0)
                            {
                                lstElements.AddRange(childern);
                            }

                            e1.Result = lstElements;
                        };

                        bgWorker.RunWorkerCompleted += (s1, e1) =>
                        {
                            holder.txtblkStatus.Visibility = Visibility.Collapsed;
                            holder.lstElements.ItemsSource = e1.Result as List<System.Windows.Automation.AutomationElement>;
                        };

                        bgWorker.RunWorkerAsync();
                        holder.ShowDialog();
                        this.CurElement = holder.lstElements.SelectedItem as System.Windows.Automation.AutomationElement;
                    }

                    if (this.CurElement == null)
                    {
                        return;
                    }

                    var elementDialog = new NewField()
                    {
                        Owner = this,
                        Topmost = true,
                    };
                    this.WindowState = WindowState.Minimized;

                    var rules = PrepareMatchRules(this.CurElement);
                    rules.Add(GetElementPath(this.CurElement));
                    elementDialog.lstMatchRules.ItemsSource = rules;

                    if (!string.IsNullOrEmpty(this.CurElement.Current.LocalizedControlType))
                    {
                        if (this.CurElement.Current.ControlType.Equals(System.Windows.Automation.ControlType.Button))
                        {
                            elementDialog.txtName.Text = "btn";
                        }
                        else if (this.CurElement.Current.ControlType.Equals(System.Windows.Automation.ControlType.Edit))
                        {
                            elementDialog.txtName.Text = "txt";
                        }
                        else if (this.CurElement.Current.ControlType.Equals(System.Windows.Automation.ControlType.CheckBox))
                        {
                            elementDialog.txtName.Text = "chk";
                        }
                        else if (this.CurElement.Current.ControlType.Equals(System.Windows.Automation.ControlType.ComboBox))
                        {
                            elementDialog.txtName.Text = "cmb";
                        }
                        else if (this.CurElement.Current.ControlType.Equals(System.Windows.Automation.ControlType.RadioButton))
                        {
                            elementDialog.txtName.Text = "radio";
                        }
                        else if (this.CurElement.Current.ControlType.Equals(System.Windows.Automation.ControlType.Text))
                        {
                            elementDialog.txtName.Text = "lbl";
                        }
                        else if (this.CurElement.Current.ControlType.Equals(System.Windows.Automation.ControlType.Hyperlink))
                        {
                            elementDialog.txtName.Text = "lnk";
                        }
                        else if (this.CurElement.Current.ControlType.Equals(System.Windows.Automation.ControlType.Menu))
                        {
                            elementDialog.txtName.Text = "menu";
                        }
                        else if (this.CurElement.Current.ControlType.Equals(System.Windows.Automation.ControlType.MenuItem))
                        {
                            elementDialog.txtName.Text = "menuItem";
                        }
                        else if (this.CurElement.Current.ControlType.Equals(System.Windows.Automation.ControlType.DataGrid))
                        {
                            elementDialog.txtName.Text = "dataGrid";
                        }
                        else if (this.CurElement.Current.ControlType.Equals(System.Windows.Automation.ControlType.Image))
                        {
                            elementDialog.txtName.Text = "img";
                        }
                        else if (this.CurElement.Current.ControlType.Equals(System.Windows.Automation.ControlType.Tab))
                        {
                            elementDialog.txtName.Text = "tab";
                        }
                        else if (this.CurElement.Current.ControlType.Equals(System.Windows.Automation.ControlType.Tree))
                        {
                            elementDialog.txtName.Text = "tree";
                        }
                        else if (this.CurElement.Current.ControlType.Equals(System.Windows.Automation.ControlType.TreeItem))
                        {
                            elementDialog.txtName.Text = "treeItem";
                        }
                        else
                        {
                            elementDialog.txtName.Text = "ctrl";
                        }
                    }

                    if (!string.IsNullOrEmpty(this.CurElement.Current.Name))
                    {
                        elementDialog.txtName.Text += this.CurElement.Current.Name.Replace(" ", "");
                    }
                    else if(!string.IsNullOrEmpty(this.CurElement.Current.AutomationId))
                    {
                        elementDialog.txtName.Text += this.CurElement.Current.AutomationId;
                    }

                    elementDialog.txtType.Text = this.CurElement.GetWinXGenericControl().GetType().ToString();

                    if(elementDialog.ShowDialog() == true)
                    {
                        var element = new WinX.Windows.GenericElement()
                        {
                            ID = Guid.NewGuid(),
                            ElementType = elementDialog.txtType.Text,
                            Name = elementDialog.txtName.Text,
                            Description = elementDialog.txtDescription.Text,
                            ScreenID = this.curWindow.ID,
                            Status = true,
                            ApplicationID = this.curWindow.ApplicationID
                        };

                        foreach(var rule in elementDialog.lstMatchRules.SelectedItems)
                        {
                            element.MatchRules.Add(rule as MatchRule);
                        }
                        this.curWindow.Fields.Add(element);
                    }
                }
            }
            catch(Exception ex)
            {
                Logger.Write(ex, "There was error while trying to interogate a generic element.");
            }

            this.WindowState = WindowState.Normal;
        }

        private ObservableCollection<MatchRule> PrepareMatchRules(System.Windows.Automation.AutomationElement ele)
        {
            var rules = new ObservableCollection<MatchRule>();

            if(!string.IsNullOrEmpty(ele.Current.Name))
            {
                rules.Add(new ControlNameMatchRule(ele.Current.Name));
            }

            if (!string.IsNullOrEmpty(ele.Current.AutomationId))
            {
                rules.Add(new ControlIdMatchRule(ele.Current.AutomationId));
            }

            if (!string.IsNullOrEmpty(ele.Current.ClassName))
            {
                rules.Add(new ControlClassMatchRule(ele.Current.ClassName));
            }

            if (!string.IsNullOrEmpty(ele.Current.LocalizedControlType))
            {
                rules.Add(new LocalizedControlTypeMatchRule(ele.Current.LocalizedControlType));
            }

            var index = ele.GetIndex();
            if(index > 0)
            {
                rules.Add(new ControlIndexMatchRule(index));
            }

            return rules;
        }

        private ControlPathMatchRule GetElementPath(System.Windows.Automation.AutomationElement srcElement)
        {
            var rootNode = new ControlPathMatchRule();
            var walker = TreeWalker.RawViewWalker;
            System.Windows.Automation.AutomationElement elementParent = null;
            var ele = srcElement;

            if(ele != System.Windows.Automation.AutomationElement.RootElement)
            {
                rootNode.MatchRules = PrepareMatchRules(ele);

                do
                {
                    elementParent = walker.GetParent(ele);
                    var tmpNode = new ControlPathMatchRule()
                    {
                        MatchRules = PrepareMatchRules(elementParent),
                    };
                    tmpNode.Child = rootNode;
                    rootNode = tmpNode;

                    if (elementParent == System.Windows.Automation.AutomationElement.RootElement)
                    {
                        break;
                    }

                    ele = elementParent;
                } while (true);
            }
            return rootNode.Child.Child;
        }
    }
}
