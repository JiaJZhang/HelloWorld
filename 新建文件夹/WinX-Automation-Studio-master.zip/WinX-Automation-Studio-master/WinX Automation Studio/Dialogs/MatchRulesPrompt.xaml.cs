﻿using MahApps.Metro.Controls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WinX_Automation_Studio
{
    /// <summary>
    /// MatchRulesPrompt.xaml 的交互逻辑
    /// </summary>
    public partial class MatchRulesPrompt : MetroWindow
    {
        public MatchRulesPrompt()
        {
            InitializeComponent();

            WinX.Core.Logger.Write(this.GetType().Name + " has been loaded successfully.");
        }

        private void btnOK_Click(object sender, RoutedEventArgs e)
        {
            if(this.lstMatchRules.SelectedItems == null || this.lstMatchRules.SelectedItems.Count < 1)
            {
                MessageBox.Show("Please choose at least on match rule.", "Mandatory", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            this.DialogResult = true;
            this.Close();
        }

        private void btnCencal_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
            this.Close();
        }
    }
}
