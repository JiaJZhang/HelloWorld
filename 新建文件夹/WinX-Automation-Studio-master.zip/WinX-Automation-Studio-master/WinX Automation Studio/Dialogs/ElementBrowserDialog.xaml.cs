﻿using MahApps.Metro.Controls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WinX_Automation_Studio
{
    /// <summary>
    /// ElementBrowserDialog.xaml 的交互逻辑
    /// </summary>
    public partial class ElementBrowserDialog : MetroWindow
    {
        public System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();

        public ElementBrowserDialog()
        {
            InitializeComponent();

            this.timer.Enabled = false;
            this.timer.Interval = 1000;
            this.timer.Tick += Timer_Tick;
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            timer.Enabled = false;
            timer.Stop();
            this.Close();
        }

        private void MetroWindow_Activated(object sender, EventArgs e)
        {
            timer.Enabled = false;
        }

        private void MetroWindow_Deactivated(object sender, EventArgs e)
        {
            timer.Enabled = true;
            timer.Start();
        }

        private void MetroWindow_MouseEnter(object sender, MouseEventArgs e)
        {
            timer.Enabled = false;
            timer.Stop();
        }

        private void MetroWindow_MouseLeave(object sender, MouseEventArgs e)
        {
            timer.Enabled = true;
            timer.Start();
        }

        private void lstElements_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (this.lstElements.SelectedItem != null)
            {
                this.Close();
            }
        }

        private void lstElements_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            timer.Enabled = false;
            timer.Stop();
        }
    }
}
