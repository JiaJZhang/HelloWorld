﻿using MahApps.Metro.Controls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WinX_Automation_Studio
{
    /// <summary>
    /// NewScreen.xaml 的交互逻辑
    /// </summary>
    public partial class NewScreen : MetroWindow
    {
        private WinX.Core.Screen screen = null;

        public WinX.Core.Screen Screen
        {
            get
            {
                return screen;
            }
            set
            {
                screen = value;
            }
        }
        
        public NewScreen()
        {
            InitializeComponent();
            WinX.Core.Logger.Write(this.GetType().Name + "has been loaded successfully.");
        }

        private void btnOK_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(txtName.Text) || !WinX.Core.Validator.IsAlphaNumber(txtName.Text))
            {
                MessageBox.Show("Name can not have spaces or special chars.", "Invalid Name", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var app = this.DataContext as WinX.Core.Application;
            
            if (app != null && app.Screens != null)
            {
                screen = app.Screens.Where(m => m.Name == txtName.Text).FirstOrDefault();
                if (screen != null)
                {
                    MessageBox.Show("There is already an screen present with the name '" + txtName.Text + "'. Please choose an other one .", "Duplicate Name", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }
            }
            
            if (screen == null)
            {
                switch (app.Type)
                {
                    case WinX.Core.ApplicationType.Web:

                        app.Screens.Add(new WinX.Web.WebScreen() { ID = Guid.NewGuid(),
                                                                    Name = txtName.Text,
                                                                    Description = txtDescription.Text,
                                                                    ApplicationID = app.ID
                                                                });
                        break;
                    case WinX.Core.ApplicationType.Generic:
                        app.Screens.Add(new WinX.Windows.GenericWindow
                                                                {
                                                                    ID = Guid.NewGuid(),
                                                                    Name = txtName.Text,
                                                                    Description = txtDescription.Text,
                                                                    ApplicationID = app.ID
                                                                });

                        break;
                    case WinX.Core.ApplicationType.Pcom:

                        break;
                }
            }
            else
            {
                screen.Name = txtName.Text;
                screen.Description = txtDescription.Text;
                screen.ApplicationID = app.ID;
                app.Screens.Add(screen);
            }
            
            this.DialogResult = true;
            this.Close();
        }

        private void btnCencal_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
            this.Close();
        }
    }
}
