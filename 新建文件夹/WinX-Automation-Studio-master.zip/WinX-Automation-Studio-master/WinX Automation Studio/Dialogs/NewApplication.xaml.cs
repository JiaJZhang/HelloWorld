﻿using MahApps.Metro.Controls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MahApps.Metro.Controls.Dialogs;


namespace WinX_Automation_Studio
{
    /// <summary>
    /// NewApplication.xaml 的交互逻辑
    /// </summary>
    public partial class NewApplication : MetroWindow
    {
        public NewApplication()
        {
            InitializeComponent();

            cmbApplicationType.ItemsSource = Enum.GetValues(typeof(WinX.Core.ApplicationType));
            WinX.Core.Logger.Write(this.GetType().Name + "has been loaded successfully.");
        }

        private void btnCencal_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
            this.Close();
        }

        private void btnOK_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(txtName.Text) || !WinX.Core.Validator.IsAlphaNumber(txtName.Text))
            {
                MessageBox.Show("Name can not have spaces or special chars.", "Invalid Name", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var proj = this.DataContext as WinX.Core.Project;
            WinX.Core.Application app = null;
            if (proj != null && proj.Applications != null)
            {
                app = proj.Applications.Where(m => m.Name == txtName.Text).FirstOrDefault();
                if (app != null)
                {
                    MessageBox.Show("There is already an application present with the name '" + txtName.Text + "'. Please choose an other one .", "Duplicate Name", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }
            }

            if (cmbApplicationType.SelectedItem == null)
            {
                MessageBox.Show("Please choose the application type.", "Error");
                return;
            }

            WinX.Core.ApplicationType applicationType = (WinX.Core.ApplicationType)Enum.Parse(typeof(WinX.Core.ApplicationType), cmbApplicationType.SelectedItem.ToString());

            switch (applicationType)
            {
                case WinX.Core.ApplicationType.Web:

                    app = new WinX.Web.WebApplication()
                    {
                        ID = Guid.NewGuid(),
                        Name = txtName.Text,
                        Type = WinX.Core.ApplicationType.Web,
                        Description = txtDescription.Text,
                    };


                    break;
                case WinX.Core.ApplicationType.Generic:

                    app = new WinX.Web.WebApplication()
                    {
                        ID = Guid.NewGuid(),
                        Name = txtName.Text,
                        Type = WinX.Core.ApplicationType.Generic,
                        Description = txtDescription.Text,
                    };
                    break;
                case WinX.Core.ApplicationType.Pcom:
                    break;

            }

            if (app != null)
            {
                proj.Applications.Add(app);
            }

            this.DialogResult = true;
            this.Close();
        }
    }
}
