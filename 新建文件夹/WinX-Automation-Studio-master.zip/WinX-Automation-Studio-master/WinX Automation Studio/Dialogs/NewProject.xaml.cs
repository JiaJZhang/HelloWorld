﻿using MahApps.Metro.Controls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WinX_Automation_Studio
{
    /// <summary>
    /// NewProject.xaml 的交互逻辑
    /// </summary>
    public partial class NewProject : MetroWindow
    {
        public NewProject()
        {
            InitializeComponent();

            WinX.Core.Logger.Write(this.GetType().Name + " has been loaded successfully.");
            this.txtProjectDirectory.Text = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + @"\WinX Projects";
        }

        private void btnCencal_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
            this.Close();
        }

        private void btnBrowse_Click(object sender, RoutedEventArgs e)
        {
            var fdb = new FolderBrowserDialog();
            fdb.ShowNewFolderButton = true;
            if(fdb.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                txtProjectDirectory.Text = fdb.SelectedPath;
            }
        }

        private void btnOK_Click(object sender, RoutedEventArgs e)
        {
            if(string.IsNullOrEmpty(txtName.Text) || !WinX.Core.Validator.IsAlphaNumber(txtName.Text))
            {
                System.Windows.MessageBox.Show("Name can not have spaces or special chars.", "Invalid Name", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            this.DialogResult = true;
            this.Close();
        }
    }
}
