﻿using MahApps.Metro.Controls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WinX.Core;
using WinX.StudioLib;
using MahApps.Metro.Controls.Dialogs;
using System.ComponentModel;

namespace WinX_Automation_Studio
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : MetroWindow
    {
        private string projectDirPath = string.Empty;
        private string projectFilePath = string.Empty;

        public ObservableCollection<WinX.Core.Project> _curProj
        {
            get;set;
        }

        public Screen _curScreen
        {
            get; set;
        }



        public MainWindow()
        {
            InitializeComponent();

            _curProj = new ObservableCollection<WinX.Core.Project>();

            Logger.NotifyUser += (msg) => 
            {
                var msgDialog = new MessageBoxDialog(msg);
                msgDialog.Owner = this;
                msgDialog.ShowDialog();
            };

            this.projectDirPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + @"\WinX Projects\";

            Logger.Write("Studio has been loaded.", Logger.MsgType.Information);
        }


        private void MainWindow_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            var result = MessageBox.Show("Do you want to save project before closing the application?", "Save Changes", MessageBoxButton.YesNoCancel, MessageBoxImage.Question);
            if(result == MessageBoxResult.Yes)
            {
                btnSaveProject_Click(null, null);
            }
            else if(result == MessageBoxResult.Cancel)
            {
                e.Cancel = true;
            }
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            //OpenProject(@"C:\Users\dada7\Desktop\VisualTest\VisualTest.winpx");
        }

        private void btnNewProject_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var newProj = new NewProject();
                newProj.Owner = this;
                if(newProj.ShowDialog() == true)
                {
                    this.projectDirPath = newProj.txtProjectDirectory.Text + @"\" + newProj.txtName.Text;

                    if(!System.IO.Directory.Exists(this.projectDirPath))
                    {
                        System.IO.Directory.CreateDirectory(this.projectDirPath);
                    }

                    this.projectFilePath = this.projectDirPath + @"\" + newProj.txtName.Text + ".winpx";
                    this._curProj.Clear();
                    this._curProj.Add(new Project()
                                    {
                                        ID = Guid.NewGuid(),
                                        Name = newProj.txtName.Text,
                                        Description = newProj.txtDescription.Text,
                                    });
                    ProjectView.ItemsSource = this._curProj;
                    Logger.Write("The project has been created successfully.");
                }

            }
            catch(Exception ex)
            {
                Logger.Write(ex, "There was an error while trying to create new project.");
            }

        }

        private void btnOpenProject_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var sDlg = new System.Windows.Forms.OpenFileDialog();
                sDlg.Filter = "Autopsmate Project(*winpx)|*.winpx";
                if (!string.IsNullOrEmpty(this.projectDirPath))
                {
                    sDlg.InitialDirectory = this.projectDirPath;
                }
                if (sDlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    OpenProject(sDlg.FileName);
                }
            }
            catch(Exception ex)
            {
                Logger.Write(ex, "There was an error while trying to open project.");
            }
        }

        private void OpenProject(string fileName)
        {
            var onenFileInfo = new System.IO.FileInfo(fileName);
            projectFilePath = fileName;
            this.projectDirPath = onenFileInfo.Directory.FullName;
            this._curProj = WinX.Core.Serializers.XMLFileToObject<ObservableCollection<WinX.Core.Project>>(projectFilePath, TypeHelper.GetTypes().ToArray());
            ProjectView.ItemsSource = this._curProj;
            SetNodeExpandedState(ProjectView, true);

        }

        private void btnSaveProject_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(projectFilePath))
                {
                    if (_curProj == null)
                    {
                        this.ShowMessageAsync(Contants.WIN_INVALID, Contants.MSG_APP_EMPTY, MessageDialogStyle.Affirmative);
                    }
                    else
                    {
                        WinX.Core.Serializers.ObjectToXMLFile(_curProj,_curProj.GetType(), projectFilePath, TypeHelper.GetTypes().ToArray());
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Write(ex, "There was an error while trying to save project.File Path -> " + this.projectFilePath + "'");
            }
        }

        private void btnAboutProject_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new AboutScreen();
            dialog.Owner = this;
            dialog.ShowDialog();
        }
        private void CtxNewApp_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var appDialog = new NewApplication();
                appDialog.Owner = this;
                appDialog.DataContext = this._curProj[0];
                if(appDialog.ShowDialog() == true)
                {
                    SetNodeExpandedState(ProjectView, true);
                }
            }
            catch(Exception ex)
            {
                Logger.Write(ex, "There was an error while trying to add new Application to the project.");
            }
        }

        private void SetNodeExpandedState(ItemsControl control, bool expandNode)
        {
            try
            {
                if (control != null)
                {
                    foreach (object item in control.Items)
                    {
                        TreeViewItem treeItem = control.ItemContainerGenerator.ContainerFromItem(item) as TreeViewItem;

                        if (treeItem != null && treeItem.HasItems)
                        {
                            treeItem.IsExpanded = expandNode;

                            if (treeItem.ItemContainerGenerator.Status != System.Windows.Controls.Primitives.GeneratorStatus.ContainersGenerated)
                            {
                                treeItem.UpdateLayout();
                            }

                            SetNodeExpandedState(treeItem as ItemsControl, expandNode);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Write(ex, "There was an error while trying to Expanded.");

            }
        }

        private void CtxNewScreen_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var app = ProjectView.SelectedItem as WinX.Core.Application;

                if (app != null)
                {
                    var dlg = new NewScreen()
                    {
                        Owner = this,
                        DataContext = app
                    };

                    dlg.ShowDialog();
                    SetNodeExpandedState(ProjectView, true);
                }
            }
            catch(Exception ex)
            {
                Logger.Write(ex, "There was an error while trying to add new screen to the screen.");
            }
        }

        private void CtxNewElement_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var screen = ProjectView.SelectedItem as WinX.Core.Screen;
                if (screen != null)
                {
                    if (screen is WinX.Web.WebScreen)
                    {
                        var dlg = new NewField()
                        {
                            Owner = this,
                            DataContext = screen,

                        };

                        dlg.txtType.Text = "mshtml.IHTMLElement";

                        if (dlg.ShowDialog() == true)
                        {
                            screen.Fields.Add(new WinX.Web.WebElement()
                            {
                                ID = Guid.NewGuid(),
                                Name = dlg.txtName.Text,
                                ElementType = dlg.txtType.Text,
                                Description = dlg.txtDescription.Text,
                                ScreenID = screen.ID,
                                ApplicationID = screen.ApplicationID
                            });
                        }
                    }
                    else if (screen is WinX.Windows.GenericWindow)
                    {
                        var dlg = new NewField()
                        {
                            Owner = this,
                            DataContext = screen,

                        };

                        dlg.txtType.Text = "System.Object";

                        if (dlg.ShowDialog() == true)
                        {
                            screen.Fields.Add(new WinX.Windows.GenericElement()
                            {
                                ID = Guid.NewGuid(),
                                Name = dlg.txtName.Text,
                                ElementType = dlg.txtType.Text,
                                Description = dlg.txtDescription.Text,
                                ScreenID = screen.ID,
                                ApplicationID = screen.ApplicationID
                            });
                        }
                    }
                }
                SetNodeExpandedState(ProjectView, true);
            }
            catch(Exception ex)
            {
                Logger.Write(ex, "There was an error while trying to add new element to the screen.");
            }
        }
        
        private void ProjectView_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            try
            {
                if (ProjectView.SelectedItem != null)
                {
                    var item = ProjectView.SelectedItem;

                    if (item.GetType().BaseType.Name.Equals(typeof(WinX.Core.Screen).Name))
                    {
                        if (!item.Equals(_curScreen))
                        {
                            RefreshScreen(_curScreen);
                            _curScreen = item as Screen;
                        }
                    }

                    PropertyGrid.Instance = item;
                    CenterGrid.Children.Clear();

                    if (item is WinX.Web.WebScreen || item is WinX.Web.WebPdfScreen)
                    {
                        CenterGrid.Children.Add(new CtrlWebDocument { DataContext = item, App = this._curProj[0].Applications.Where(m => m.ID == ((WinX.Web.WebScreen)item).ApplicationID).FirstOrDefault() });
                    }
                    else if (item is WinX.Windows.GenericWindow)
                    {
                        CenterGrid.Children.Add(new CtrlGenericWindow { DataContext = item });
                    }
                    else if (item is WinX.Web.WebElement)
                    {
                        CenterGrid.Children.Add(new CtrlWebElement { DataContext = item });
                    }
                    else if (item is WinX.Windows.GenericElement)
                    {
                        CenterGrid.Children.Add(new CtrlGenericElement { DataContext = item });
                    }
                    else if (item is WinX.Windows.VisualElement)
                    {
                        var oldVisualEle = item as WinX.Windows.VisualElement;
                      
                        var app = this._curProj[0].Applications.Where(m => m.ID == ((WinX.Core.Field)item).ApplicationID).FirstOrDefault();

                        if (app != null)
                        {
                            var screen = app.Screens.Where(m => m.ID == oldVisualEle.ScreenID).FirstOrDefault() as WinX.Windows.GenericWindow;

                            if (screen != null)
                            {
                                //oldVisualEle.Parent = screen;
                                var ctrlVisualElement = new CtrlVisualElement()
                                {
                                    CurrTarget = oldVisualEle,
                                    CurrWindow = screen,
                                };

                                CenterGrid.Children.Add(ctrlVisualElement);
                            }
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                Logger.Write(ex, "There was an error while trying to switch between objects in the project tree.");
            }
        }

        private void RefreshScreen(Screen curScreen)
        {
            try
            {
                if(this._curProj != null)
                {
                    if (this._curProj[0].Applications != null && this._curProj[0].Applications.Count > 0)
                    {
                        var bgWorker = new BackgroundWorker();
                        bgWorker.DoWork += (s1, e1) =>
                        {
                            dynamic e2 = e1.Argument;
                            foreach (WinX.Core.Application app in e2[0])
                            {
                                foreach (var screen in app.Screens)
                                {
                                    if (screen is WinX.Web.WebScreen)
                                    {
                                        WinX.Web.MatchEngine.ResetScreenStatus(screen);
                                    }
                                    if (screen is WinX.Web.WebPdfScreen)
                                    {
                                        WinX.Web.MatchEngine.ResetScreenStatus(screen);
                                    }
                                    //other Windows match rule;

                                    if (screen.GetType().IsEquivalentTo(typeof(WinX.Web.WebScreen)))
                                    {
                                        WinX.Web.MatchEngine.ResetScreenStatus(screen);
                                    }

                                }
                            }
                        };

                        bgWorker.RunWorkerAsync(new object[] { this._curProj[0].Applications, curScreen });
                    }
                }

            }
            catch(Exception ex)
            {
                Logger.Write(ex, "There was an error while trying refresh project tree.");
            }
        }

        private void CtxDeleteApp_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                var item = ProjectView.SelectedItem;

                if (item is WinX.Core.Application)
                {
                    this._curProj[0].Applications.Remove(item as WinX.Core.Application);
                }
            }
            catch (Exception ex)
            {
                Logger.Write(ex, "There was an error while trying to delete application.");
            }
        }

        private void CtxDeleteScreen_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var item = ProjectView.SelectedItem;

                if (item is WinX.Core.Screen)
                {
                    var app = this._curProj[0].Applications.Where(m => m.ID == ((WinX.Core.Screen)item).ApplicationID).FirstOrDefault();

                    if(app != null)
                    {
                        app.Screens.Remove((WinX.Core.Screen)item);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Write(ex, "There was an error while trying to delete screen.");
            }
        }


        private void CtxDeleteField_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var item = ProjectView.SelectedItem;

                if (item is WinX.Core.Field)
                {
                    var app = this._curProj[0].Applications.Where(m => m.ID == ((WinX.Core.Field)item).ApplicationID).FirstOrDefault();

                    if (app != null)
                    {
                        var screen = app.Screens.Where(m => m.ID == ((WinX.Core.Field)item).ScreenID).FirstOrDefault();
                        screen.Fields.Remove((WinX.Core.Field)item);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Write(ex, "There was an error while trying to delete Field.");
            }
        }


        private void CtxListener_Click(object sender, RoutedEventArgs e)
        {

        }

        private void CtxJsEditor_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var item = ProjectView.SelectedItem;

                if (item is WinX.Web.WebScreen)
                {
                    var webScreen = item as WinX.Web.WebScreen;
                    var doc = webScreen.HTMLDocument;
                    if(doc != null)
                    {
                        var jsScriptDialog = new JavaScriptDialog();
                        jsScriptDialog.Owner = WinX_Automation_Studio.App.Current.MainWindow;
                        jsScriptDialog.DataContext = doc;
                        jsScriptDialog.ShowDialog();
                    }

                }
            }
            catch (Exception ex)
            {
                Logger.Write(ex, "There was an error while trying to execute JavaScript.");
            }
        }

        private void CtxAddChildMatchRule_Click(object sender, RoutedEventArgs e)
        {

        }


        private void btnBuildProject_Click(object sender, RoutedEventArgs e)
        {
            if(!string.IsNullOrEmpty( projectDirPath) && _curProj.Count > 0)
            {
                var buildFolder = projectDirPath + @"\bin\v" + _curProj[0].BuildVersion;

                if(System.IO.Directory.Exists(projectDirPath + @"\bin"))
                {
                    System.IO.Directory.Delete(projectDirPath + @"\bin", true);
                }

                var buildDialog = new BuildDialog(_curProj[0], buildFolder);
                buildDialog.ShowDialog();
                this.btnSaveProject_Click(null, null);
            }
        }
    }
}
